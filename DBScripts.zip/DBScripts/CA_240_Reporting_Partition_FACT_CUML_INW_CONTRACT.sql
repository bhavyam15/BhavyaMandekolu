--***********************************************************************************************
-- Script Name :     CA_240_Reporting_Partition_FACT_CUML_INW_CONTRACT.sql

-- Description:               Script to Partition FACT_CUML_INW_CONTRACT
                
-- Modification Log:
-- Version 1.0.0                    <Dushyant S>                 27/11/2019             Initial version.
-- ************************************************************************************************************************************************************************************


USE $(REPORTING_DB)

-- This is for Main table

IF NOT EXISTS (
		SELECT ps.Name PartitionScheme,
			pf.name PartitionFunction,
			object_name(i.object_id) table_name
		FROM sys.indexes i
		JOIN sys.partition_schemes ps ON ps.data_space_id = i.data_space_id
		JOIN sys.partition_functions pf ON pf.function_id = ps.function_id
		WHERE i.object_id = object_id('FACT_CUML_INW_CONTRACT')
		)
BEGIN
	BEGIN TRANSACTION

	ALTER TABLE dbo.FACT_CUML_INW_CONTRACT

	DROP CONSTRAINT FACT_CUML_INW_CONTRACT_PK
	WITH (ONLINE = OFF)

	ALTER TABLE dbo.FACT_CUML_INW_CONTRACT ADD CONSTRAINT FACT_CUML_INW_CONTRACT_PK PRIMARY KEY CLUSTERED (
		DIM_SYNDICATE_KEY ASC,
		DIM_UNDERWRITING_DIVISION_KEY ASC,
		DIM_CURRENCY_KEY ASC,
		DIM_YEAR_OF_ACCOUNT_KEY ASC,
		DIM_DURG_CLASS_KEY ASC,
		DIM_CALENDAR_KEY ASC,
		DIM_INW_SYNDICATE_CONTRACT_KEY ASC,
		DIM_SCENARIO_KEY ASC
		)
		WITH (
				PAD_INDEX = OFF,
				STATISTICS_NORECOMPUTE = OFF,
				SORT_IN_TEMPDB = ON,
				IGNORE_DUP_KEY = OFF,
				ONLINE = OFF,
				ALLOW_ROW_LOCKS = ON,
				MAXDOP = 16,
				ALLOW_PAGE_LOCKS = ON
				) ON p_sch_calendar_year(DIM_CALENDAR_KEY)

	COMMIT TRANSACTION
END
