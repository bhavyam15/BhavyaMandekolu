--***********************************************************************************************
-- Script Name :  CA_210_KDRStaging_Compress_Tables.sql

-- Description:   Script to compress existing tables to reduce IO
                
-- Modification Log:
-- Version 1.0.0                    <Dushyant S>                 05/11/2019             Initial version.
-- ************************************************************************************************************************************************************************************

USE $(KDRSTAGING_DB)

GO

IF NOT EXISTS (
		SELECT *
		FROM sys.partitions p
		INNER JOIN sys.objects o ON p.object_id = o.object_id
		WHERE p.data_compression > 0
			AND OBJECT_NAME(o.object_id) = 'WRK_ECL_INW_CLAIM_MOVEMENT'
		)
	ALTER TABLE dbo.WRK_ECL_INW_CLAIM_MOVEMENT REBUILD PARTITION = ALL
		WITH (DATA_COMPRESSION = PAGE)
GO

IF NOT EXISTS (
		SELECT *
		FROM sys.partitions p
		INNER JOIN sys.objects o ON p.object_id = o.object_id
		WHERE p.data_compression > 0
			AND OBJECT_NAME(o.object_id) = 'TMP_ECL_LANDED_SCMTRANS'
		)
	ALTER TABLE dbo.TMP_ECL_LANDED_SCMTRANS REBUILD PARTITION = ALL
		WITH (DATA_COMPRESSION = PAGE)
GO


