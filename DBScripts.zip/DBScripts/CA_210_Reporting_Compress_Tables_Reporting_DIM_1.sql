--***********************************************************************************************
-- Script Name :  CA_210_Reporting_Compress_Tables_Reporting_DIM_1.sql

-- Description:   Script to compress existing tables to reduce IO
                
-- Modification Log:
-- Version 1.0.0                    <Dushyant S>                 05/11/2019             Initial version.
-- ************************************************************************************************************************************************************************************

USE $(REPORTING_DB)

GO

IF NOT EXISTS (
		SELECT *
		FROM sys.partitions p
		INNER JOIN sys.objects o ON p.object_id = o.object_id
		WHERE p.data_compression > 0
			AND OBJECT_NAME(o.object_id) = 'DIM_INW_SYNDICATE_CONTRACT'
		)
	ALTER TABLE dbo.DIM_INW_SYNDICATE_CONTRACT REBUILD PARTITION = ALL
		WITH (DATA_COMPRESSION = PAGE)
GO

IF NOT EXISTS (
		SELECT *
		FROM sys.partitions p
		INNER JOIN sys.objects o ON p.object_id = o.object_id
		WHERE p.data_compression > 0
			AND OBJECT_NAME(o.object_id) = 'DIM_INW_PRE_SCM_CLAIM'
		)
	ALTER TABLE dbo.DIM_INW_PRE_SCM_CLAIM REBUILD PARTITION = ALL
		WITH (DATA_COMPRESSION = PAGE)
GO

IF NOT EXISTS (
		SELECT *
		FROM sys.partitions p
		INNER JOIN sys.objects o ON p.object_id = o.object_id
		WHERE p.data_compression > 0
			AND OBJECT_NAME(o.object_id) = 'RTL_DIM_INW_SYNDICATE_CONTRACT'
		)
	ALTER TABLE dbo.RTL_DIM_INW_SYNDICATE_CONTRACT REBUILD PARTITION = ALL
		WITH (DATA_COMPRESSION = PAGE)
GO

IF NOT EXISTS (
		SELECT *
		FROM sys.partitions p
		INNER JOIN sys.objects o ON p.object_id = o.object_id
		WHERE p.data_compression > 0
			AND OBJECT_NAME(o.object_id) = 'RTL_DIM_INW_PRE_SCM_CLAIM'
		)
	ALTER TABLE dbo.RTL_DIM_INW_PRE_SCM_CLAIM REBUILD PARTITION = ALL
		WITH (DATA_COMPRESSION = PAGE)
GO