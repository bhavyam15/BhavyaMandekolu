--***********************************************************************************************
-- Script Name :  CA_210_Reporting_Compress_Tables_Reporting_3.sql

-- Description:   Script to compress existing tables to reduce IO
                
-- Modification Log:
-- Version 1.0.0                    <Dushyant S>                 05/11/2019             Initial version.
-- ************************************************************************************************************************************************************************************

USE $(REPORTING_DB)

GO

IF NOT EXISTS (
		SELECT *
		FROM sys.partitions p
		INNER JOIN sys.objects o ON p.object_id = o.object_id
		WHERE p.data_compression > 0
			AND OBJECT_NAME(o.object_id) = 'FACT_CREDIT_CONTROL'
		)
	ALTER TABLE dbo.FACT_CREDIT_CONTROL REBUILD PARTITION = ALL
		WITH (DATA_COMPRESSION = PAGE)
GO

IF NOT EXISTS (
		SELECT *
		FROM sys.partitions p
		INNER JOIN sys.objects o ON p.object_id = o.object_id
		WHERE p.data_compression > 0
			AND OBJECT_NAME(o.object_id) = 'FACT_CUML_OUTW_CONTRACT_CLAIM_ACTUALS'
		)
	ALTER TABLE dbo.FACT_CUML_OUTW_CONTRACT_CLAIM_ACTUALS REBUILD PARTITION = ALL
		WITH (DATA_COMPRESSION = PAGE)
GO

IF NOT EXISTS (
		SELECT *
		FROM sys.partitions p
		INNER JOIN sys.objects o ON p.object_id = o.object_id
		WHERE p.data_compression > 0
			AND OBJECT_NAME(o.object_id) = 'RTL_FACT_CREDIT_CONTROL'
		)
	ALTER TABLE dbo.RTL_FACT_CREDIT_CONTROL REBUILD PARTITION = ALL
		WITH (DATA_COMPRESSION = PAGE)
GO

IF NOT EXISTS (
		SELECT *
		FROM sys.partitions p
		INNER JOIN sys.objects o ON p.object_id = o.object_id
		WHERE p.data_compression > 0
			AND OBJECT_NAME(o.object_id) = 'RTL_FACT_CUML_OUTW_CONTRACT_CLAIM_ACTUALS'
		)
	ALTER TABLE dbo.RTL_FACT_CUML_OUTW_CONTRACT_CLAIM_ACTUALS REBUILD PARTITION = ALL
		WITH (DATA_COMPRESSION = PAGE)
GO