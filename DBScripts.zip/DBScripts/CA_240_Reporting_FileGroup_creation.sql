--***********************************************************************************************
-- Script Name :     CA_240_Reporting_FileGroup_creation.sql

-- Description:               Script to create file Groups
                
-- Modification Log:
-- Version 1.0.0                    <Dushyant S>                 27/11/2019             Initial version.
-- ************************************************************************************************************************************************************************************

USE $(REPORTING_DB)
GO

-- this would be the default file group for all Paritions

IF NOT EXISTS (
		SELECT NAME
		FROM sys.filegroups
		WHERE NAME = N'FG_PARTITION_REPORTING'
		)
BEGIN
	-- Add filegroup FG_PARTITION_REPORTING
	ALTER DATABASE $(REPORTING_DB) ADD FILEGROUP [FG_PARTITION_REPORTING]

	-- Add data file to FG_PARTITION_REPORTING
	ALTER DATABASE $(REPORTING_DB) ADD FILE (
			NAME = N'Reporting_Partitions',
			-- Change path appripriate to the server
			FILENAME = N'D:\SQLData\$(REPORTING_DB)_Partitions.ndf',
			SIZE = 1024 MB,
			FILEGROWTH = 1024 MB
			) TO FILEGROUP [FG_PARTITION_REPORTING]
END
GO

-- this would be the file group for all Paritions contains data that we believe Business actively uses
-- This normally is YOA 2010 till 2023

IF NOT EXISTS (
		SELECT NAME
		FROM sys.filegroups
		WHERE NAME = N'FG_PARTITION_REPORTING_ACTIVE'
		)
BEGIN
	-- Add filegroup FG_PARTITION_REPORTING_ACTIVE
	ALTER DATABASE $(REPORTING_DB) ADD FILEGROUP [FG_PARTITION_REPORTING_ACTIVE]

	-- Add data file to FG_PARTITION_REPORTING_ACTIVE
	ALTER DATABASE $(REPORTING_DB) ADD FILE (
			NAME = N'Reporting_Partitions_Active',
			-- Change path appripriate to the server
			FILENAME = N'D:\SQLData\$(REPORTING_DB)_Partitions_Active.ndf',
			SIZE = 1024 MB,
			FILEGROWTH = 1024 MB
			) TO FILEGROUP [FG_PARTITION_REPORTING_ACTIVE]
END

GO


