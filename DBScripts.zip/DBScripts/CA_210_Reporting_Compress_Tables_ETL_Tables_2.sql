--***********************************************************************************************
-- Script Name :  CA_210_Reporting_Compress_Tables_ETL_Tables_2.sql

-- Description:   Script to compress existing tables to reduce IO
                
-- Modification Log:
-- Version 1.0.0                    <Dushyant S>                 05/11/2019             Initial version.
-- ************************************************************************************************************************************************************************************

USE $(REPORTING_DB)

GO

IF NOT EXISTS (
		SELECT *
		FROM sys.partitions p
		INNER JOIN sys.objects o ON p.object_id = o.object_id
		WHERE p.data_compression > 0
			AND OBJECT_NAME(o.object_id) = 'TMP_REP_LANDED_Inw_Claim_Movement'
		)
	ALTER TABLE dbo.TMP_REP_LANDED_Inw_Claim_Movement REBUILD PARTITION = ALL
		WITH (DATA_COMPRESSION = PAGE)
GO

IF NOT EXISTS (
		SELECT *
		FROM sys.partitions p
		INNER JOIN sys.objects o ON p.object_id = o.object_id
		WHERE p.data_compression > 0
			AND OBJECT_NAME(o.object_id) = 'TMP_REP_LANDED_YOA_General_Adjustment'
		)
	ALTER TABLE dbo.TMP_REP_LANDED_YOA_General_Adjustment REBUILD PARTITION = ALL
		WITH (DATA_COMPRESSION = PAGE)
GO

IF NOT EXISTS (
		SELECT *
		FROM sys.partitions p
		INNER JOIN sys.objects o ON p.object_id = o.object_id
		WHERE p.data_compression > 0
			AND OBJECT_NAME(o.object_id) = 'WRK_EARLY_RI_QRY_CUMULATIVE_SETTLEMENT'
		)
	ALTER TABLE dbo.WRK_EARLY_RI_QRY_CUMULATIVE_SETTLEMENT REBUILD PARTITION = ALL
		WITH (DATA_COMPRESSION = PAGE)
GO

