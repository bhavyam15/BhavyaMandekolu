--***********************************************************************************************
-- Script Name :  CA_282_KDR_Create_Index_2.sql

-- Description:   Script to create new indexes on key KDR tables
                
-- Modification Log:
-- Version 1.0.0                    <Dushyant S>                 05/11/2019             Initial version.
-- ************************************************************************************************************************************************************************************

USE $(KDR_DB)

GO

-- Creating new indexes

IF NOT EXISTS (
		SELECT NAME
		FROM sys.indexes
		WHERE NAME = N'IDX_USM_CURRENT'
		)
	CREATE NONCLUSTERED INDEX IDX_USM_CURRENT ON dbo.Inw_USM (
		Current_IND,
		Deleted_IND,
		Early_RI_IND,
		Year_Of_Account
		) INCLUDE (
		Transaction_Reason_Repos_ID,
		SYNDICATE_REPOS_ID,
		Signing_Status_Repos_ID,
		Settlement_Currency_Repos_ID,
		Settlement_Transaction_AMT,
		Inw_Contract_Repos_ID,
		Trust_Fund_Repos_ID,
		Risk_Code_Repos_ID,
		Processing_Period_Repos_ID
		)
		WITH (
				SORT_IN_TEMPDB = ON,
				MAXDOP = 16,
				DROP_EXISTING = OFF,
				IGNORE_DUP_KEY = OFF,
				ONLINE = OFF
				)
GO


