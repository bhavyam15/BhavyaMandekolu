--***********************************************************************************************
-- Script Name :  CA_282_KDR_Create_Index_1.sql

-- Description:   Script to create new indexes on key KDR tables
                
-- Modification Log:
-- Version 1.0.0                    <Dushyant S>                 05/11/2019             Initial version.
-- ************************************************************************************************************************************************************************************

USE $(KDR_DB)

GO

-- Creating new indexes

IF NOT EXISTS (
		SELECT NAME
		FROM sys.indexes
		WHERE NAME = N'IX_CTRL_LOAD_MGMT_JOBNAME'
		)
	CREATE NONCLUSTERED INDEX IX_CTRL_LOAD_MGMT_JOBNAME ON dbo.CTRL_Load_Management (
		Job_Name ASC,
		Load_Status ASC,
		Repository_Run_From ASC
		) INCLUDE (
		Load_ID,
		Project_Name,
		Load_Start,
		Load_End,
		Applied_To_Kdr
		)
		WITH (
				SORT_IN_TEMPDB = ON,
				MAXDOP = 8,
				DROP_EXISTING = OFF,
				IGNORE_DUP_KEY = OFF,
				ONLINE = OFF
				)
GO

IF NOT EXISTS (
		SELECT NAME
		FROM sys.indexes
		WHERE NAME = N'IDX_CTRL_LOAD_MESSAGES'
		)
	CREATE NONCLUSTERED INDEX IDX_CTRL_LOAD_MESSAGES ON dbo.CTRL_Load_Message (load_id ASC) INCLUDE (Load_Message_Key)
		WITH (
				SORT_IN_TEMPDB = ON,
				MAXDOP = 8,
				DROP_EXISTING = OFF,
				IGNORE_DUP_KEY = OFF,
				ONLINE = OFF
				)
GO

IF NOT EXISTS (
		SELECT NAME
		FROM sys.indexes
		WHERE NAME = N'IDX_INW_CONTRACT_ACTIVE'
		)
	CREATE NONCLUSTERED INDEX IDX_INW_CONTRACT_ACTIVE ON dbo.Inw_Contract (
		Current_IND ASC,
		Deleted_IND ASC
		) INCLUDE (
		Inw_Contract_Repos_ID,
		Underwriting_Division_Repos_ID,
		Syndicate_Repos_ID,
		Durg_Repos_ID,
		Inw_Contract_Source_ID
		)
		WITH (
				SORT_IN_TEMPDB = ON,
				MAXDOP = 8,
				DROP_EXISTING = OFF,
				IGNORE_DUP_KEY = OFF,
				ONLINE = OFF
				)
GO

IF NOT EXISTS (
		SELECT NAME
		FROM sys.indexes
		WHERE NAME = N'IDX_ITEM_ALLOCATION'
		)
	CREATE NONCLUSTERED INDEX IDX_ITEM_ALLOCATION ON dbo.Lrc_Ltf_Item_Allocation_Outw (
		Period_Repos_ID ASC,
		Item_Name ASC
		) INCLUDE (
		Outw_Contract_Repos_ID,
		Syndicate_Repos_ID,
		Underwriting_Division_Repos_ID,
		Durg_Repos_ID,
		Currency_Repos_ID,
		Year_Of_Account,
		Risk_Code_Repos_ID,
		Allocation_AMT
		)
		WITH (
				SORT_IN_TEMPDB = ON,
				MAXDOP = 8,
				DROP_EXISTING = OFF,
				IGNORE_DUP_KEY = OFF,
				ONLINE = OFF
				)
GO

IF NOT EXISTS (
		SELECT NAME
		FROM sys.indexes
		WHERE NAME = N'IDX_Inw_Contract_3Capital'
		)
	CREATE NONCLUSTERED INDEX IDX_Inw_Contract_3Capital ON dbo.Inw_Contract_3Capital_Reporting_Usage (
		Current_IND,
		Deleted_IND,
		Data_Source_Repos_ID,
		Applicable_IND
		) INCLUDE (Inw_Contract_Repos_ID)
		WITH (
				SORT_IN_TEMPDB = ON,
				MAXDOP = 8,
				DROP_EXISTING = OFF,
				IGNORE_DUP_KEY = OFF,
				ONLINE = OFF
				)
GO

IF NOT EXISTS (
		SELECT NAME
		FROM sys.indexes
		WHERE NAME = N'IDX_INW_CONTRACT_EFFECTIVE_DATE'
		)
	CREATE NONCLUSTERED INDEX IDX_INW_CONTRACT_EFFECTIVE_DATE ON dbo.Inw_Contract (
		Effective_Start_DT,
		Effective_End_DT,
		Deleted_IND
		) INCLUDE (
		Inw_Contract_Repos_ID,
		Underwriting_Division_Repos_ID,
		Syndicate_Repos_ID,
		LBS_IND
		)
		WITH (
				SORT_IN_TEMPDB = ON,
				MAXDOP = 8,
				DROP_EXISTING = OFF,
				IGNORE_DUP_KEY = OFF,
				ONLINE = OFF
				)
GO


