--***********************************************************************************************
-- Script Name :     CA_240_KDR_FileGroup_creation.sql

-- Description:               Script to create file Groups
                
-- Modification Log:
-- Version 1.0.0                    <Dushyant S>                 27/11/2019             Initial version.
-- ************************************************************************************************************************************************************************************

USE $(KDR_DB)
GO

-- this would be the default file group for all historical data


IF NOT EXISTS (
		SELECT NAME
		FROM sys.filegroups
		WHERE NAME = N'FG_PARTITION_KDR_HISTORY'
		)
BEGIN
	-- Add filegroup FG_PARTITION_REPORTING
	ALTER DATABASE $(KDR_DB) ADD FILEGROUP FG_PARTITION_KDR_HISTORY

	-- Add data file to FG_PARTITION_REPORTING
	ALTER DATABASE $(KDR_DB) ADD FILE (
			NAME = N'KDR_History',
			-- Change path appripriate to the server
			FILENAME = N'D:\SQLData\$(KDR_DB)_History.ndf',
			SIZE = 1024 MB,
			FILEGROWTH = 1024 MB
			) TO FILEGROUP FG_PARTITION_KDR_HISTORY
END
GO
