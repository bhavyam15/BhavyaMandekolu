--***********************************************************************************************
-- Script Name :     CA_240_KDR_Partition_CTRL_LOAD_TABLES.sql

-- Description:               Script to Partition FACT_CUML_INW_CONTRACT
                
-- Modification Log:
-- Version 1.0.0                    <Dushyant S>                 27/11/2019             Initial version.
-- ************************************************************************************************************************************************************************************

USE $(KDR_DB)

IF NOT EXISTS (
		SELECT *
		FROM sys.partition_functions
		WHERE name = 'fn_p_ctrl_load_Data'
		)
BEGIN
	CREATE PARTITION FUNCTION fn_p_ctrl_load_Data (DATETIME) AS RANGE RIGHT
	FOR
	VALUES (N'20191201')
END

IF NOT EXISTS (
		SELECT *
		FROM sys.partition_schemes
		WHERE name = 'p_sch_ctrl_load_data'
		)
BEGIN
	CREATE PARTITION SCHEME p_sch_ctrl_load_data AS PARTITION fn_p_ctrl_load_Data TO (
		FG_PARTITION_KDR_HISTORY,
		[PRIMARY]
		)
END

IF NOT EXISTS (
		SELECT *
		FROM sys.partition_functions
		WHERE name = 'fn_p_ctrl_load_Data_load_id'
		)
BEGIN
	CREATE PARTITION FUNCTION fn_p_ctrl_load_Data_load_id (INT) AS RANGE RIGHT
	FOR
	VALUES (N'969000')
END

IF NOT EXISTS (
		SELECT *
		FROM sys.partition_schemes
		WHERE name = 'p_sch_ctrl_load_id_data'
		)
BEGIN
	CREATE PARTITION SCHEME p_sch_ctrl_load_id_data AS PARTITION fn_p_ctrl_load_Data_load_id TO (
		FG_PARTITION_KDR_HISTORY,
		[PRIMARY]
		)
END

-- This is for CTRL Load Management table
IF NOT EXISTS (
		SELECT ps.Name PartitionScheme,
			pf.name PartitionFunction,
			object_name(i.object_id) table_name
		FROM sys.indexes i
		JOIN sys.partition_schemes ps ON ps.data_space_id = i.data_space_id
		JOIN sys.partition_functions pf ON pf.function_id = ps.function_id
		WHERE i.object_id = object_id('CTRL_LOAD_MANAGEMENT')
		)
BEGIN
	BEGIN TRANSACTION

	ALTER TABLE dbo.CTRL_LOAD_MANAGEMENT

	DROP CONSTRAINT CTRL_LOAD_MANAGEMENT_PK
	WITH (ONLINE = OFF)

	ALTER TABLE dbo.CTRL_LOAD_MANAGEMENT ADD CONSTRAINT CTRL_LOAD_MANAGEMENT_PK PRIMARY KEY CLUSTERED (
		Load_ID ASC,
		load_start ASC
		)
		WITH (
				PAD_INDEX = OFF,
				STATISTICS_NORECOMPUTE = OFF,
				SORT_IN_TEMPDB = ON,
				IGNORE_DUP_KEY = OFF,
				ONLINE = OFF,
				ALLOW_ROW_LOCKS = ON,
				MAXDOP = 16,
				ALLOW_PAGE_LOCKS = ON
				) ON p_sch_ctrl_load_data(load_start)

	CREATE NONCLUSTERED INDEX IX_CTRL_LOAD_MGMT_JOBNAME ON dbo.CTRL_Load_Management (
		Job_Name ASC,
		Load_Status ASC,
		Repository_Run_From ASC
		) INCLUDE (
		Load_ID,
		Project_Name,
		Load_Start,
		Load_End,
		Applied_To_Kdr
		)
		WITH (
				PAD_INDEX = OFF,
				STATISTICS_NORECOMPUTE = OFF,
				SORT_IN_TEMPDB = ON,
				DROP_EXISTING = ON,
				ONLINE = OFF,
				ALLOW_ROW_LOCKS = ON,
				ALLOW_PAGE_LOCKS = ON
				) ON p_sch_ctrl_load_data(load_start)

	COMMIT TRANSACTION
END

-- This is for CTRL_LOAD_MESSAGE table
IF NOT EXISTS (
		SELECT ps.Name PartitionScheme,
			pf.name PartitionFunction,
			object_name(i.object_id) table_name
		FROM sys.indexes i
		JOIN sys.partition_schemes ps ON ps.data_space_id = i.data_space_id
		JOIN sys.partition_functions pf ON pf.function_id = ps.function_id
		WHERE i.object_id = object_id('CTRL_LOAD_MESSAGE')
		)
BEGIN
	BEGIN TRANSACTION

	ALTER TABLE dbo.CTRL_LOAD_MESSAGE

	DROP CONSTRAINT CTRL_LOAD_MESSAGE_PK
	WITH (ONLINE = OFF)

	ALTER TABLE dbo.CTRL_LOAD_MESSAGE ADD CONSTRAINT CTRL_LOAD_MESSAGE_PK PRIMARY KEY CLUSTERED (
		Load_Message_Key ASC,
		Inserted_Date ASC
		)
		WITH (
				PAD_INDEX = OFF,
				STATISTICS_NORECOMPUTE = OFF,
				SORT_IN_TEMPDB = ON,
				IGNORE_DUP_KEY = OFF,
				ONLINE = OFF,
				ALLOW_ROW_LOCKS = ON,
				MAXDOP = 16,
				ALLOW_PAGE_LOCKS = ON
				) ON p_sch_ctrl_load_data(Inserted_Date)

	CREATE NONCLUSTERED INDEX IDX_CTRL_LOAD_MESSAGES ON dbo.CTRL_LOAD_MESSAGE (Load_ID ASC) INCLUDE (Load_Message_Key)
		WITH (
				PAD_INDEX = OFF,
				STATISTICS_NORECOMPUTE = OFF,
				SORT_IN_TEMPDB = ON,
				DROP_EXISTING = ON,
				ONLINE = OFF,
				ALLOW_ROW_LOCKS = ON,
				ALLOW_PAGE_LOCKS = ON
				) ON p_sch_ctrl_load_data(Inserted_Date)

	COMMIT TRANSACTION
END

-- This is for CTRL_CHECK_RESULT table
IF NOT EXISTS (
		SELECT ps.Name PartitionScheme,
			pf.name PartitionFunction,
			object_name(i.object_id) table_name
		FROM sys.indexes i
		JOIN sys.partition_schemes ps ON ps.data_space_id = i.data_space_id
		JOIN sys.partition_functions pf ON pf.function_id = ps.function_id
		WHERE i.object_id = object_id('CTRL_CHECK_RESULT')
		)
BEGIN
	BEGIN TRANSACTION

	ALTER TABLE dbo.CTRL_CHECK_RESULT

	DROP CONSTRAINT CTRL_CHECK_RESULT_PK
	WITH (ONLINE = OFF)

	ALTER TABLE dbo.CTRL_CHECK_RESULT ADD CONSTRAINT CTRL_CHECK_RESULT_PK PRIMARY KEY CLUSTERED (
		CTRL_CHECK_RESULT_KEY ASC,
		RUN_DATE ASC
		)
		WITH (
				PAD_INDEX = OFF,
				STATISTICS_NORECOMPUTE = OFF,
				SORT_IN_TEMPDB = ON,
				IGNORE_DUP_KEY = OFF,
				ONLINE = OFF,
				ALLOW_ROW_LOCKS = ON,
				MAXDOP = 16,
				ALLOW_PAGE_LOCKS = ON
				) ON p_sch_ctrl_load_data(RUN_DATE)

	COMMIT TRANSACTION
END

---- This is for DI_VALIDATION table
IF NOT EXISTS (
		SELECT ps.Name PartitionScheme,
			pf.name PartitionFunction,
			object_name(i.object_id) table_name
		FROM sys.indexes i
		JOIN sys.partition_schemes ps ON ps.data_space_id = i.data_space_id
		JOIN sys.partition_functions pf ON pf.function_id = ps.function_id
		WHERE i.object_id = object_id('DI_VALIDATION')
		)
BEGIN
	BEGIN TRANSACTION

	IF NOT EXISTS (
			SELECT NAME
			FROM sys.indexes
			WHERE NAME = N'DI_VALIDATION_UK'
			)
	BEGIN
		CREATE CLUSTERED INDEX DI_VALIDATION_UK ON dbo.DI_VALIDATION (Load_ID)
			WITH (
					PAD_INDEX = OFF,
					STATISTICS_NORECOMPUTE = OFF,
					SORT_IN_TEMPDB = ON,
					IGNORE_DUP_KEY = OFF,
					ONLINE = OFF,
					ALLOW_ROW_LOCKS = ON,
					MAXDOP = 16,
					ALLOW_PAGE_LOCKS = ON
					) ON p_sch_ctrl_load_id_data(load_id)

		DROP INDEX DI_VALIDATION_UK ON dbo.DI_Validation
	END

	COMMIT TRANSACTION
END

----------------------------------------------------------------------
-- Compress old Partitions
IF NOT EXISTS (
		SELECT *
		FROM sys.partitions p
		INNER JOIN sys.objects o ON p.object_id = o.object_id
		WHERE p.data_compression > 0
			AND OBJECT_NAME(o.object_id) = 'CTRL_LOAD_MANAGEMENT'
		)
	ALTER TABLE dbo.CTRL_Load_Management REBUILD PARTITION = 1
		WITH (DATA_COMPRESSION = PAGE)

ALTER TABLE dbo.CTRL_Load_Management REBUILD PARTITION = 2
	WITH (DATA_COMPRESSION = NONE)
GO

IF NOT EXISTS (
		SELECT *
		FROM sys.partitions p
		INNER JOIN sys.objects o ON p.object_id = o.object_id
		WHERE p.data_compression > 0
			AND OBJECT_NAME(o.object_id) = 'CTRL_LOAD_MANAGEMENT'
		)
	ALTER TABLE dbo.CTRL_Load_Management REBUILD PARTITION = 1
		WITH (DATA_COMPRESSION = PAGE)

ALTER TABLE dbo.CTRL_Load_Management REBUILD PARTITION = 2
	WITH (DATA_COMPRESSION = NONE)
GO

IF NOT EXISTS (
		SELECT *
		FROM sys.partitions p
		INNER JOIN sys.objects o ON p.object_id = o.object_id
		WHERE p.data_compression > 0
			AND OBJECT_NAME(o.object_id) = 'CTRL_CHECK_RESULT'
		)
	ALTER TABLE dbo.CTRL_CHECK_RESULT REBUILD PARTITION = 1
		WITH (DATA_COMPRESSION = PAGE)

ALTER TABLE dbo.CTRL_CHECK_RESULT REBUILD PARTITION = 2
	WITH (DATA_COMPRESSION = NONE)
GO

IF NOT EXISTS (
		SELECT *
		FROM sys.partitions p
		INNER JOIN sys.objects o ON p.object_id = o.object_id
		WHERE p.data_compression > 0
			AND OBJECT_NAME(o.object_id) = 'CTRL_LOAD_MESSAGE'
		)
	ALTER TABLE dbo.CTRL_LOAD_MESSAGE REBUILD PARTITION = 1
		WITH (DATA_COMPRESSION = PAGE)

ALTER TABLE dbo.CTRL_LOAD_MESSAGE REBUILD PARTITION = 2
	WITH (DATA_COMPRESSION = NONE)
GO

IF NOT EXISTS (
		SELECT *
		FROM sys.partitions p
		INNER JOIN sys.objects o ON p.object_id = o.object_id
		WHERE p.data_compression > 0
			AND OBJECT_NAME(o.object_id) = 'DI_VALIDATION'
		)
	ALTER TABLE dbo.DI_VALIDATION REBUILD PARTITION = 1
		WITH (DATA_COMPRESSION = PAGE)

ALTER TABLE dbo.DI_VALIDATION REBUILD PARTITION = 2
	WITH (DATA_COMPRESSION = NONE)
GO


