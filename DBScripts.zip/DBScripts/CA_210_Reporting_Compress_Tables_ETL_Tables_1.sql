--***********************************************************************************************
-- Script Name :  CA_210_Reporting_Compress_Tables_ETL_Tables_1.sql

-- Description:   Script to compress existing tables to reduce IO
                
-- Modification Log:
-- Version 1.0.0                    <Dushyant S>                 05/11/2019             Initial version.
-- ************************************************************************************************************************************************************************************

USE $(REPORTING_DB)

GO

IF NOT EXISTS (
		SELECT *
		FROM sys.partitions p
		INNER JOIN sys.objects o ON p.object_id = o.object_id
		WHERE p.data_compression > 0
			AND OBJECT_NAME(o.object_id) = 'TMP_REP_LANDED_INW_USM'
		)
	ALTER TABLE dbo.TMP_REP_LANDED_INW_USM REBUILD PARTITION = ALL
		WITH (DATA_COMPRESSION = PAGE)
GO

IF NOT EXISTS (
		SELECT *
		FROM sys.partitions p
		INNER JOIN sys.objects o ON p.object_id = o.object_id
		WHERE p.data_compression > 0
			AND OBJECT_NAME(o.object_id) = 'TMP_REP_LANDED_Inw_Claim_Movement_Delta'
		)
	ALTER TABLE dbo.TMP_REP_LANDED_Inw_Claim_Movement_Delta REBUILD PARTITION = ALL
		WITH (DATA_COMPRESSION = PAGE)
GO

IF NOT EXISTS (
		SELECT *
		FROM sys.partitions p
		INNER JOIN sys.objects o ON p.object_id = o.object_id
		WHERE p.data_compression > 0
			AND OBJECT_NAME(o.object_id) = 'TMP_REP_LANDED_Lrc_Ltf_Item_Allocation_Outw'
		)
	ALTER TABLE dbo.TMP_REP_LANDED_Lrc_Ltf_Item_Allocation_Outw REBUILD PARTITION = ALL
		WITH (DATA_COMPRESSION = PAGE)
GO

