select top 1000 * from KDR..CTRL_Load_Management order by 1 desc
--select top 100 * from KDR..CTRL_Load_Management where convert(date,Load_Start) = '2020-02-01' order by 1 desc

use DS_LOCAL_REPOS_PROD
SELECT AL_LANG.NAME, 
       AL_HISTORY.START_TIME, 
       AL_HISTORY.END_TIME, 
       AL_HISTORY.EXECUTION_TIME, 
       ObjName.VALUE as Object_Name, 
       ObjType.VALUE as Object_Type, 
       cast(ExecTime.VALUE as numeric(10,0)) as Object_Execution_Time 
FROM AL_LANG 
     JOIN AL_HISTORY 
        ON (AL_HISTORY.INST_EXEC_KEY = AL_LANG.OBJECT_KEY) 
     JOIN AL_STATISTICS ExecTime 
        ON (ExecTime.OBJECT_KEY = AL_HISTORY.OBJECT_KEY AND 
            ExecTime.NAME       = 'EXECUTION_TIME') 
     JOIN AL_STATISTICS ObjType 
        ON (ObjType.OBJECT_KEY = ExecTime.OBJECT_KEY AND 
            ObjType.KEY2       = ExecTime.KEY2       AND 
            ObjType.NAME       = 'OBJECT_TYPE'       AND 
            ObjType.VALUE     IN ('Dataflow')) 
     JOIN AL_STATISTICS ObjName 
        ON (ObjName.OBJECT_KEY = ExecTime.OBJECT_KEY AND 
            ObjName.KEY2       = ExecTime.KEY2       AND 
            ObjName.NAME       = 'OBJECT_NAME') 
WHERE AL_LANG.NAME = 'JOB_REP_20_Publish_Dimensions' 
  AND AL_LANG.OBJECT_TYPE = 0 -- To help use the index and narrow the scope 
  --AND AL_HISTORY.OBJECT_KEY = (SELECT MAX(SUBQ.OBJECT_KEY) 
  --                             FROM AL_HISTORY SUBQ 
  --                             WHERE SUBQ.INST_EXEC_KEY = AL_LANG.OBJECT_KEY 
  --                               and has_error = 0  and status = 'D' AND END_TIME IS NOT NULL) 
  --AND AL_LANG.VERSION = (select max(subq.version) 
  --                       from AL_LANG subq 
  --                       where subq.OBJECT_TYPE = AL_LANG.OBJECT_TYPE 
  --                         and subq.GUID        = AL_LANG.GUID) 
  --and convert(date, AL_HISTORY.START_TIME) = '2020-02-01'
  and AL_HISTORY.START_TIME = '2020-02-01 05:58:02'
ORDER BY cast(ExecTime.VALUE as numeric(10,0)) DESC;


select * from AL_STATISTICS where Name = 'Execution Time' and OBJECT_KEY in (767697,767708,767721,767750,767765,767794,767808,
767823,767835 )
select * from AL_HISTORY where INST_EXEC_KEY = 20246 and convert(date, start_time) = '2020-02-03' and INST_MACHINE = 'UK1-APP-DSJ-P03'
select * from AL_LANG where NAME = 'JOB_REP_05_Land_KDR_For_Reporting'