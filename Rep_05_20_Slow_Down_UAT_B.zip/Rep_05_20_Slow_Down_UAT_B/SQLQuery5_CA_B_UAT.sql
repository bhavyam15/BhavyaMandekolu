use msdb
select top 1 * from restorehistory where destination_database_name = 'DS_LOCAL_REPOS_CA_UAT' order by 1 desc
select top 1 * from restorehistory where destination_database_name = 'DS_LOCAL_REPOS_CA_B_UAT' order by 1 desc

use DS_LOCAL_REPOS_CA_B_UAT
SELECT AL_LANG.NAME, 
       AL_HISTORY.START_TIME, 
       AL_HISTORY.END_TIME, 
       AL_HISTORY.EXECUTION_TIME, 
       ObjName.VALUE as Object_Name, 
       ObjType.VALUE as Object_Type, 
       cast(ExecTime.VALUE as numeric(10,0)) as Object_Execution_Time 
FROM AL_LANG 
     JOIN AL_HISTORY 
        ON (AL_HISTORY.INST_EXEC_KEY = AL_LANG.OBJECT_KEY) 
     JOIN AL_STATISTICS ExecTime 
        ON (ExecTime.OBJECT_KEY = AL_HISTORY.OBJECT_KEY AND 
            ExecTime.NAME       = 'EXECUTION_TIME') 
     JOIN AL_STATISTICS ObjType 
        ON (ObjType.OBJECT_KEY = ExecTime.OBJECT_KEY AND 
            ObjType.KEY2       = ExecTime.KEY2       AND 
            ObjType.NAME       = 'OBJECT_TYPE'       AND 
            ObjType.VALUE     IN ('Dataflow')) 
     JOIN AL_STATISTICS ObjName 
        ON (ObjName.OBJECT_KEY = ExecTime.OBJECT_KEY AND 
            ObjName.KEY2       = ExecTime.KEY2       AND 
            ObjName.NAME       = 'OBJECT_NAME') 
WHERE AL_LANG.NAME = 'JOB_REP_05_Land_KDR_For_Reporting' 
  AND AL_LANG.OBJECT_TYPE = 0 -- To help use the index and narrow the scope 
  --AND AL_HISTORY.OBJECT_KEY = (SELECT MAX(SUBQ.OBJECT_KEY) 
  --                             FROM AL_HISTORY SUBQ 
  --                             WHERE SUBQ.INST_EXEC_KEY = AL_LANG.OBJECT_KEY 
  --                               and has_error = 0  and status = 'D' AND END_TIME IS NOT NULL) 
  --AND AL_LANG.VERSION = (select max(subq.version) 
  --                       from AL_LANG subq 
  --                       where subq.OBJECT_TYPE = AL_LANG.OBJECT_TYPE 
  --                         and subq.GUID        = AL_LANG.GUID) 
--ORDER BY cast(ExecTime.VALUE as numeric(10,0)) DESC;
and   convert(date, AL_HISTORY.START_TIME) ='2020-02-06'-- 02:11:06'
order by ObjName.VALUE

select * from CA_UAT_B_KDR..Ctrl_Load_Management where job_name  = 'JOB_KDR_10_Land_And_Unload_Eclipse' order by 1 desc
select * from DS_LOCAL_REPOS_CA_B_UAT..AL_HISTORY where Service = 'JOB_REP_05_Land_KDR_For_Reporting' order by Start_Time desc

use [CA_UAT_B_Reporting]
select count(*) from RTL_DIM_INW_CLAIM
select count(*) from RTL_DIM_INW_SYNDICATE_CONTRACT
select count(*) from RTL_DIM_CESSION
select count(*) from RTL_DIM_ACTUAL_INW_CLAIM
select count(*) from RTL_DIM_INW_CLAIM_MOVEMENT
select count(*) from RTL_DIM_INW_SYNDICATE_CONTRACT_SNAPSHOT
select count(*) from RTL_DIM_INW_SYNDICATE_CONTRACT_RISK_CODE
select count(*) from RTL_DIM_INW_SYNDICATE_ORIGINAL_PREMIUM
select count(*) from RTL_DIM_REINSURER_CONTRACT
select count(*) from RTL_DIM_REINSURER
select count(*) from RTL_DIM_MAPPED_SII_LOB
select count(*) from RTL_DIM_SUB_PILLAR
--UWD Copyback:
RTL_DIM_INW_SYNDICATE_ORIGINAL_PREMIUM
RTL_DIM_SUB_PILLAR


--List of the tables added as a part of CA
DIM_SUB_PILLAR
DIM_REINSURER_CONTRACT
DIM_REINSURER
DIM_MAPPED_SII_LOB
DIM_SYNDICATE_OWNERSHIP_CALCULATIONS
------------------------------------------------------------------
use DS_LOCAL_REPOS_CA_UAT
SELECT AL_LANG.NAME, 
       AL_HISTORY.START_TIME, 
       AL_HISTORY.END_TIME, 
       AL_HISTORY.EXECUTION_TIME, 
       ObjName.VALUE as Object_Name, 
       ObjType.VALUE as Object_Type, 
       cast(ExecTime.VALUE as numeric(10,0)) as Object_Execution_Time 
FROM AL_LANG 
     JOIN AL_HISTORY 
        ON (AL_HISTORY.INST_EXEC_KEY = AL_LANG.OBJECT_KEY) 
     JOIN AL_STATISTICS ExecTime 
        ON (ExecTime.OBJECT_KEY = AL_HISTORY.OBJECT_KEY AND 
            ExecTime.NAME       = 'EXECUTION_TIME') 
     JOIN AL_STATISTICS ObjType 
        ON (ObjType.OBJECT_KEY = ExecTime.OBJECT_KEY AND 
            ObjType.KEY2       = ExecTime.KEY2       AND 
            ObjType.NAME       = 'OBJECT_TYPE'       AND 
            ObjType.VALUE     IN ('Dataflow')) 
     JOIN AL_STATISTICS ObjName 
        ON (ObjName.OBJECT_KEY = ExecTime.OBJECT_KEY AND 
            ObjName.KEY2       = ExecTime.KEY2       AND 
            ObjName.NAME       = 'OBJECT_NAME') 
WHERE AL_LANG.NAME = 'JOB_REP_05_Land_KDR_For_Reporting' 
  AND AL_LANG.OBJECT_TYPE = 0 -- To help use the index and narrow the scope 
  --AND AL_HISTORY.OBJECT_KEY = (SELECT MAX(SUBQ.OBJECT_KEY) 
  --                             FROM AL_HISTORY SUBQ 
  --                             WHERE SUBQ.INST_EXEC_KEY = AL_LANG.OBJECT_KEY 
  --                               and has_error = 0  and status = 'D' AND END_TIME IS NOT NULL) 
  --AND AL_LANG.VERSION = (select max(subq.version) 
  --                       from AL_LANG subq 
  --                       where subq.OBJECT_TYPE = AL_LANG.OBJECT_TYPE 
  --                         and subq.GUID        = AL_LANG.GUID) 
--ORDER BY cast(ExecTime.VALUE as numeric(10,0)) DESC;
and   convert(date, AL_HISTORY.START_TIME) ='2020-02-06'
order by ObjName.VALUE
