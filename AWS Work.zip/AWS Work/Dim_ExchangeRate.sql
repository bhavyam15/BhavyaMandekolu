select 
/* Business Key */
cc_exchangerate.ID ExchangeRateID,
/* Dimension Attributes */
basecur.L_en_GB FromCurrency,
basecur.DESCRIPTION FromCurrencyDescription,
pricecur.L_en_GB toCurrency,
pricecur.DESCRIPTION toCurrencyDescription,
cc_exchangerate.NormalizedRate,
cc_exchangerate.NormalizedRate_TMK,
cc_exchangerate.CreateTime,
cc_exchangerate.UpdateTime
from cc_exchangerate
left outer join cctl_currency pricecur on pricecur.ID = cc_exchangerate.PriceCurrency
left outer join cctl_currency basecur on basecur.ID = cc_exchangerate.BaseCurrency
where basecur.L_en_GB = 'GBP'
order by 2 desc