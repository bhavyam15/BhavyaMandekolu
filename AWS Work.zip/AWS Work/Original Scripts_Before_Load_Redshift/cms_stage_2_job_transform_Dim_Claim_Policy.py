###########################################################
#   Job Name    : cms_stage_2_job_transform_Dim_Claim_Policy.py
#   Description : This job will transform the data from Landing into a S3 bucket 'Transformations' folder for a given day

#   Version no  |   Date Modified  | Comment     
#       0.1     |     29/03/19     | Initial Version
#
###########################################################

import sys
import datetime
import config
import cms_function
from awsglue.job import Job
from pyspark.sql.types import *
from awsglue.utils import getResolvedOptions

job = Job(cms_function.glueContext)
args = getResolvedOptions(sys.argv, ['JOB_NAME'])
job.init(args['JOB_NAME'], args)

jobnam = args['JOB_NAME']
job_run_id = args['JOB_RUN_ID']

#Assign variables from Config File
s3_bucket_name = config.s3_bucket_name
transformation_path  = config.transformation_path 
started = config.started
failure = config.failure
completed = config.completed
s3_file_format = config.s3_file_format
s3_file_compression = config.s3_file_compression
sql_code_path =config.sql_code_path
sql_path = "s3://"+s3_bucket_name+"/"+sql_code_path+"/"
load_incremental = config.load_incremental
offset_required_no  = config.offset_required_no

try:
    sql_file ="Dim_Claim_Policy.sql"
    
    table_name ="Dim_Claim_Policy_rtl"
    view_name = sql_file[:-4] 
    
    ######## This table is an incremental loading ########
    
    delta_column_name="Policy_ReposId"
    
    #Check for the current job run status
    val = cms_function.job_status(jobnam)
    if val == 1:
        cms_function.log_message (jobnam,"Error","Job is currently in progress.Refer ctrl_load_mangement for error details", "Operational_Check_Job_Run", "","Redshift Control Load Management", "Glue")
        raise cms_function.exception_job_status ("Job is already in progress.Exiting the current session")
    mess = "Call to job_status function is succeeded.No current job is in progress.Loading of "+table_name+" dimension table has started"
    cms_function.log_message (jobnam,"Info",mess, "Operational_Check_Job_Run", "","Redshift Control Load Management", "Glue")
    
    
    #Insert into the ctrl_load_mangement table with a start message
    mess = "Loading of "+table_name+" dimension table has started"
    audit_tab = cms_function.UPDATE_AUDIT_TABLE(jobnam, mess,  started,'','')
    if len(audit_tab) > 1:
        cms_function.log_message (jobnam,"Error","Call to the UPDATE_AUDIT_TABLE function failed while updating the 'STARTED' status", "Operational_Load_Ctrl_Load_Mangement", "", "Glue", "Redshift Control Load Management")
        error_mess = "Call to the UPDATE_AUDIT_TABLE function failed while updating the 'STARTED' status with the error "+audit_tab  
        raise  cms_function.exception_audit_table(error_mess)
    cms_function.log_message (jobnam,"Info","Call to the UPDATE_AUDIT_TABLE function is succeeded with the status updated as 'STARTED'", "Operational_Load_Ctrl_Load_Mangement", "", "Glue", "Redshift Control Load Management")
    
    
    #Checking for the .sql file availability
    try:
        val = "Checking for the "+sql_file+" file availability in S3 - "+sql_path
        cms_function.log_message (jobnam,"Info",val, "Operational_Check_S3_SQL_File", "", "S3", "Glue")
        print "Checking for the availability of "+sql_file+" in sql_code_path"
        sql_file_value = cms_function.sc.textFile(sql_path).collect()
        print sql_file+" file has been read"
        val = sql_file+" file is available  in S3 - "+sql_path
        cms_function.log_message (jobnam,"Info",val, "Operational_Check_S3_SQL_File", "", "S3", "Glue")
    except:
        val =  sql_file +" unavailable in the S3 path " +sql_path
        cms_function.log_message (jobnam,"Error",val, "Operational_Check_S3_SQL_File", "", "S3", "Glue")
        error_mess = sql_file +" unavailable in the S3 path " +sql_path
        raise cms_function.exception_others(error_mess)  
    
    
    #Temp view creation for all stage tables	
    cms_function.log_message (jobnam,"Info","Create temp views for all the staging tables", "Operational_Temp_View_Creation", "", "S3", "Glue")
    print " Create temp views for all the staging tables"
    view_creation = cms_function.call_create_views()
    if view_creation != 1:
        cms_function.log_message (jobnam,"Error","Temp view creation failed.Refer ctrl_load_mangement for error details", "Operational_Temp_View_Creation", "", "S3", "Glue")
        error_mess = "Unexpected error.Temp view creation failed"  
        raise  cms_function.exception_others(error_mess)
    print "Views are created for all staging tables"
    cms_function.log_message (jobnam,"Info","Call to call_create_views function is succeeded. Views are created for all staging tables", "Operational_Temp_View_Creation", "", "S3", "Glue")
    
    

    #Get the Delta key for the table
    val = " Get the latest Delta key for the "+table_name
    cms_function.log_message (jobnam,"Info",val, "Functional_Get_Delta_Key_Offset", "", "Redshift", "Glue")
    delta_max_key = cms_function.get_max_dim_key(table_name,delta_column_name)
    val = "Call to get_max_dim_key is succeeded. Latest key retreived for the table "+table_name+ " from the column "+delta_column_name+" is "+str(delta_max_key)
    cms_function.log_message (jobnam,"Info",val, "Functional_Get_Delta_Key_Offset", "", "Redshift", "Glue") 
    
    
    #Reading the SQL file and creating a temp view
    val= " Reading the "+sql_file+" as a wholetextfile"
    cms_function.log_message (jobnam,"Info",val, "Functional_"+sql_file, sql_file, "S3", "Glue String")
    sql_query = cms_function.transform_sql_file_2_string(sql_path ,sql_file )
    val = "Call to transform_sql_file_2_string function is succeeded. SQL Query retrieved : " + sql_query
    cms_function.log_message (jobnam,"Info",val, "Functional_"+sql_file, sql_query, "S3", "Glue DF")
    
    sql_query_delta = sql_query.format(delta_max_key)
    val = "SQL Delta query updated. SQL Query: " + sql_query_delta
    cms_function.log_message (jobnam,"Info",val, "Functional_"+sql_file, sql_query_delta, "S3", "Glue DF")
    
    sql_execute =cms_function.spark.sql(sql_query_delta)
    val = "Create a view "+view_name+" for the SQL query in "+ sql_file
    cms_function.log_message (jobnam,"Info",val, "Functional_"+sql_file+"Create_View", "", "S3", "Glue TempView")
    sql_execute.createOrReplaceTempView(view_name)
    print "View created : ", view_name
    
    
    
    #Populate the audit columns
    val = "Populate the audit columns as a SQL wrapper for the view "+view_name
    cms_function.log_message (jobnam,"Info",val, "Operational_Wrap_Audit_Columns", "", "Glue String", "Glue String")
    print "Populate the audit columns"
    sql_output = cms_function.populate_audit_columns(view_name,'','',load_incremental,offset_required_no)
    print "SQL Output for " +table_name 
    print str(sql_output)
    val = "Call to populate_audit_columns function is succeeded. SQL query retrieved : "+ str(sql_output)
    cms_function.log_message (jobnam,"Info",val, "Operational_Wrap_Audit_Columns", "", "Glue String", "Glue String")
    
    
    #Execute the SQL as a whole
    cms_function.log_message (jobnam,"Info","Create a dataframe for the sql query", "Functional_Execute_SQL", sql_output, "Glue String", "Glue DF")
    print "Create a dataframe for the sql query"
    sql_execute =cms_function.spark.sql(sql_output)
    cnt = cms_function.get_record_count(sql_execute)
    print "Number of records :", cnt
    
    
    
    #Writing the file into S3
    val = "Writing the dataframe into S3. Number of records : "+ str(cnt)
    cms_function.log_message (jobnam,"Info",val, "Functional_Write_DF_To_S3", "", "Glue DF", "S3")
    print "Writing the records into S3"
    sql_execute.write.format(s3_file_format).mode("overwrite").option("compression",s3_file_compression).save("s3a://"+s3_bucket_name+"/"+transformation_path+ "/" + table_name + "/")
    print table_name+ " is successfully written in S3"
    val ="Dataframe is successfully inserted into S3 path s3a://"+s3_bucket_name+"/"+transformation_path+ "/" + table_name + "/"
    cms_function.log_message (jobnam,"Info",val, "Functional_Write_DF_To_S3", "", "Glue DF", "S3")
    
    
    
    #Writing the reconciliation details into S3
    cms_function.log_message (jobnam,"Info","Writing the reconciliation details into S3 in append mode", "Reconciliation", "", "Glue DF", "S3")
    cms_function.recon_check(jobnam,table_name,cnt,'','',load_incremental,delta_column_name,delta_max_key)
    cms_function.log_message (jobnam,"Info","Call to recon_check function is completed ", "Reconciliation", "", "Glue DF", "S3")
    
    
    
    #Insert into the ctrl_load_mangement table with a success message
    mess = "Loading of "+table_name+" dimension table is completed"
    audit_tab = cms_function.UPDATE_AUDIT_TABLE(jobnam, mess,  completed,'','') 
    if len(audit_tab) > 1:
        cms_function.log_message (jobnam,"Error","Call to the UPDATE_AUDIT_TABLE function failed while updating the 'COMPLETED' status", "Operational_Load_Ctrl_Load_Mangement", "", "Glue", "Redshift Control Load Management")
        error_mess = "Call to the UPDATE_AUDIT_TABLE function failed while updating the 'COMPLETED' status with the error "+audit_tab  
        raise  cms_function.exception_audit_table(error_mess)
    cms_function.log_message (jobnam,"Info","Call to the UPDATE_AUDIT_TABLE function is succeeded with the status updated as 'COMPLETED'", "Operational_Load_Ctrl_Load_Mangement", "", "Glue", "Redshift Control Load Management")    
        

except (cms_function.exception_job_status,cms_function.exception_audit_table) as error:
    print " Error - Job status/Audit Table"
    print jobnam+" is exiting."
    print "Error message : " , error

except cms_function.exception_others as error:
    print "Error - File/View unavailability ", error
    Error_code = 'File/View unavailability' 
    Error_Message= error_mess
    cms_function.UPDATE_AUDIT_TABLE(jobnam, 'Failed with exception', failure,Error_code,Error_Message)

except:
    print "Error - others"
    Error_code = str(sys.exc_info()[0] ) 
    def_Error_Mess= str(sys.exc_info()[1] )
    Error_Message = def_Error_Mess[0:6000]
    val = jobnam+" has failed with the exception "+ Error_code+ " Refer ctrl_load_mangement for error details"
    cms_function.log_message (jobnam,"Error",val, "Operational_Load_Ctrl_Load_Mangement", "", "Glue", "Redshift Control Load Management")  
    cms_function.UPDATE_AUDIT_TABLE(jobnam, 'Failed with exception',  failure,Error_code,Error_Message)
    
job.commit()