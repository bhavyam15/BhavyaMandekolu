select 
cc_claimcontact.ClaimID,
c.ID  ContactID,
/* Business Key */
cc_claimcontact.ClaimID Claim_ReposId,
c.ID  Contact_ReposId,
/* Business Key */
/* Dimension Attributes */
c.NameDenorm,
c.VendorApprovalAssignment_TMK typelist_approvalassignment_id,
cctl_vendorcontactapprovalassignment_tmk.L_en_GB Approvassignment,
cctl_country.id typelist_Country_id,
cctl_country.L_en_GB Country,
cc_address.AddressLine1,
cc_address.AddressLine2,
cc_address.AddressLine3,
cc_address.CityDenorm Town,
cc_address.PostalCodeDenorm PostalCode,
cctl_addresstype.L_en_GB Addresstype,
cc_address.Description Location_Description,
cc_address.ValidUntil ValidUntil,
cctl_currency.ID typelist_Prefered_Currency_id,
cctl_currency.L_en_GB Prefered_Currency,
(select relatedcontact.Name
from 
cc_contactcontact, cc_contact relatedcontact , cctl_contactrel where relatedcontact.ID = cc_contactcontact.SourceContactID
and relatedcontact.id = cc_contactcontact.RelatedContactID
and cctl_contactrel.ID = cc_contactcontact.Relationship and cctl_contactrel.L_en_GB = 'Primary Contact') Primary_Contact,
c.WorkPhone Work,
c.FaxPhone Fax,
c.EmailAddress1 Main_Email,
c.EmailAddress2 Alternate_Email,
c.TaxID,
c.Notes,
case when cc_claimcontact.ContactProhibited = 1 then 'Yes' else 'No' end  ContactProhibited,
cc_address.CityDenorm,
cc_address.State
/* Dimension Attributes */
from 
cc_claim
left outer join cc_claimcontact on cc_claimcontact.ClaimID = cc_claim.ID
left outer join cc_contact c on cc_claimcontact.ContactID = c.ID
left outer join cctl_vendorcontactapprovalassignment_tmk on cctl_vendorcontactapprovalassignment_tmk.ID = c.VendorApprovalAssignment_TMK
left outer join cc_address on cc_address.ID = c.PrimaryAddressID
left outer join cctl_country on cc_address.Country = cctl_country.ID
left outer join cctl_addresstype on cc_address.AddressType = cctl_addresstype.ID 
left outer join cctl_currency on c.PreferredCurrency = cctl_currency.ID
where c.ID is not null 
