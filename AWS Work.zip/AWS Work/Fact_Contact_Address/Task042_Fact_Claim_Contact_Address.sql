drop table #Fact_Claim_Contact_Address
-- Fact_Claim_Contact_Address
select
cc_claimcontact.ClaimID,
cc_contactaddress.ContactID,
cc_address.ID AddressID,
/* Lookup Dim_Claim  */
cc_claimcontact.ClaimID Claim_ReposId,
/* Lookup Dim_Contact  */
cc_contactaddress.contactid Contact_ReposId,
/* Lookup Dim_Address */
cc_address.ID Address_ReposId
into
#Fact_Claim_Contact_Address
from 
cc_address 
left outer join cc_contactaddress on cc_contactaddress.AddressID = cc_address.ID
left outer join cc_contact on cc_contact.id = cc_contactaddress.contactid
left outer join cc_claimcontact on cc_claimcontact.ContactID = cc_contact.ID
left outer join cctl_country on  cc_address.Country = cctl_country.ID
left outer join cctl_addresstype on  cc_address.Subtype = cctl_addresstype.ID
where 
cc_claimcontact.ClaimID is not null 
and cc_contactaddress.contactid is not null 

create table Fact_Claim_Contact_Address 
(
	ClaimID bigint,
	ContactID bigint,
	AddressID bigint,
	/*Claim_ReposId*/ Dim_Claim_Key_FK bigint,
	/*Contact_ReposId*/ Dim_Contact_Key_FK bigint,
	/*Address_ReposId*/ Dim_Address_Key_FK bigint,
/* Fact Audit Columns */
	Load_id						   int,
	Dim_Period_key				   int,
	Inserted_dt					   datetime,
	Updated_dt				       datetime
)  
use tempdb
select COLUMN_NAME+' '+DATA_TYPE+isnull('('+cast (CHARACTER_MAXIMUM_LENGTH as varchar)+')','')+',' 
from Information_schema.columns where Table_name like '#Fact_Claim_Contact_Address%'

-- Script for creating TestData for BO

declare @v_Load_id int = dbo.fn_Get_LoadId(); 
declare @v_Dim_Period_Key int = dbo.fn_Get_Dim_Period_Key();



insert into Fact_Claim_Contact_Address
select 
	ClaimID ,
	ContactID ,
	AddressID ,
(
select 
Dim_Contact_Key
from Dim_Contact
where Contact_ReposId = #Fact_Claim_Contact_Address.Contact_ReposId
and Dim_period_key = @v_Dim_Period_Key
) Dim_Contact_Key_FK,
(
select 
Dim_claim_Key
from Dim_Claim
where Claim_ReposID = #Fact_Claim_Contact_Address.Claim_ReposID
and Dim_period_key = @v_Dim_Period_Key
) Dim_Claim_Key_FK,
(
select 
Dim_Address_Key
from Dim_Address
where Address_ReposId = #Fact_Claim_Contact_Address.Address_ReposId
and Dim_period_key = @v_Dim_Period_Key
) Dim_Address_Key_FK,
--	/*Claim_ReposId*/ dbo.fn_get_Dim_Key('Dim_Claim_RTL',#Fact_Claim_Contact_Address.Claim_ReposID,@v_Dim_Period_Key) Dim_Claim_Key_FK ,
--	/*Contact_ReposId*/ dbo.fn_get_Dim_Key('Dim_Contact_RTL',#Fact_Claim_Contact_Address.Contact_ReposId,@v_Dim_Period_Key) Dim_Contact_Key_FK ,
--	/*Address_ReposId*/ dbo.fn_get_Dim_Key('Dim_Address_RTL',#Fact_Claim_Contact_Address.Address_ReposId,@v_Dim_Period_Key) Dim_Address_Key_FK ,
	/* Dimension Audit Columns */
	@v_Load_id Load_id,
	@v_Dim_Period_Key Dim_Period_key,
	GETDATE() Inserted_dt,
	GETDATE() Updated_dt
from 
#Fact_Claim_Contact_Address 