select
cc_claimcontact.ClaimID,
cc_contactaddress.ContactID,
cc_address.ID AddressID,
/* Lookup Dim_Claim  */
cc_claimcontact.ClaimID Claim_ReposId,
/* Lookup Dim_Contact  */
cc_contactaddress.contactid Contact_ReposId,
/* Lookup Dim_Address */
cc_address.ID Address_ReposId
--into#Fact_Claim_Contact_Address
from 
cc_address 
left outer join cc_contactaddress on cc_contactaddress.AddressID = cc_address.ID
left outer join cc_contact on cc_contact.id = cc_contactaddress.contactid
left outer join cc_claimcontact on cc_claimcontact.ContactID = cc_contact.ID
left outer join cctl_country on  cc_address.Country = cctl_country.ID
left outer join cctl_addresstype on  cc_address.Subtype = cctl_addresstype.ID
where 
cc_claimcontact.ClaimID is not null 
and cc_contactaddress.contactid is not null