###########################################################
#   Job Name    : cms_stage_2_job_transform_Fact_Activity.py
#   Description : This job will transform the data from Landing into a S3 bucket 'Transformations' folder for a given day

#   Version no  |   Date Modified  | Comment     
#       0.1     |     08/04/19     | Initial Version
#
###########################################################

import sys
import datetime
import config
import cms_function_tran
from awsglue.job import Job
from pyspark.sql.types import *
from awsglue.utils import getResolvedOptions

job = Job(cms_function_tran.glueContext)
args = getResolvedOptions(sys.argv, ['JOB_NAME'])
job.init(args['JOB_NAME'], args)

jobnam = args['JOB_NAME']
job_run_id = args['JOB_RUN_ID']

#Initiaze the variables to be used in the function

load_type = config.load_complete
column_name = max_key = delta_column_name = delta_max_key = refer_table_list = refer_sql_query = sql_file = ''
failure = config.failure

try:
    load_type = config.load_incremental
    
    # Assign the sql files and place the files in the order it needs to be trigerred.
    sql_file = "Fact_Activity.sql"
       
    table_name ="Fact_Activity"
	
	refer_table_name1 = "Dim_Claim_rtl"	    
    refer_table_name2 = "Dim_Activity_rtl"
    refer_table_name3 = "Dim_Exposure_rtl"
    refer_table_name4 = "Dim_Matter_rtl"
    refer_table_name5 = "Dim_Contact_rtl"
	
	refer_sql_query = "select fct_activity.*, nvl(Dim_Claim.Dim_Claim_Key, 0) Dim_Claim_Key_FK, nvl(Dim_Activity.Dim_Activity_Key, 0) Dim_Activity_Key_FK , nvl(Dim_Exposure.Dim_Exposure_Key, 0) Dim_Exposure_Key_FK, nvl(Dim_Matter.Dim_Matter_Key,0) Dim_Matter_Key_FK, nvl(Dim_Contact.Dim_Contact_Key, 0) Dim_Contact_Key_FK from fact_activity fct_activity left outer join Dim_Claim_rtl Dim_Claim on Dim_Claim.Claim_ReposID = fct_activity.Claim_ReposID and Dim_Claim.Dim_period_key=fct_activity.Dim_period_key  left outer join Dim_Activity_rtl Dim_Activity on Dim_Activity.Activity_ReposID = fct_activity.Activity_ReposID and Dim_Activity.Dim_period_key=fct_activity.Dim_period_key left outer join Dim_Exposure_rtl Dim_Exposure on Dim_Exposure.Exposure_ReposID = fct_activity.Related_to_Exposure_ReposID and Dim_Exposure.Dim_period_key= fct_activity.Dim_period_key left outer join Dim_Matter_rtl Dim_Matter on Dim_Matter.Matter_ReposID = fct_activity.Related_to_Matter_ReposID  and Dim_Matter.Dim_period_key = fct_activity.Dim_period_key Left outer join Dim_Contact_rtl Dim_Contact on Dim_Contact.Contact_ReposID = fct_activity.Related_to_Contact_ReposID and  Dim_Contact.Dim_period_key = fct_activity.Dim_period_key"
    
    ##### This table has incremental load ########
    
    #delta_column_name ='Message_Last_Updated'
    
    view_name =  cms_function_tran.create_transformation_sql_views(jobnam,table_name,sql_file)
    if view_name == '1':
        raise cms_function_tran.exception_others("process failed while calling the create_transformation_sql_view function")
    
    #Get the delta date value for the table
    val = " Get the latest delta date value for the " + table_name
    cms_function_tran.log_message (jobnam,"Info",val, "Operational_Get_Surrogate_Key_Offset", "", "Redshift", "Glue")
    delta_max_key = cms_function_tran.get_max_dim_date(table_name,delta_column_name)
    val = "Call to get_max_dim_date is succeeded. Latest date value retreived for the table "+table_name+ " from the column "+delta_column_name+" is "+str(delta_max_key)
    cms_function_tran.log_message (jobnam,"Info",val, "Operational_Get_Surrogate_Key_Offset", "", "Redshift", "Glue")
    
    #Populate the audit columns
    val = "Populate the audit columns as a SQL wrapper for the view. This is an full load "+view_name
    cms_function_tran.log_message (jobnam,"Info",val, "Operational_Wrap_Audit_Columns", "", "Glue String", "Glue String")
    print "Populate the audit columns"
    sql_output = cms_function_tran.populate_audit_columns(view_name,delta_column_name,delta_max_key,load_type)
    print "SQL Output for " +table_name 
    print str(sql_output)
    val = "Call to populate_audit_columns function is succeeded. SQL query retrieved : "+ str(sql_output)
    cms_function_tran.log_message (jobnam,"Info",val, "Operational_Wrap_Audit_Columns", "", "Glue String", "Glue String")
    
    cms_function_tran.populate_transformation_redshift(jobnam,table_name,sql_output,column_name,max_key,load_type,delta_column_name,delta_max_key,refer_table_list,refer_sql_query,job_run_id)
    if view_name == '1':
        raise cms_function_tran.exception_others("process failed")
        
except cms_function_tran.exception_others as error:
    print "Process failed while calling the populate_transformation_redshift function"
   
except:
    print "Error - others"
    Error_code = str(sys.exc_info()[0] ) 
    def_Error_Mess= str(sys.exc_info()[1] )
    Error_Message = def_Error_Mess[0:6000]
    val = jobnam+" has failed with the exception "+ Error_code+ " Refer ctrl_load_mangement for error details"
    cms_function_tran.log_message (jobnam,"Error",val, "Operational_Load_Ctrl_Load_Mangement", "", "Glue", "Redshift Control Load Management")  
    cms_function_tran.UPDATE_AUDIT_TABLE(jobnam, 'Failed with exception',  failure,Error_code,Error_Message)
job_commit()


