###########################################################
#   Job Name    : cms_stage_2_job_transform_Dim_Contact_AC.py
#   Description : This job will transform the data from Landing into a S3 bucket 'Transformations' folder for a given day

#   Version no  |   Date Modified  | Comment     
#       0.1     |     29/03/19     | Initial Version
#
###########################################################

import sys
import datetime
import config
import cms_function_tran
from awsglue.job import Job
from pyspark.sql.types import *
from awsglue.utils import getResolvedOptions

job = Job(cms_function.glueContext)
args = getResolvedOptions(sys.argv, ['JOB_NAME'])
job.init(args['JOB_NAME'], args)

jobnam = args['JOB_NAME']
job_run_id = args['JOB_RUN_ID']

#Assign variables from Config File
# s3_bucket_name = config.s3_bucket_name
# transformation_path  = config.transformation_path 
# started = config.started
# failure = config.failure
# completed = config.completed
# s3_file_format = config.s3_file_format
# s3_file_compression = config.s3_file_compression
# sql_code_path =config.sql_code_path
# sql_path = "s3://"+s3_bucket_name+"/"+sql_code_path+"/"

#Initiaze the variables to be used in the function

load_type = config.load_complete
column_name = max_key = delta_column_name = delta_max_key = refer_table_list = refer_sql_query = sql_file = ''
failure = config.failure

try:
    #load_type = config.load_incremental
    
    # Assign the sql files and place the files in the order it needs to be trigerred.
	sql_file ="Dim_Contact.sql"
    #sql_file_list = ["CC_SCMFinancials_CC_SCMFinancials.sql","CC_SCMFinancials_Exchangerate.sql","CC_SCMFinancials_Original_FXRate.sql"]
       
    table_name ="Dim_Contact_rtl"
    ##############################################################
	 view_name =  cms_function_tran.create_transformation_sql_views(jobnam,table_name,sql_file)
    if view_name == '1':
        raise cms_function_tran.exception_others("process failed while calling the create_transformation_sql_view function")
    
    #Get the delta date value for the table
    # val = " Get the latest delta date value for the " + table_name
    # cms_function_tran.log_message (jobnam,"Info",val, "Operational_Get_Surrogate_Key_Offset", "", "Redshift", "Glue")
    # delta_max_key = cms_function_tran.get_max_dim_date(table_name,delta_column_name)
    # val = "Call to get_max_dim_date is succeeded. Latest date value retreived for the table "+table_name+ " from the column "+delta_column_name+" is "+str(delta_max_key)
    # cms_function_tran.log_message (jobnam,"Info",val, "Operational_Get_Surrogate_Key_Offset", "", "Redshift", "Glue")
    
    #Populate the audit columns
    val = "Populate the audit columns as a SQL wrapper for the view. This is an full load "+view_name
    cms_function_tran.log_message (jobnam,"Info",val, "Operational_Wrap_Audit_Columns", "", "Glue String", "Glue String")
    print "Populate the audit columns"
    sql_output = cms_function_tran.populate_audit_columns(view_name,delta_column_name,delta_max_key,load_type)
    print "SQL Output for " +table_name 
    print str(sql_output)
    val = "Call to populate_audit_columns function is succeeded. SQL query retrieved : "+ str(sql_output)
    cms_function_tran.log_message (jobnam,"Info",val, "Operational_Wrap_Audit_Columns", "", "Glue String", "Glue String")
    
    cms_function_tran.populate_transformation_redshift(jobnam,table_name,sql_output,column_name,max_key,load_type,delta_column_name,delta_max_key,refer_table_list,refer_sql_query,job_run_id)
    if view_name == '1':
        raise cms_function_tran.exception_others("process failed")
        
except cms_function_tran.exception_others as error:
    print "Process failed while calling the populate_transformation_redshift function"
   
except:
    print "Error - others"
    Error_code = str(sys.exc_info()[0] ) 
    def_Error_Mess= str(sys.exc_info()[1] )
    Error_Message = def_Error_Mess[0:6000]
    val = jobnam+" has failed with the exception "+ Error_code+ " Refer ctrl_load_mangement for error details"
    cms_function_tran.log_message (jobnam,"Error",val, "Operational_Load_Ctrl_Load_Mangement", "", "Glue", "Redshift Control Load Management")  
    cms_function_tran.UPDATE_AUDIT_TABLE(jobnam, 'Failed with exception',  failure,Error_code,Error_Message)
	#################################################################    
       
job.commit()