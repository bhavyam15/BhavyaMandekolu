select 
 cc_activity.ClaimID,
 cc_activity.ID ActivityID,
 cc_activity.ID Activity_ReposID,
/* Dimension Attributes */
 cc_exposure.OCR_Ext  +'-' +cc_exposure.PolicyLineReference_TMK Related_to_Exposures, 
 cc_matter.Name Related_to_Matter,
 relatedto.ContactNameDenorm Related_to_ClaimContact,
 'STAR' Star,
 case when cc_activity.Escalated = 1 then 'Yes' else 'No' end isthisactivityEscalated,
 TargetDate Duedate, 
 cctl_priority.ID typelist_Priority_ID,
 cctl_priority.L_en_GB Priority, 
 cctl_activitystatus.ID typelist_status_ID,
 cctl_activitystatus.L_en_GB Status ,
 cc_activity.Subject, 
 cc_exposure.OCR_Ext  +'-' +cc_exposure.PolicyLineReference_TMK Exposures, 
 case when cc_activity.ExternallyOwned =1 then 'Yes' else 'No' end Externally_Owned,
 c.NameDenorm  Ext_Owner,
  cc_contact.FirstName +' ' + cc_contact.LastName AssignedTo,
  obc.FirstName +' ' + obc.LastName AssignedBy,
  cc_activity.CreateTime Assigneddate,
  cc_activity.Description,
  cc_activity.EscalationDate Escalation_Date,
  cctl_importancelevel.L_en_GB Calendar_Importance,
  case when cc_activity.Mandatory = 1 then 'Yes' else 'No' end Mandatory,
  case when cc_activity.Recurring  = 1 then 'Yes' else 'No' end Recurring,
  cc_activity.CloseDate Completion_Skipped_date,
  cc.FirstName +' ' + cc.LastName Completed_by,
  cc_group.Name Assigned_Group,
  cc_activity.ECFActivityFlag_TMK,
  cctl_activitycategory_tmk.L_en_GB ActivityCategory,
  cc_activitypattern.Description ActivityPatternDescription,
  cctl_activitycategory.L_en_GB ActivityPatternCategory,
  ccx_lmmessage_ext.ID MessageID,
  ccx_lmmessage_ext.TR TransactionReference,
  cctl_ecfparticipantfunction_ext.L_en_GB Our_Role,
  cc_assignqueue.Name AssignedQueue
/* Dimension Attributes */
--into #Dim_Activity
from 
cc_claim 
left outer join cc_activity on cc_claim.id = cc_activity.Claimid
left outer join cctl_priority on cctl_priority.ID = cc_activity.Priority 
left outer join cctl_activitystatus on cctl_activitystatus.ID = cc_activity.Status
left outer join cc_exposure on cc_exposure.ID =  cc_activity.ExposureID
left outer join cc_policy on cc_claim.PolicyID = cc_policy.ID
left outer join cc_user on cc_user.id = cc_activity.AssignedUserID
left outer join cc_contact on cc_contact.id = cc_user.ContactID
left outer join cc_user obu on obu.id = cc_activity.AssignedByUserID
left outer join cc_contact obc on obc.id = obu.ContactID
left outer join cc_claimcontact on cc_claimcontact.ID = cc_activity.ExternalOwnerCCID
left outer join cc_contact c on c.id = cc_claimcontact.ContactID
left outer join cc_claimcontact relatedto on relatedto.id = cc_activity.ClaimContactID
left outer join cctl_importancelevel on cctl_importancelevel.ID = cc_activity.Importance
left outer join cc_user cl on cl.id = cc_activity.CloseUserID
left outer join cc_contact cc on cc.id = cl.ContactID
left outer join cc_group on cc_group.id = cc_activity.AssignedGroupID
left outer join cc_matter on cc_activity.MatterID = cc_matter.ID 
left outer join cctl_activitycategory_tmk on cc_activity.ActivityCategory_TMK = cctl_activitycategory_tmk.ID
left outer join cc_activitypattern  on cc_activity.ActivityPatternID = cc_activitypattern.ID
left outer join cctl_activitycategory on cc_activitypattern.Category = cctl_activitycategory.ID
left outer join ccx_lmmessage_ext on ccx_lmmessage_ext.ID = cc_activity.LMMessage_Ext
left outer join cctl_ecfparticipantfunction_ext on ccx_lmmessage_ext.Role = cctl_ecfparticipantfunction_ext.ID
left outer join cc_assignqueue on cc_activity.AssignedQueueID = cc_assignqueue.ID
where  cc_activity.ID is not null
--cc_claim.ClaimNumber  = 'TMK000000000002' 
--cc_claim.ID = 5829
