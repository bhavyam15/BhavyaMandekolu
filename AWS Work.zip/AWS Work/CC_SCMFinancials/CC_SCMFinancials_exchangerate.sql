select 
cc_exchangerate.ID ExchangeRateID,
pricecur.L_en_GB PriceCurrency,
basecur.L_en_GB BaseCurrency,
cc_exchangerate.NormalizedRate,
cc_exchangerate.NormalizedRate_TMK,
cc_exchangerate.CreateTime,
cc_exchangerate.UpdateTime
--into #exchangerate
from cc_exchangerate
left outer join cctl_currency pricecur on pricecur.ID = cc_exchangerate.PriceCurrency
left outer join cctl_currency basecur on basecur.ID = cc_exchangerate.BaseCurrency
order by 5 desc