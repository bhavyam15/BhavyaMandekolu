select 
cc_claim.id ClaimID,
cc_claim.ClaimNumber,
ccx_lmmessage_ext.id MessageID,
ccx_lmmessage_ext.MessageSequence,
ccx_lmmessage_ext.MessageType,
ccx_ecfmsgclaimnotrqfin_ext.ID ECFClaim_FInancialID,
ccx_lmmessage_ext.TR,
ccx_lmmessage_ext.UpdateTime,
substring(ReceiverPartyId,length(ReceiverPartyId)-3,length(ReceiverPartyId)) Current_Syndicate,
ccx_ecfmsgclaimnotrqfin_ext.OriginalSplitReferenceCSV_TMK Original_Signing_Number_and_Date,
cctl_ecfoutstandingqualifiercode_ext.L_en_GB Outstanding_Amount_Qualifier,
	incurredcurrency.L_en_GB Incurred_Original_Currency,
	ccx_ecfmsgclaimnotrqfin_ext.LossAndExpensesIncurred_amt Incurred_Amount_In_Original_Currency,
	outstandingcurrency.l_en_gb Outstanding_Original_Currency, 
	ccx_ecfmsgclaimnotrqfin_ext.OutstandingLossPlus_amt Outstanding_Amount_In_Original_Currency,
	Previouslypaidcurrency.l_en_gb Previouslypaid_Original_Currency, 
	ccx_ecfmsgclaimnotrqfin_ext.FullCostsPaidBefoRetent_amt Previously_Paid_Amount_In_Original_Currency,
	Settlementcostcurrency.l_en_gb  Settlementvalues_Original_Currency, 
	ccx_ecfmsgclaimnotrqfin_ext.CurrentCostsForContract_amt Settlement_Amount_In_Original_Currency,
	ccx_ecfmsgclaimnotrqfin_ext.SettlementVat_amt Settlement_Amount_VAT_In_VAT_Currency,
	SettlementVatcurrency.l_en_gb Settlement_VAT_Currency, 
	settlementcurrency.l_en_gb  Settlement_Currency, 
	ccx_ecfmsgclaimnotrqfin_ext.SettlementAmount_amt Settlement_Amount_In_Settlement_Currency,
	ccx_ecfmsgclaimnotrqfin_ext.ExchangeRate Exchange_Rate,
case when Isnull(incurredcurrency.l_en_gb) then (outstandingcurrency.l_en_gb) 
when Isnull(outstandingcurrency.l_en_gb) then (Previouslypaidcurrency.l_en_gb) 
when Isnull(Previouslypaidcurrency.l_en_gb) then (Settlementcostcurrency.l_en_gb)
else (incurredcurrency.l_en_gb) 
end Original_Currency 
from 
cc_claim 
left outer join ccx_lmmessage_ext on ccx_lmmessage_ext.Claim = cc_claim.id
left outer join ccx_ecfmsgclaimnotrqfin_ext on ccx_ecfmsgclaimnotrqfin_ext.ECFMsg = ccx_lmmessage_ext.id
left outer join cctl_currency incurredcurrency on ccx_ecfmsgclaimnotrqfin_ext.incurred_cur = incurredcurrency.ID
left outer join cctl_ecfoutstandingqualifiercode_ext on  ccx_ecfmsgclaimnotrqfin_ext.OutstandingAmountQualifier_TMK = cctl_ecfoutstandingqualifiercode_ext.ID
LEFT OUTER JOIN cctl_lmmessagetype_ext on ccx_lmmessage_ext.messagetype = cctl_lmmessagetype_ext.id 
LEFT OUTER JOIN cctl_currency outstandingcurrency ON outstandingcurrency.id = ccx_ecfmsgclaimnotrqfin_ext.outstanding_cur 
LEFT OUTER JOIN cctl_currency Previouslypaidcurrency ON ccx_ecfmsgclaimnotrqfin_ext.fullcostspaidbeforetent_cur = Previouslypaidcurrency.id 
LEFT OUTER JOIN cctl_currency Settlementcostcurrency  ON ccx_ecfmsgclaimnotrqfin_ext.currentcostsforcontract_cur = Settlementcostcurrency.id 
LEFT OUTER JOIN cctl_currency SettlementVatcurrency  ON ccx_ecfmsgclaimnotrqfin_ext.settlementvat_cur =  SettlementVatcurrency.id 
LEFT OUTER JOIN cctl_currency settlementcurrency ON ccx_ecfmsgclaimnotrqfin_ext.settlementamount_cur = settlementcurrency.id 
where  
        cctl_lmmessagetype_ext.l_en_gb = 'ClaimNotify' 
         AND ccx_lmmessage_ext.suspended = 0 