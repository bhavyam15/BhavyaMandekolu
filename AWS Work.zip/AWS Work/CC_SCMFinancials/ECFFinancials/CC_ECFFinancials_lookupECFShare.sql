select
distinct
Current_Syndicate_Share.ClaimID,
Current_Syndicate_Share.ClaimNumber,
Current_Syndicate_Share.MessageID,
Current_Syndicate_Share.MessageSequence,
--Current_Syndicate_Share.Share,
--Current_Syndicate_Share.Role,
sum(Current_Syndicate_Share.Share) over( partition by Current_Syndicate_Share.ClaimID,Current_Syndicate_Share.MessageID,Current_Syndicate_Share.MessageSequence) Bureau_Share,
sum((case when Carrier_code = Current_syndicate and Role = 'Lead' then Current_Syndicate_Share.Share else 0.0 end)) over( partition by Current_Syndicate_Share.ClaimID,Current_Syndicate_Share.MessageID,Current_Syndicate_Share.MessageSequence) Lead_Share,
sum((case when Carrier_code = Current_syndicate and Role = 'Follower' then Current_Syndicate_Share.Share else 0.0 end)) over( partition by Current_Syndicate_Share.ClaimID,Current_Syndicate_Share.MessageID,Current_Syndicate_Share.MessageSequence) Follower_Share,
sum((case when Carrier_code = Current_syndicate and Role in ('Follower','Lead') then Current_Syndicate_Share.Share else 0.0 end)) over( partition by Current_Syndicate_Share.ClaimID,Current_Syndicate_Share.MessageID,Current_Syndicate_Share.MessageSequence) Aggregate_Share
--into #lookupECFShare 
from(
select
cc_claim.ClaimNumber,
cc_claim.id ClaimID,
ccx_lmmessage_ext.ID MessageID,
ccx_lmmessage_ext.MessageSequence,
substring(ccx_ecfmsgcnotifrqcarrier_ext.CarrierCode_TMK,length(ccx_ecfmsgcnotifrqcarrier_ext.CarrierCode_TMK)-3,length(ccx_ecfmsgcnotifrqcarrier_ext.CarrierCode_TMK)) Carrier_code,
substring(ReceiverPartyId,length(ReceiverPartyId)-3,length(ReceiverPartyId)) Current_syndicate,
cctl_ecfparticipantfunction_ext.L_en_GB Role,
ccx_ecfmsgcnotifrqcarrier_ext.Share
from 
cc_claim
left outer join ccx_lmmessage_ext on cc_claim.ID = ccx_lmmessage_ext.Claim
left outer join ccx_ecfmsgcnotifrqcarrier_ext on ccx_lmmessage_ext.id = ccx_ecfmsgcnotifrqcarrier_ext.ECFMsg  
left outer join cctl_ecfparticipantfunction_ext on ccx_ecfmsgcnotifrqcarrier_ext.Role = cctl_ecfparticipantfunction_ext.ID
left outer join cctl_ecfresponsecode_ext on cctl_ecfresponsecode_ext.ID = ccx_lmmessage_ext.ResponseCode
left outer join ccx_ecfmarketfinanamt_ext on ccx_ecfmsgcnotifrqcarrier_ext.id = ccx_ecfmarketfinanamt_ext.carrier
where
--ClaimNumber = 'TMK000000000424' and
TR is not null
) Current_Syndicate_Share
order by ClaimID,MessageID,MessageSequence

