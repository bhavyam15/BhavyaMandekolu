select * from (
select 
CurrentMessage.ClaimID,
CurrentMessage.ECFClaim_FinancialID,CurrentMessage.MessageID,
row_number() over(partition by CurrentMessage.ECFClaim_FinancialID order by CurrentMessage.UpdateTime ) rnk,
exchangerate.NormalizedRate  
from CC_ECFFinancials_exchangerate exchangerate , CC_ECFFinancials_CurrentMessage CurrentMessage
where PriceCurrency = 'EUR' 
and exchangerate.BaseCurrency = 'GBP'
and CurrentMessage.UpdateTime >=  exchangerate.CreateTime
order by  exchangerate.CreateTime  ) where rnk = 1