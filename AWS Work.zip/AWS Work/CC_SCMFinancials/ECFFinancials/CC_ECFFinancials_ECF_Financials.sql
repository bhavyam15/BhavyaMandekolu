select 
CurrentMessage.ClaimID,
CurrentMessage.ClaimNumber,
/* Primary Key */
CurrentMessage.MessageID,
CurrentMessage.MessageSequence,
CurrentMessage.MessageType,
/* Primary Key */
CurrentMessage.ECFClaim_FinancialID,
CurrentMessage.TR,
CurrentMessage.UpdateTime,
CurrentMessage.Original_Currency,  
Originalcur_FXRate.NormalizedRate CurrentMessage_GBP_to_Originalcur_FXRate, 
GBP_to_EUR_FXRate.NormalizedRate CurrentMessage_GBP_to_EUR_FXRate, 
GBP_to_CAD_FXRate.NormalizedRate CurrentMessage_GBP_to_CAD_FXRate, 
CurrentMessage.Current_Syndicate,
CurrentMessage.Original_Signing_Number_and_Date,
CurrentMessage.Outstanding_Amount_Qualifier,
CurrentMessage.Incurred_Original_Currency,
CurrentMessage.Incurred_Amount_In_Original_Currency,
CurrentMessage.Outstanding_Original_Currency, 
CurrentMessage.Outstanding_Amount_In_Original_Currency,
CurrentMessage.Previouslypaid_Original_Currency, 
CurrentMessage.Previously_Paid_Amount_In_Original_Currency,
CurrentMessage.Settlementvalues_Original_Currency, 
CurrentMessage.Settlement_Amount_In_Original_Currency,
CurrentMessage.Settlement_Amount_VAT_In_VAT_Currency,
CurrentMessage.Settlement_VAT_Currency, 
CurrentMessage.Settlement_Currency, 
CurrentMessage.Settlement_Amount_In_Settlement_Currency,
CurrentMessage.Exchange_Rate,
lkp.Lead_Share  CurrentMessageLeadShare,
lkp.Bureau_Share  CurrentMessageBureauShare,
lkp.Aggregate_Share  CurrentMessageAggregateShare,
lkp.Follower_Share  CurrentMessageFollowerShare 
--into #ECF_Financials
from CC_ECFFinancials_CurrentMessage CurrentMessage
left outer join CC_ECFFinancials_lookupECFShare lkp on lkp.ClaimID = CurrentMessage.ClaimID and lkp.MessageID = CurrentMessage.MessageID and lkp.MessageSequence = CurrentMessage.MessageSequence
left outer join CC_ECFFinancials_CurrentMessage_GBP_to_CAD_FXRate GBP_to_CAD_FXRate on GBP_to_CAD_FXRate.ECFClaim_FinancialID = CurrentMessage.ECFClaim_FinancialID
left outer join CC_ECFFinancials_CurrentMessage_GBP_to_Originalcur_FXRate  Originalcur_FXRate on Originalcur_FXRate.ECFClaim_FinancialID = CurrentMessage.ECFClaim_FinancialID
left outer join CC_ECFFinancials_CurrentMessage_GBP_to_EUR_FXRate  GBP_to_EUR_FXRate on GBP_to_EUR_FXRate.ECFClaim_FinancialID = CurrentMessage.ECFClaim_FinancialID
where
--CurrentMessage.ClaimNumber = 'TMK000000000424' and
CurrentMessage.TR is not null
--and UUID = '03c4a2df-4502-4b1f-944a-c340f30b5cde'