select 
cc_claim.id ClaimID,
/* Primary Key */
lm.ID MessageID,
lm.UpdateTime Message_Last_Updated,
ECFIndicator_TMK,
lm.UUID ,
lm.OCR BPCR,
lm.CreateTime,
lm.MovementReferenceSequence,
lm.ReceiverPartyId Syndicate,
lm.ClaimLineNum_TMK Syndicate_Line_Number,
lm.ReceiverShare/100 Carrier_Share,
lm.Narrative,
origcur.L_en_GB OriginalCurrency,
setlcur.L_en_GB SettlementCurrency,
lm.PaidThisTimeIndemnity_amt pct100Share_PaidThisTimeIndemnity, 
lm.PaidThisTimeFees_amt pct100Share_PaidThisTimeFees ,
lm.PaidThisTimeIndemnity_amt+lm.PaidThisTimeFees_amt pct100Total_PaidThisTime,
lm.PaidToDateIndemnity_amt pct100Share_PaidToDateIndemnity ,
lm.PaidToDateFees_amt pct100Share_PaidToDateFees,
lm.PaidToDateIndemnity_amt+lm.PaidToDateFees_amt pct100Total_PaidtoDate,
lm.OutstandingIndemnity_amt pct100Share_OutstandingIndemnity,
lm.OutstandingFees_amt pct100Share_OutstandingFees,
lm.OutstandingIndemnity_amt+lm.OutstandingFees_amt pct100Total_Outstanding ,
lm.PaidThisTimeIndemnity_amt+lm.PaidToDateIndemnity_amt+lm.OutstandingIndemnity_amt pct100TotalIncurredIndemnity,
lm.PaidThisTimeFees_amt+lm.PaidToDateFees_amt+lm.OutstandingFees_amt pct100TotalIncurredFee,
lm.PaidThisTimeIndemnity_amt+lm.PaidThisTimeFees_amt+lm.PaidToDateIndemnity_amt+lm.PaidToDateFees_amt+lm.OutstandingIndemnity_amt+lm.OutstandingFees_amt pct100totalincurred,
lm.PaidThisTimeIndemnity_amt *lm.ReceiverShare/100  pctcarrierShare_PaidThisTimeIndemnity, 
lm.PaidThisTimeFees_amt *lm.ReceiverShare/100 pctcarrierShare_PaidThisTimeFees ,
lm.PaidThisTimeIndemnity_amt *lm.ReceiverShare/100+lm.PaidThisTimeFees_amt *lm.ReceiverShare/100 pctcarrierShare_TotalPaidThisTime,
lm.PaidToDateIndemnity_amt *lm.ReceiverShare/100 pctcarrierShare_PaidToDateIndemnity ,
lm.PaidToDateFees_amt *lm.ReceiverShare/100 pctcarrierShare_PaidToDateFees,
lm.PaidToDateIndemnity_amt *lm.ReceiverShare/100+lm.PaidToDateFees_amt *lm.ReceiverShare/100 pctcarrierShare_TotalPaidToDate,
lm.OutstandingIndemnity_amt *lm.ReceiverShare/100 pctcarrierShare_OutstandingIndemnity,
lm.OutstandingFees_amt *lm.ReceiverShare/100 pctcarrierShare_OutstandingFees,
lm.OutstandingIndemnity_amt*lm.ReceiverShare/100+lm.OutstandingFees_amt *lm.ReceiverShare/100 pctcarrierShare_TotalOutstanding,

lm.PaidThisTimeIndemnity_amt *lm.ReceiverShare/100+
lm.PaidToDateIndemnity_amt *lm.ReceiverShare/100+
lm.OutstandingIndemnity_amt*lm.ReceiverShare/100 pctcarriershare_Totalincurred_Indeminity,

lm.PaidThisTimeFees_amt *lm.ReceiverShare/100+
lm.PaidToDateFees_amt *lm.ReceiverShare/100+
lm.OutstandingFees_amt *lm.ReceiverShare/100 pctcarriershare_Totalincurred_Fee,

lm.PaidThisTimeIndemnity_amt *lm.ReceiverShare/100+lm.PaidThisTimeFees_amt *lm.ReceiverShare/100+lm.PaidToDateIndemnity_amt *lm.ReceiverShare/100+lm.PaidToDateFees_amt *lm.ReceiverShare/100+lm.OutstandingIndemnity_amt*lm.ReceiverShare/100+lm.OutstandingFees_amt *lm.ReceiverShare/100 pctcarriershare_Totalincurred,

lm.ExchangeRate Original_to_Settlement_Exchange_Rate,
lm.ReserveExchangeRate_TMK Base_to_Original_Exchange_Rate,
(select 
top 1
NormalizedRate  
from cc_exchangerate 
where convert(varchar(256),PriceCurrency) = origcur.L_en_GB 
--and convert(varchar(50),BaseCurrency) = 'GBP'
and lm.UpdateTime >=  CreateTime
order by  CreateTime desc ) Base_to_Original_FXRate,
lm.InsurerRiskReference,
cctl_lmmessagetype_ext.L_en_GB Messagetype,
lm.TransactionType

from 
cc_claim
left outer join ccx_lmmessage_ext lm on lm.claim = cc_claim.ID
left outer join cctl_lmmessagetype_ext on lm.MessageType = cctl_lmmessagetype_ext.ID
left outer join cctl_currency origcur on lm.OriginalCurrency = origcur.ID
left outer join cctl_currency setlcur on lm.SettlementCurrency = setlcur.ID
where 
Suspended = 0  and 
cctl_lmmessagetype_ext.L_en_GB ='LloydsSyndicateClaim'