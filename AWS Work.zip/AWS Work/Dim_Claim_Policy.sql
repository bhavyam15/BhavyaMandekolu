select  
cc_policy.ID Dim_Claim_Policy_Key,
cc_claim.ID ClaimID,
cc_policy.ID PolicyID,
/* Business Key */
cc_policy.ID Policy_ReposId,
/* Business Key */
/* Dimension Attributes */
cc_policy.PolicyNumber UMR,
cctl_policytype.L_en_GB Policy_Type,
cc_policy.ProgramReference_TMK Programme_Reference,
cc_policy.OperatingTerritory_TMK Operating_Territory,
cc_policy.YearOfAccount_TMK Year_Of_Account,
cctl_placingbasis_tmk.L_en_GB Placing_Basis,
cc_Policy.FinancialInterests Interests,
cc_Policy.Peril_TMK Peril,
cctl_currency.L_en_GB Policy_Currency,
case when EndorsementInd_TMK= 1 then 'Yes' else 'No' end Endorsement ,
cc_policy.SanctionStatus_TMK Policy_Sanction_Status,
cctl_periodbasis_tmk.L_en_GB Period_Basis,
cc_Policy.PolicyLength_TMK Period_Length,
cc_Policy.EffectiveDate Policy_Effective_Date,
cc_Policy.ExpirationDate Policy_Expiration_Date
--into #Dim_Claim_Policy
/* Dimension Attributes */
from cc_claim 
left outer join cc_policy on  cc_claim.PolicyID = cc_policy.ID
left outer join cctl_currency on cc_policy.Currency = cctl_currency.ID
left outer join cctl_policytype on cctl_policytype.id = cc_claim.ClaimCustomerType_TMK
left outer join cctl_placingbasis_tmk on cctl_placingbasis_tmk.id = cc_policy.PlacingBasis_TMK
left outer join cctl_periodbasis_tmk on cctl_periodbasis_tmk.ID = cc_policy.PeriodBasis_TMK
where cc_policy.ID > {0}
