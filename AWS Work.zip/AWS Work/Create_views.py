import sys
import datetime
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import SQLContext
from awsglue.job import Job
from awsglue.dynamicframe import DynamicFrame
from pyspark.sql import *


## @params: [JOB_NAME]
args = getResolvedOptions(sys.argv,['JOB_NAME'])


sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

#get todays date for s3 directory
now = datetime.datetime.now()
extract_date = now.strftime("%Y%m%d")

#generate s3 path
#s3_path = "s3://ntt-glue-scripts/CC-Staging-Dev-parquet1/"+extract_date+"/"
s3_path = "s3://ntt-glue-scripts/Landing-S3-For-CMS/CURRENT/20190321/"

print '\n s3_path : ' + s3_path

table_list_df = spark.read.format("csv").option("header", "true").load("s3://ntt-glue-scripts/Stage_table_list/CMS_Stage_Table_Name.csv")
#print table_list_df.printSchema()
#print type(table_list_df)
#print "total count", table_list_df.count()

table_array = table_list_df.select('Base_table').collect()
print table_array

table_list = [str(row.Base_table) for row in table_array]
print table_list



def call_create_views():
	def create_views(table_name, s3_source_path):
		DF = table_name
		catalog_tab_name = table_name+"/"
		view_name = table_name
		DF = glueContext.create_dynamic_frame_from_options(connection_type = "s3", connection_options = {"paths": [s3_source_path + catalog_tab_name]}, format = "parquet").toDF()
		DF.createOrReplaceTempView(view_name)
		print "view :" + view_name + "created"
	for table in table_list:
		print '\n-- tableName: '+table
		create_views(table, s3_path)
