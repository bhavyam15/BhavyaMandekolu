###########################################################
#   Script Name    :  cms_pre_requistics_table_creation_redshift.py
#   Description : This script will create all the tables neccessary for CMS in Redshift Database.
#                   

#   Version no  |   Date Modified  | Comment     
#       0.1     |    16/03/19     | Initial Version
#
###########################################################
import sys
import config
import psycopg2

#Global parameters for Redshift connections
glue_redshift_db_connection = config.glue_redshift_db_connection
glue_redshift_host = config.glue_redshift_host
glue_redshift_database = config.glue_redshift_database
glue_redshift_port = config.glue_redshift_port
glue_redshift_db_user_name = config.glue_redshift_db_user_name
glue_redshift_db_password = config.glue_redshift_db_password
glue_redshift_schema_name = config.glue_redshift_schema_name
 
try:
    print (" Reading the Redshift_table_creation.sql file ")
    fileread = open(r'''Redshift_table_creation.sql''', 'r')
    sqlFile = fileread.read()
    fileread.close()
    
    # Split SQLs based on ';'
    sqlCommands = sqlFile.split(';')
    
    # connect to the PostgreSQL server
    conn = psycopg2.connect(
    host=glue_redshift_host,
    user=glue_redshift_db_user_name,
    port=glue_redshift_port,
    password=glue_redshift_db_password,
    dbname=glue_redshift_database)
    		
    cur = conn.cursor()
    	
    for commands in sqlCommands:
        sql_execute = commands.format(glue_redshift_schema_name)
        cur.execute(sql_execute)
             
    # close communication with the PostgreSQL database server
    cur.close()
    # commit the changes
    conn.commit()
    print (" All the tables are created in Redshift ")  
	
except (Exception, psycopg2.DatabaseError) as error:
	print ("Unexpected error:", error)
	print (str(sys.exc_info()[0])) 
	print (str(sys.exc_info()[1]))
finally:
    if conn is not None:
        conn.close()  