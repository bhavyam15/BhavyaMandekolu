/*###########################################################
#   Script Name    :  Redshift_table_creation.sql
#   Description : This SQL file holds all the tables required to be created in Redshift
#                   

#   Version no  |   Date Modified  | Comment     
#       0.1     |    16/03/19     | Initial Version
#
###########################################################  */

/* Table Creation : ctrl_load_reconciliation */

drop table if exists {0}.ctrl_load_reconciliation;

create table {0}.ctrl_load_reconciliation (
load_id	bigint	,
period_key	bigint	,
job_name	varchar(65535)	,
inserted_dt	varchar(65535)	,
table_name	varchar(65535)	,
Record_count_in_S3	bigint	,
Record_count_in_Redshift	bigint	,
Error_Record_count	bigint	,
surrogate_column_name	varchar(65535)	,
max_surrogate_key_retrieved	varchar(65535)	,
load_type	varchar(65535)	,
delta_column_name	varchar(65535)	,
max_delta_key_value_retrieved	varchar(65535)	,
Glue_Job_Id	varchar(65535)	);

-----------------------------------------------------------------------------------

/* Table Creation : Ctrl_Load_management */

drop table if exists {0}.Ctrl_Load_management;

create table {0}.Ctrl_Load_management
(load_id	bigint	,
job_name	varchar(65535)	,
inserted_dt	varchar(65535)	,
step_name	varchar(65535)	,
status	varchar(65535)	,
error_code	varchar(65535)	,
message	varchar(65535)	,
loadparmeter_start_date	varchar(65535)	,
loadparmeter_period_key	bigint	);

-----------------------------------------------------------------------------------

/* Table Creation : Ctrl_Load_log_message */

drop table if exists {0}.Ctrl_Load_log_message;

create table {0}.Ctrl_Load_log_message
(load_id	bigint	,
job_name	varchar(500)	,
start_time	varchar(50)	,
log_level	varchar(50)	,
log_message	varchar(65535)	,
dest_name	varchar(65535)	,
logic	varchar(65535)	,
step_name	varchar(65535)	,
src_name	varchar(65535)	);

-----------------------------------------------------------------------------------

/* Table Creation : Dim_Address_rtl */

drop table if exists {0}.Dim_Address_rtl;

create table {0}.Dim_Address_rtl
(
	Load_id				    int,
	Dim_Period_key			int,
	Inserted_dt				timestamp without time zone,
	Updated_dt				timestamp without time zone,
	Effective_Start_dt		timestamp without time zone,
	Effective_End_dt		timestamp without time zone,
	Current_Ind				Char(1),
	Delete_Ind				Char(1),
    Dim_Address_Key         bigint,
    AddressID bigint,
	Address_ReposId bigint,
	Country varchar(256),
	AddressLine1 varchar(60),
	AddressLine2 varchar(60),
	AddressLine3 varchar(60),
	Town varchar(60),
	PostalCode varchar(60),
	Addresstype varchar(256),
	Location_Description varchar(255),
	ValidUntil datetime
)  DISTSTYLE All SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : Dim_Address */

drop table if exists {0}.Dim_Address;

create table {0}.Dim_Address
(
	Load_id				    int,
	Dim_Period_key			int,
	Inserted_dt				timestamp without time zone,
	Updated_dt				timestamp without time zone,
	Effective_Start_dt		timestamp without time zone,
	Effective_End_dt		timestamp without time zone,
	Current_Ind				Char(1),
	Delete_Ind				Char(1),
    Dim_Address_Key         bigint,
    AddressID bigint,
	Address_ReposId bigint,
	Country varchar(256),
	AddressLine1 varchar(60),
	AddressLine2 varchar(60),
	AddressLine3 varchar(60),
	Town varchar(60),
	PostalCode varchar(60),
	Addresstype varchar(256),
	Location_Description varchar(255),
	ValidUntil datetime
)  DISTSTYLE All SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : BOUser_Security_Detail_rtl */

drop table if exists {0}.BOUser_Security_Detail_rtl;

create table {0}.BOUser_Security_Detail_rtl
( /* Dimension Audit Columns */
	Load_id						   int,
    Dim_Period_Key  int,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	BoUser varchar(61),
	ClaimId bigint,
	UserClaim_Conflict int	
)  DISTKEY(ClaimID) SORTKEY(BoUser);

-----------------------------------------------------------------------------------

/* Table Creation : BOUser_Security_Detail */

drop table if exists {0}.BOUser_Security_Detail;

create table {0}.BOUser_Security_Detail
( /* Dimension Audit Columns */
	Load_id						   int,
    Dim_Period_Key  int,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	BoUser varchar(61),
	ClaimId bigint,
	UserClaim_Conflict int	
)  DISTKEY(ClaimID) SORTKEY(BoUser);

-----------------------------------------------------------------------------------

/* Table Creation : CC_ECF_Financials_rtl */

drop table if exists {0}.CC_ECF_Financials_rtl;

create table {0}.CC_ECF_Financials_rtl
(   /* Flat Table Audit Columns */
	Load_id						   int,
	Dim_Period_key				   int,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	ClaimID bigint,
	ClaimNumber varchar(40),
	MessageID bigint,
	MessageSequence decimal(21,9),
	MessageType int,
	ECFClaim_FinancialID bigint,
	TR varchar(255),
	UpdateTime datetime,
	Original_Currency varchar(50),
	CurrentMessage_GBP_to_Originalcur_FXRate decimal(21,9),
	CurrentMessage_GBP_to_EUR_FXRate decimal(21,9),
	CurrentMessage_GBP_to_CAD_FXRate decimal(21,9),
	Current_Syndicate varchar(60),
	Original_Signing_Number_and_Date varchar(63),
	Outstanding_Amount_Qualifier varchar(256),
	Incurred_Original_Currency varchar(256),
	Incurred_Amount_In_Original_Currency decimal(21,9),
	Outstanding_Original_Currency varchar(256),
	Outstanding_Amount_In_Original_Currency decimal(21,9),
	Previouslypaid_Original_Currency varchar(256),
	Previously_Paid_Amount_In_Original_Currency decimal(21,9),
	Settlementvalues_Original_Currency varchar(256),
	Settlement_Amount_In_Original_Currency decimal(21,9),
	Settlement_Amount_VAT_In_VAT_Currency decimal(21,9),
	Settlement_VAT_Currency varchar(256),
	Settlement_Currency varchar(256),
	Settlement_Amount_In_Settlement_Currency decimal(21,9),
	Exchange_Rate decimal(21,9),
	CurrentMessageLeadShare decimal(21,9),
	CurrentMessageBureauShare decimal(21,9),
	CurrentMessageAggregateShare decimal(21,9),
	CurrentMessageFollowerShare decimal(21,9)
)  DISTKEY(ClaimID) SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : CC_ECF_Financials */

drop table if exists {0}.CC_ECF_Financials;

create table {0}.CC_ECF_Financials
(   /* Flat Table Audit Columns */
	Load_id						   int,
	Dim_Period_key				   int,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	ClaimID bigint,
	ClaimNumber varchar(40),
	MessageID bigint,
	MessageSequence decimal(21,9),
	MessageType int,
	ECFClaim_FinancialID bigint,
	TR varchar(255),
	UpdateTime datetime,
	Original_Currency varchar(50),
	CurrentMessage_GBP_to_Originalcur_FXRate decimal(21,9),
	CurrentMessage_GBP_to_EUR_FXRate decimal(21,9),
	CurrentMessage_GBP_to_CAD_FXRate decimal(21,9),
	Current_Syndicate varchar(60),
	Original_Signing_Number_and_Date varchar(63),
	Outstanding_Amount_Qualifier varchar(256),
	Incurred_Original_Currency varchar(256),
	Incurred_Amount_In_Original_Currency decimal(21,9),
	Outstanding_Original_Currency varchar(256),
	Outstanding_Amount_In_Original_Currency decimal(21,9),
	Previouslypaid_Original_Currency varchar(256),
	Previously_Paid_Amount_In_Original_Currency decimal(21,9),
	Settlementvalues_Original_Currency varchar(256),
	Settlement_Amount_In_Original_Currency decimal(21,9),
	Settlement_Amount_VAT_In_VAT_Currency decimal(21,9),
	Settlement_VAT_Currency varchar(256),
	Settlement_Currency varchar(256),
	Settlement_Amount_In_Settlement_Currency decimal(21,9),
	Exchange_Rate decimal(21,9),
	CurrentMessageLeadShare decimal(21,9),
	CurrentMessageBureauShare decimal(21,9),
	CurrentMessageAggregateShare decimal(21,9),
	CurrentMessageFollowerShare decimal(21,9)
)  DISTKEY(ClaimID) SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : CC_SCM_Financials_rtl */

drop table if exists {0}.CC_SCM_Financials_rtl;

create table {0}.CC_SCM_Financials_rtl
(	/* Flat Table Audit Columns */
	Load_id						   int,
	Dim_Period_key				   int,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	ClaimID bigint,
	MessageID bigint, -- Primary Key
	Message_Last_Updated datetime,
	ECFIndicator_TMK int,
	UUID varchar(36),
	BPCR varchar(255),
	CreateTime datetime,
	MovementReferenceSequence varchar(255),
	Syndicate varchar(60),
	Syndicate_Line_Number bigint,
	Carrier_Share decimal(21,9),
	Narrative varchar(1000),
	OriginalCurrency varchar(256),
	SettlementCurrency varchar(256),
	pct100Share_PaidThisTimeIndemnity decimal(21,9),
	pct100Share_PaidThisTimeFees decimal(21,9),
	pct100Total_PaidThisTime decimal(21,9),
	pct100Share_PaidToDateIndemnity decimal(21,9),
	pct100Share_PaidToDateFees decimal(21,9),
	pct100Total_PaidtoDate decimal(21,9),
	pct100Share_OutstandingIndemnity decimal(21,9),
	pct100Share_OutstandingFees decimal(21,9),
	pct100Total_Outstanding decimal(21,9),
	pct100TotalIncurredIndemnity decimal(21,9),
	pct100TotalIncurredFee decimal(21,9),
	pct100totalincurred decimal(21,9),
	pctcarrierShare_PaidThisTimeIndemnity decimal(21,9),
	pctcarrierShare_PaidThisTimeFees decimal(21,9),
	pctcarrierShare_TotalPaidThisTime decimal(21,9),
	pctcarrierShare_PaidToDateIndemnity decimal(21,9),
	pctcarrierShare_PaidToDateFees decimal(21,9),
	pctcarrierShare_TotalPaidToDate decimal(21,9),
	pctcarrierShare_OutstandingIndemnity decimal(21,9),
	pctcarrierShare_OutstandingFees decimal(21,9),
	pctcarrierShare_TotalOutstanding decimal(21,9),
	pctcarriershare_Totalincurred_Indeminity decimal(21,9),
	pctcarriershare_Totalincurred_Fee decimal(21,9),
	pctcarriershare_Totalincurred decimal(21,9),
	Original_to_Settlement_Exchange_Rate decimal(21,9),
	Base_to_Original_Exchange_Rate decimal(21,9),
	Base_to_Original_FXRate decimal(21,9),
	InsurerRiskReference varchar(255),
	MessageType varchar(255),
	TransactionType int
)  DISTKEY(ClaimID) SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : CC_SCM_Financials */

drop table if exists {0}.CC_SCM_Financials;

create table {0}.CC_SCM_Financials
(	/* Flat Table Audit Columns */
	Load_id						   int,
	Dim_Period_key				   int,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	ClaimID bigint,
	MessageID bigint, -- Primary Key
	Message_Last_Updated datetime,
	ECFIndicator_TMK int,
	UUID varchar(36),
	BPCR varchar(255),
	CreateTime datetime,
	MovementReferenceSequence varchar(255),
	Syndicate varchar(60),
	Syndicate_Line_Number bigint,
	Carrier_Share decimal(21,9),
	Narrative varchar(1000),
	OriginalCurrency varchar(256),
	SettlementCurrency varchar(256),
	pct100Share_PaidThisTimeIndemnity decimal(21,9),
	pct100Share_PaidThisTimeFees decimal(21,9),
	pct100Total_PaidThisTime decimal(21,9),
	pct100Share_PaidToDateIndemnity decimal(21,9),
	pct100Share_PaidToDateFees decimal(21,9),
	pct100Total_PaidtoDate decimal(21,9),
	pct100Share_OutstandingIndemnity decimal(21,9),
	pct100Share_OutstandingFees decimal(21,9),
	pct100Total_Outstanding decimal(21,9),
	pct100TotalIncurredIndemnity decimal(21,9),
	pct100TotalIncurredFee decimal(21,9),
	pct100totalincurred decimal(21,9),
	pctcarrierShare_PaidThisTimeIndemnity decimal(21,9),
	pctcarrierShare_PaidThisTimeFees decimal(21,9),
	pctcarrierShare_TotalPaidThisTime decimal(21,9),
	pctcarrierShare_PaidToDateIndemnity decimal(21,9),
	pctcarrierShare_PaidToDateFees decimal(21,9),
	pctcarrierShare_TotalPaidToDate decimal(21,9),
	pctcarrierShare_OutstandingIndemnity decimal(21,9),
	pctcarrierShare_OutstandingFees decimal(21,9),
	pctcarrierShare_TotalOutstanding decimal(21,9),
	pctcarriershare_Totalincurred_Indeminity decimal(21,9),
	pctcarriershare_Totalincurred_Fee decimal(21,9),
	pctcarriershare_Totalincurred decimal(21,9),
	Original_to_Settlement_Exchange_Rate decimal(21,9),
	Base_to_Original_Exchange_Rate decimal(21,9),
	Base_to_Original_FXRate decimal(21,9),
	InsurerRiskReference varchar(255),
	MessageType varchar(255),
	TransactionType int
)  DISTKEY(ClaimID) SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : Dim_Contact */

drop table if exists {0}.Dim_Contact;

create table {0}.Dim_Contact
(	Load_id						   int,
	Dim_Period_key				   int,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	Effective_Start_dt			   timestamp without time zone,
	Effective_End_dt			   timestamp without time zone,
	Current_Ind					   Char(1),
	Delete_Ind					   Char(1),
	Dim_Contact_Key bigint, --GeneratedKey
	ClaimID bigint,
	Contact_ReposId bigint, -- BusinessKey
	NameDenorm varchar(60),
	typelist_approvalassignment_id int,
	Approvassignment varchar(256),
	typelist_Country_id int,
	Country varchar(256),
	AddressLine1 varchar(60),
	AddressLine2 varchar(60),
	AddressLine3 varchar(60),
	Town varchar(60),
	PostalCode varchar(60),
	Addresstype varchar(256),
	Location_Description varchar(255),
	ValidUntil datetime,
	typelist_Prefered_Currency_id int,
	Prefered_Currency varchar(256),
	Primary_Contact varchar(60),
	Work varchar(30),
	Fax varchar(30),
	Main_Email varchar(60),
	Alternate_Email varchar(60),
	TaxID varchar(60),
	Notes varchar(1000),
	ContactProhibited varchar(3),
	CityDenorm varchar(60),
	State int

)  DISTKEY(ClaimID) SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : Dim_Contact_rtl */

drop table if exists {0}.Dim_Contact_rtl;

create table {0}.Dim_Contact_rtl
(	Load_id						   int,
	Dim_Period_key				   int,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	Effective_Start_dt			   timestamp without time zone,
	Effective_End_dt			   timestamp without time zone,
	Current_Ind					   Char(1),
	Delete_Ind					   Char(1),
	Dim_Contact_Key bigint, --GeneratedKey
	ClaimID bigint,
	Contact_ReposId bigint, -- BusinessKey
	NameDenorm varchar(60),
	typelist_approvalassignment_id int,
	Approvassignment varchar(256),
	typelist_Country_id int,
	Country varchar(256),
	AddressLine1 varchar(60),
	AddressLine2 varchar(60),
	AddressLine3 varchar(60),
	Town varchar(60),
	PostalCode varchar(60),
	Addresstype varchar(256),
	Location_Description varchar(255),
	ValidUntil datetime,
	typelist_Prefered_Currency_id int,
	Prefered_Currency varchar(256),
	Primary_Contact varchar(60),
	Work varchar(30),
	Fax varchar(30),
	Main_Email varchar(60),
	Alternate_Email varchar(60),
	TaxID varchar(60),
	Notes varchar(1000),
	ContactProhibited varchar(3),
	CityDenorm varchar(60),
	State int

)  DISTKEY(ClaimID) SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : Dim_Activity */

drop table if exists {0}.Dim_Activity;

create table {0}.Dim_Activity 
(
    /* Dimension Audit Columns */
	Load_id						   int,
	Dim_Period_key				   int,
	Inserted_dt					   timestamp without time zone ,
	Updated_dt				       timestamp without time zone ,
	Effective_Start_dt			   timestamp without time zone ,
	Effective_End_dt			   timestamp without time zone ,
	Current_Ind					   Char(1),
	Delete_Ind					   Char(1),
	Dim_Activity_Key bigint, --Generated Key
	ClaimID bigint,
	Activity_ReposID bigint, -- Business Key
	Related_to_Exposures varchar(511),
	Related_to_Matter varchar(128),
	Related_to_ClaimContact varchar(60),
	Star varchar(4),
	isthisactivityEscalated varchar(3),
	Duedate datetime,
	typelist_Priority_ID int,
	Priority varchar(256),
	typelist_status_ID int,
	Status varchar(256),
	Subject varchar(255),
	Exposures varchar(511),
	Externally_Owned varchar(3),
	Ext_Owner varchar(60),
	AssignedTo varchar(61),
	AssignedBy varchar(61),
	AssignedDate datetime,
	Description varchar(1333),
	Escalation_Date datetime,
	Calendar_Importance varchar(256),
	Mandatory varchar(3),
	Recurring varchar(3),
	Completion_Skipped_date datetime,
	Completed_by varchar(61),
	Assigned_Group varchar(100),
	ECFActivityFlag_TMK int,
	ActivityCategory varchar(256),
	ActivityPatternDescription varchar(1333),
	ActivityPatternCode varchar(255), -- newly added 
	ActivityPatternCategory varchar(256),
	MessageID bigint,
	TransactionReference varchar(255),
	Our_Role varchar(256),
	AssignedQueue varchar(255) ) ; 

-----------------------------------------------------------------------------------

/* Table Creation : Dim_Activity_rtl */

drop table if exists {0}.Dim_Activity_rtl;

create table {0}.Dim_Activity_rtl 
(
    /* Dimension Audit Columns */
	Load_id						   int,
	Dim_Period_key				   int,
	Inserted_dt					   timestamp without time zone ,
	Updated_dt				       timestamp without time zone ,
	Effective_Start_dt			   timestamp without time zone ,
	Effective_End_dt			   timestamp without time zone ,
	Current_Ind					   Char(1),
	Delete_Ind					   Char(1),
	Dim_Activity_Key bigint, --Generated Key
	ClaimID bigint,
	Activity_ReposID bigint, -- Business Key
	Related_to_Exposures varchar(511),
	Related_to_Matter varchar(128),
	Related_to_ClaimContact varchar(60),
	Star varchar(4),
	isthisactivityEscalated varchar(3),
	Duedate datetime,
	typelist_Priority_ID int,
	Priority varchar(256),
	typelist_status_ID int,
	Status varchar(256),
	Subject varchar(255),
	Exposures varchar(511),
	Externally_Owned varchar(3),
	Ext_Owner varchar(60),
	AssignedTo varchar(61),
	AssignedBy varchar(61),
	AssignedDate datetime,
	Description varchar(1333),
	Escalation_Date datetime,
	Calendar_Importance varchar(256),
	Mandatory varchar(3),
	Recurring varchar(3),
	Completion_Skipped_date datetime,
	Completed_by varchar(61),
	Assigned_Group varchar(100),
	ECFActivityFlag_TMK int,
	ActivityCategory varchar(256),
	ActivityPatternDescription varchar(1333),
	ActivityPatternCode varchar(255), -- newly added 
	ActivityPatternCategory varchar(256),
	MessageID bigint,
	TransactionReference varchar(255),
	Our_Role varchar(256),
	AssignedQueue varchar(255)) ;

-----------------------------------------------------------------------------------

/* Table Creation : Dim_Matter */

drop table if exists {0}.Dim_Matter;

create table {0}.Dim_Matter 
(
    /* Dimension Audit Columns */
	Load_id						   int,
	Dim_Period_key				   int,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	Effective_Start_dt			   timestamp without time zone,
	Effective_End_dt			   timestamp without time zone,
	Current_Ind					   Char(1),
	Delete_Ind					   Char(1),
	Dim_Matter_Key bigint, -- Generated Key 
	ClaimID bigint,
	Matter_ReposId bigint, -- Business Key 
	Name varchar(128),
	CaseNumber varchar(128),
	FinalSettleCost1 decimal(21,9),
	Owner varchar(61),
	Owner_Group varchar(100),
	MatterType varchar(256),
	Claimant varchar(60),
	Defendant varchar(60),
	Related_to_Subrogation varchar(3),
	CloseDate datetime,
	Reason_ReOpened varchar(256),
	CourtType varchar(256),
	Court_District varchar(256),
	CLaimant_Lawyer varchar(60),
	Claimant_Law_Firm varchar(60),
	Defense_Lawyer varchar(60),
	Defense_Law_Firm varchar(60),
	DefenceAppointmentDate datetime,
	SentToDefenseDate datetime,
	TrialDate datetime,
	Trial_Venue varchar(60),
	Room varchar(32),
	Judge varchar(60),
	DocketNumber varchar(20),
	FilingDate datetime,
	Filed_by varchar(60),
	ServiceDate datetime,
	MethodServed varchar(256),
	ResponseDue datetime,
	ResponseFiled datetime,
	PunitiveDamages varchar(3),
	Resolution int,
	FinalLegalCost decimal(21,9),
	FinalSettleCost decimal(21,9),
	FinalSettleDate datetime

)  DISTKEY(ClaimID) SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : Dim_Matter_rtl */

drop table if exists {0}.Dim_Matter_rtl;

create table {0}.Dim_Matter_rtl
(
    /* Dimension Audit Columns */
	Load_id						   int,
	Dim_Period_key				   int,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	Effective_Start_dt			   timestamp without time zone,
	Effective_End_dt			   timestamp without time zone,
	Current_Ind					   Char(1),
	Delete_Ind					   Char(1),
	Dim_Matter_Key bigint, -- Generated Key 
	ClaimID bigint,
	Matter_ReposId bigint, -- Business Key 
	Name varchar(128),
	CaseNumber varchar(128),
	FinalSettleCost1 decimal(21,9),
	Owner varchar(61),
	Owner_Group varchar(100),
	MatterType varchar(256),
	Claimant varchar(60),
	Defendant varchar(60),
	Related_to_Subrogation varchar(3),
	CloseDate datetime,
	Reason_ReOpened varchar(256),
	CourtType varchar(256),
	Court_District varchar(256),
	CLaimant_Lawyer varchar(60),
	Claimant_Law_Firm varchar(60),
	Defense_Lawyer varchar(60),
	Defense_Law_Firm varchar(60),
	DefenceAppointmentDate datetime,
	SentToDefenseDate datetime,
	TrialDate datetime,
	Trial_Venue varchar(60),
	Room varchar(32),
	Judge varchar(60),
	DocketNumber varchar(20),
	FilingDate datetime,
	Filed_by varchar(60),
	ServiceDate datetime,
	MethodServed varchar(256),
	ResponseDue datetime,
	ResponseFiled datetime,
	PunitiveDamages varchar(3),
	Resolution int,
	FinalLegalCost decimal(21,9),
	FinalSettleCost decimal(21,9),
	FinalSettleDate datetime

)  DISTKEY(ClaimID) SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : Dim_Claim_Policy */

drop table if exists {0}.Dim_Claim_Policy;

  create table {0}.Dim_Claim_Policy 
(
    Load_id						   bigint,
	Dim_Period_key				   bigint,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	Effective_Start_dt			   timestamp without time zone,
	Effective_End_dt			   timestamp without time zone,
	Current_Ind					   Char(1),
	Delete_Ind					   Char(1),
	Dim_Claim_Policy_Key	bigint not null, -- Generated
	ClaimID bigint,
	PolicyID bigint,
	Policy_ReposId bigint, --Business Key
	UMR varchar(40),
	Policy_Type varchar(256),
	Programme_Reference varchar(255),
	Operating_Territory varchar(255),
	Year_Of_Account varchar(4),
	Placing_Basis varchar(256),
	Interests varchar(255),
	Peril varchar(255),
	Policy_Currency varchar(256),
	Endorsement varchar(3),
	Policy_Sanction_Status int,
	Period_Basis varchar(256),
	Period_Length varchar(255),
	Policy_Effective_Date datetime,
	Policy_Expiration_Date datetime

	
)  DISTKEY(ClaimID) SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : Dim_Claim_Policy_rtl */

drop table if exists {0}.Dim_Claim_Policy_rtl;

  create table {0}.Dim_Claim_Policy_rtl
(
    Load_id						   bigint,
	Dim_Period_key				   bigint,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	Effective_Start_dt			   timestamp without time zone,
	Effective_End_dt			   timestamp without time zone,
	Current_Ind					   Char(1),
	Delete_Ind					   Char(1),
	Dim_Claim_Policy_Key	bigint not null, -- Generated
	ClaimID bigint,
	PolicyID bigint,
	Policy_ReposId bigint, --Business Key
	UMR varchar(40),
	Policy_Type varchar(256),
	Programme_Reference varchar(255),
	Operating_Territory varchar(255),
	Year_Of_Account varchar(4),
	Placing_Basis varchar(256),
	Interests varchar(255),
	Peril varchar(255),
	Policy_Currency varchar(256),
	Endorsement varchar(3),
	Policy_Sanction_Status int,
	Period_Basis varchar(256),
	Period_Length varchar(255),
	Policy_Effective_Date datetime,
	Policy_Expiration_Date datetime

	
)  DISTKEY(ClaimID) SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : Dim_CLaim_PolicyLine */

drop table if exists {0}.Dim_CLaim_PolicyLine;

create table {0}.Dim_CLaim_PolicyLine 
(
    	/* Dimension Audit Columns */
	Load_id						   bigint,
	Dim_Period_key				   bigint,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	Effective_Start_dt			   timestamp without time zone,
	Effective_End_dt			   timestamp without time zone,
	Current_Ind					   Char(1),
	Delete_Ind					   Char(1),
	Dim_Claim_PolicyLine_Key bigint, --
	ClaimID bigint,
	PolicyID bigint,
	PolicyLineID bigint,
	PolicyLine_ReposId bigint, -- Business Key
	Class_Type varchar(12),
	Major_Class varchar(12),
	Minor_Class varchar(12),
	Class varchar(12),
	Policy_Line_Reference varchar(255),
	Policy_LineStatus varchar(256),
	Carrier_Code varchar(256),
	Producing_Team varchar(256),
	Signed_Order decimal(21,9),
	Signed_Line decimal(21,9),
	OSND varchar(271),
	ExposureLimit decimal(21,9),
	R_I varchar(255),
	R_I2 varchar(255),
	R_I3 varchar(255),
	Policy_Currency varchar(256),
	UM_Ref varchar(255),
	Underwriter varchar(255),
	Premium decimal(21,9),
	Package varchar(3),
	Declaration_Reference varchar(3)

)  DISTKEY(ClaimID) SORTKEY(Dim_Period_key);
-----------------------------------------------------------------------------------

/* Table Creation : Dim_CLaim_PolicyLine_rtl */

drop table if exists {0}.Dim_CLaim_PolicyLine_rtl;

create table {0}.Dim_CLaim_PolicyLine_rtl
(
    	/* Dimension Audit Columns */
	Load_id						   bigint,
	Dim_Period_key				   bigint,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	Effective_Start_dt			   timestamp without time zone,
	Effective_End_dt			   timestamp without time zone,
	Current_Ind					   Char(1),
	Delete_Ind					   Char(1),
	Dim_Claim_PolicyLine_Key bigint, --
	ClaimID bigint,
	PolicyID bigint,
	PolicyLineID bigint,
	PolicyLine_ReposId bigint, -- Business Key
	Class_Type varchar(12),
	Major_Class varchar(12),
	Minor_Class varchar(12),
	Class varchar(12),
	Policy_Line_Reference varchar(255),
	Policy_LineStatus varchar(256),
	Carrier_Code varchar(256),
	Producing_Team varchar(256),
	Signed_Order decimal(21,9),
	Signed_Line decimal(21,9),
	OSND varchar(271),
	ExposureLimit decimal(21,9),
	R_I varchar(255),
	R_I2 varchar(255),
	R_I3 varchar(255),
	Policy_Currency varchar(256),
	UM_Ref varchar(255),
	Underwriter varchar(255),
	Premium decimal(21,9),
	Package varchar(3),
	Declaration_Reference varchar(3)

)  DISTKEY(ClaimID) SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : Dim_User */

drop table if exists {0}.Dim_User;

create table {0}.Dim_User 
(
	/* Dimension Audit Columns */
	Load_id						   int,
	Dim_Period_key				   int,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	Effective_Start_dt			   timestamp without time zone,
	Effective_End_dt			   timestamp without time zone,
	Current_Ind					   Char(1),
	Delete_Ind					   Char(1),
	Dim_User_Key bigint, -- Generated Key
	Userid bigint,
    User_ReposId bigint, -- Business Key
	FirstName varchar(30),
	LastName varchar(30),
	PrimaryPhone int,
	EmailAddress1 varchar(60)

)  DISTSTYLE All SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : Dim_User_rtl */

drop table if exists {0}.Dim_User_rtl;

create table {0}.Dim_User_rtl
(
	/* Dimension Audit Columns */
	Load_id						   int,
	Dim_Period_key				   int,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	Effective_Start_dt			   timestamp without time zone,
	Effective_End_dt			   timestamp without time zone,
	Current_Ind					   Char(1),
	Delete_Ind					   Char(1),
	Dim_User_Key bigint, -- Generated Key
	Userid bigint,
    User_ReposId bigint, -- Business Key
	FirstName varchar(30),
	LastName varchar(30),
	PrimaryPhone int,
	EmailAddress1 varchar(60)

)  DISTSTYLE All SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : Dim_Exposure_rtl */

drop table if exists {0}.Dim_Exposure_rtl;

create table {0}.Dim_Exposure_rtl
( 	/* Dimension Audit Columns */
	Load_id						   bigint,
	Dim_Period_key				   bigint,
	Inserted_dt					   datetime,
	Updated_dt				       datetime,
	Effective_Start_dt			   datetime,
	Effective_End_dt			   datetime,
	Current_Ind					   Char(1),
	Delete_Ind					   Char(1),
    Dim_Exposure_Key bigint, -- Generated Key
	ClaimID bigint,
	ExposureID bigint,
		Exposure_ReposId bigint, -- Business Key
	ClaimNumber varchar(40),
	Exposure_Name varchar(511),
	Syndicate varchar(256),
	BPCR varchar(255),
	Loss_Party varchar(256),
	Primary_Coverage varchar(256),
	Coverage_Subtype varchar(256),
	Coverage varchar(48),
	Claim_Adjuster varchar(61),
	Assigned_Group varchar(100),
	Status varchar(256),
	CreateTime datetime,
	ValidationLevel varchar(256),
	Claimant varchar(61),
	Claimant_Type varchar(256),
	ContactProhibited varchar(3),
	PrimaryPhone int,
	Address varchar(60),
	TypeofLoss varchar(25),
	Jurisdiction_State varchar(256),
	Segment varchar(256),
	Strategy varchar(256),
	Currency varchar(48),
	Outsatnding_Reserve decimal(21,9),
	FuturePayments decimal(21,9),
	Paid decimal(21,9),
	Recoveries decimal(21,9),
	Total_Incurred decimal(21,9),
	Insured varchar(60),
	LossDate datetime,
	OtherCoverageInfo varchar(3)

)  DISTKEY(ClaimID) SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : Dim_Exposure */

drop table if exists {0}.Dim_Exposure;

create table {0}.Dim_Exposure
( 	/* Dimension Audit Columns */
	Load_id						   bigint,
	Dim_Period_key				   bigint,
	Inserted_dt					   datetime,
	Updated_dt				       datetime,
	Effective_Start_dt			   datetime,
	Effective_End_dt			   datetime,
	Current_Ind					   Char(1),
	Delete_Ind					   Char(1),
    Dim_Exposure_Key bigint, -- Generated Key
	ClaimID bigint,
	ExposureID bigint,
		Exposure_ReposId bigint, -- Business Key
	ClaimNumber varchar(40),
	Exposure_Name varchar(511),
	Syndicate varchar(256),
	BPCR varchar(255),
	Loss_Party varchar(256),
	Primary_Coverage varchar(256),
	Coverage_Subtype varchar(256),
	Coverage varchar(48),
	Claim_Adjuster varchar(61),
	Assigned_Group varchar(100),
	Status varchar(256),
	CreateTime datetime,
	ValidationLevel varchar(256),
	Claimant varchar(61),
	Claimant_Type varchar(256),
	ContactProhibited varchar(3),
	PrimaryPhone int,
	Address varchar(60),
	TypeofLoss varchar(25),
	Jurisdiction_State varchar(256),
	Segment varchar(256),
	Strategy varchar(256),
	Currency varchar(48),
	Outsatnding_Reserve decimal(21,9),
	FuturePayments decimal(21,9),
	Paid decimal(21,9),
	Recoveries decimal(21,9),
	Total_Incurred decimal(21,9),
	Insured varchar(60),
	LossDate datetime,
	OtherCoverageInfo varchar(3)

)  DISTKEY(ClaimID) SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : Dim_ExchangeRate_rtl */

drop table if exists {0}.Dim_ExchangeRate_rtl;

create table {0}.Dim_ExchangeRate_rtl
( 
	Load_id						   int,
	Dim_Period_key				   int,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	Effective_Start_dt			   timestamp without time zone,
	Effective_End_dt			   timestamp without time zone,
	Current_Ind					   Char(1),
	Delete_Ind					   Char(1),
    Dim_ExchangeRate_Key		   int not null,
	ExchangeRateID                 int not null,
	FromCurrency				   varchar(5) not null,
	FromCurrencyDescription		   varchar(50) not null,
	toCurrency					   varchar(5) not null,
	toCurrencyDescription		   varchar(50) not null,
	NormalizedRate				   Decimal(26,6) not null,
	NormalizedRate_TMK			   Decimal(26,6) not null, 
	CC_CreateTime				   datetime,
	CC_UpdateTime				   datetime
)  DISTKEY(ExchangeRateID) SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : Dim_ExchangeRate */

drop table if exists {0}.Dim_ExchangeRate;

create table {0}.Dim_ExchangeRate
( 
	Load_id						   int,
	Dim_Period_key				   int,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	Effective_Start_dt			   timestamp without time zone,
	Effective_End_dt			   timestamp without time zone,
	Current_Ind					   Char(1),
	Delete_Ind					   Char(1),
    Dim_ExchangeRate_Key		   int not null,
	ExchangeRateID                 int not null,
	FromCurrency				   varchar(5) not null,
	FromCurrencyDescription		   varchar(50) not null,
	toCurrency					   varchar(5) not null,
	toCurrencyDescription		   varchar(50) not null,
	NormalizedRate				   Decimal(26,6) not null,
	NormalizedRate_TMK			   Decimal(26,6) not null, 
	CC_CreateTime				   datetime,
	CC_UpdateTime				   datetime
)  DISTKEY(ExchangeRateID) SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : CC_Timeline_rtl */

drop table if exists {0}.CC_Timeline_rtl;

create table {0}.CC_Timeline_rtl
(  /*  ETL Audit Columns */
	Load_id						   int,
	Dim_Period_key				   int,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
    ClaimID						   int not null,
/* Primary Key */
	TimelineID                     int not null,
/* Flat table Attributes */
	Summary						   varchar(1000) not null,
	Category					   varchar(100) not null,
	importance					   varchar(100) not null,
	Status						   varchar(100) not null,
	CC_CreateTime				   datetime,
	Assigned_User				   varchar(100) ,
	Lobgroup					   varchar(255) ,
	EmailAddress1					varchar(60) ,			
	Dim_claim_Key_FK			   int,
	Dim_User_Key_FK				   int,
	Dim_Activity_Key_FK			   int

)  DISTKEY(ClaimID) SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : CC_Timeline */

drop table if exists {0}.CC_Timeline;

create table {0}.CC_Timeline
(  /*  ETL Audit Columns */
	Load_id						   int,
	Dim_Period_key				   int,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
    ClaimID						   int not null,
/* Primary Key */
	TimelineID                     int not null,
/* Flat table Attributes */
	Summary						   varchar(1000) not null,
	Category					   varchar(100) not null,
	importance					   varchar(100) not null,
	Status						   varchar(100) not null,
	CC_CreateTime				   datetime,
	Assigned_User				   varchar(100) ,
	Lobgroup					   varchar(255) ,
	EmailAddress1					varchar(60) ,			
	Dim_claim_Key_FK			   int,
	Dim_User_Key_FK				   int,
	Dim_Activity_Key_FK			   int

)  DISTKEY(ClaimID) SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : CC_ECF_Summary_rtl */

drop table if exists {0}.CC_ECF_Summary_rtl;

create table {0}.CC_ECF_Summary_rtl
( /* Flat Table Audit Columns */
	Load_id						   int,
	Dim_Period_key				   int,
	Inserted_dt					   datetime,
	Updated_dt				       datetime,
	ClaimID bigint,
	UUID varchar(36),
	MessageID bigint,
	Message_Last_UpdatedTime datetime, --use this column to load incremental data
	Message_Type varchar(256),
	Syndicate varchar(60),
	Date_Arrived datetime,
	TR varchar(255),
	Transaction_Sequence varchar(255),
	Action_Code varchar(769),
	Our_Role varchar(256),
	Bureau_Type varchar(256),
	Message_State varchar(256),
	Transaction_Details varchar(255),
	Transaction_Status varchar(256),
	Transaction_Type varchar(256),
	Date datetime,
	Broker_Advised_Date datetime,
	Slip_Lead_Advised_Date datetime,
	Added_Circulated_Date datetime,
	Action_Participant varchar(255),
	Action_Participant_Type varchar(256),
	ECF_Indicator varchar(256),
	Conflict_Of_Interest varchar(1),
	SimultaneousRIPIndicator varchar(255),
	WAR varchar(1),
	XcsToAgreeIndicator varchar(255),
	UCR varchar(255),
	Triage_Category varchar(256),
	Claim_Scheme varchar(256),
	Claim_Status varchar(256),
	Loss_Event_Name varchar(255),
	Loss_Description varchar(1000),
	Line_Of_Business varchar(256),
	Loss_Cause varchar(255),
	Vessel_Aircraft varchar(255),
	Loss_Location varchar(255),
	Loss_Date_from datetime,
	Loss_Date_to datetime,
	Loss_Date_Qualifier varchar(770),
	Loss_Date_Narrative varchar(30),
	PCS_Catastrophe_Code varchar(60),
	LCO_Catastrophe_Code varchar(60),
	Adjuster varchar(255),
	AdjusterReference varchar(255),
	LawyerName varchar(255),
	LawyerReference varchar(255),
	Parallel_UCR varchar(255),
	XCR varchar(255),
	Claim_Type varchar(307),
	Insured varchar(255),
	UMR varchar(255),
	Policy_Number varchar(255),
	Insurer_Risk_Reference varchar(255),
	Insurer_Risk_Reference_2 varchar(255),
	Risk_Description varchar(255),
	Risk_Location varchar(255),
	Policy_Type varchar(255),
	Coverage_Type varchar(255),
	Risk_Code varchar(256),
	Reinsured varchar(23),
	Year_of_Account int,
	Policy_Period_from datetime,
	Policy_Period_to datetime,
	Policy_Period_Narrative varchar(255),
	Sum_Insured_Narrative varchar(255),
	Sum_Insured_Basis varchar(255),
	Market varchar(256),
	Broker_Id varchar(255),
	Name varchar(255),
	Contact varchar(255),
	Phone varchar(255),
	Email varchar(255),
	Slip_Order_1 decimal(21,9),
	Slip_Order_2 decimal(21,9),
	CoLeadIndicator varchar(255),
	Slip_Lead varchar(255),
	Bureau_Lead varchar(255),
	LeadClaimRef1_TMK varchar(35),
	LeadClaimRef2_TMK varchar(35)

)  DISTKEY(ClaimID) SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : CC_ECF_Summary */

drop table if exists {0}.CC_ECF_Summary;

create table {0}.CC_ECF_Summary
( /* Flat Table Audit Columns */
	Load_id						   int,
	Dim_Period_key				   int,
	Inserted_dt					   datetime,
	Updated_dt				       datetime,
	ClaimID bigint,
	UUID varchar(36),
	MessageID bigint,
	Message_Last_UpdatedTime datetime, --use this column to load incremental data
	Message_Type varchar(256),
	Syndicate varchar(60),
	Date_Arrived datetime,
	TR varchar(255),
	Transaction_Sequence varchar(255),
	Action_Code varchar(769),
	Our_Role varchar(256),
	Bureau_Type varchar(256),
	Message_State varchar(256),
	Transaction_Details varchar(255),
	Transaction_Status varchar(256),
	Transaction_Type varchar(256),
	Date datetime,
	Broker_Advised_Date datetime,
	Slip_Lead_Advised_Date datetime,
	Added_Circulated_Date datetime,
	Action_Participant varchar(255),
	Action_Participant_Type varchar(256),
	ECF_Indicator varchar(256),
	Conflict_Of_Interest varchar(1),
	SimultaneousRIPIndicator varchar(255),
	WAR varchar(1),
	XcsToAgreeIndicator varchar(255),
	UCR varchar(255),
	Triage_Category varchar(256),
	Claim_Scheme varchar(256),
	Claim_Status varchar(256),
	Loss_Event_Name varchar(255),
	Loss_Description varchar(1000),
	Line_Of_Business varchar(256),
	Loss_Cause varchar(255),
	Vessel_Aircraft varchar(255),
	Loss_Location varchar(255),
	Loss_Date_from datetime,
	Loss_Date_to datetime,
	Loss_Date_Qualifier varchar(770),
	Loss_Date_Narrative varchar(30),
	PCS_Catastrophe_Code varchar(60),
	LCO_Catastrophe_Code varchar(60),
	Adjuster varchar(255),
	AdjusterReference varchar(255),
	LawyerName varchar(255),
	LawyerReference varchar(255),
	Parallel_UCR varchar(255),
	XCR varchar(255),
	Claim_Type varchar(307),
	Insured varchar(255),
	UMR varchar(255),
	Policy_Number varchar(255),
	Insurer_Risk_Reference varchar(255),
	Insurer_Risk_Reference_2 varchar(255),
	Risk_Description varchar(255),
	Risk_Location varchar(255),
	Policy_Type varchar(255),
	Coverage_Type varchar(255),
	Risk_Code varchar(256),
	Reinsured varchar(23),
	Year_of_Account int,
	Policy_Period_from datetime,
	Policy_Period_to datetime,
	Policy_Period_Narrative varchar(255),
	Sum_Insured_Narrative varchar(255),
	Sum_Insured_Basis varchar(255),
	Market varchar(256),
	Broker_Id varchar(255),
	Name varchar(255),
	Contact varchar(255),
	Phone varchar(255),
	Email varchar(255),
	Slip_Order_1 decimal(21,9),
	Slip_Order_2 decimal(21,9),
	CoLeadIndicator varchar(255),
	Slip_Lead varchar(255),
	Bureau_Lead varchar(255),
	LeadClaimRef1_TMK varchar(35),
	LeadClaimRef2_TMK varchar(35)

)  DISTKEY(ClaimID) SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : Dim_Claim */

drop table if exists {0}.Dim_Claim;

create table {0}.Dim_Claim 
(
	/* Dimension Audit Columns */
	Load_id						   int,
	Dim_Period_key				   int,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	Effective_Start_dt			   timestamp without time zone,
	Effective_End_dt			   timestamp without time zone,
	Current_Ind					   Char(1),
	Delete_Ind					   Char(1),
	Dim_CLaim_Key bigint, -- Generated Key
	ClaimID bigint,
	Claim_ReposId bigint, -- Business Key
	ClaimNumber varchar(40),
	Insured varchar(60),
	Days_Open2 int,
	Migrated_Claim varchar(3),
	Cover_Type2 varchar(256),
	Claim_Classification1 varchar(256),
	Lead_Coverage_Type varchar(256),
	Total_Incurred decimal(21,9),
	Total_Payment decimal(21,9),
	Total_Reserve decimal(21,9),
	COI varchar(3),
	Litigation_Status varchar(256),
	Large_Loss1 varchar(21),
	Currently_Flagged varchar(3),
	Subrogation varchar(256),
	SIU_Status varchar(256),
	FAC_RI varchar(3),
	Top_Percentile1 varchar(3),
	Top_Percentile_TBA2 varchar(3),
	Declinature1 varchar(3),
	Dispute2 varchar(3),
	Extra_Contractual_Obligations1 varchar(3),
	Salvage2 varchar(3),
	Volatile1 varchar(3),
	Complaint1 varchar(3),
	Closely_Monitored_Claim1 varchar(3),
	SCAP1 varchar(3),
	Claim_Customer_Type1 varchar(260),
	Ex_Gratia1 varchar(3),
	Underwriter_Interest1 varchar(3),
	UCR varchar(64),
	UMR varchar(64),
	Loss_Date_from1 datetime,
	Loss_Date_to1 datetime,
	Risk_Code2 varchar(100),
	Bureau1 varchar(97),
	Fil_Code varchar(100),
	Eclipse_Claim_Number varchar(100),
	Loss_Date datetime,
	Notice_Date datetime,
	Loss_Location varchar(255),
	Loss_Details_Description varchar(1333),
	ECFLastUpdateTime datetime,
	Loss_Type varchar(256),
	Line_of_Business varchar(256),
	Claim_Segment varchar(256),
	Claim_Strategy varchar(256),
	Incident_Only varchar(3),
	Claim_Status varchar(256),
	Date_Reported datetime,
	Create_Date datetime,
	Days_Open1 int,
	AssignedUserID bigint,
	Primary_Adjuster varchar(60),
	Primary_Group varchar(256),
	Special_Claim_Permission varchar(256),
	Claim_Validation_Level varchar(256),
	ISO_Enabled varchar(3),
	Salvage_Status varchar(256),
	Other_Recoverable_Status varchar(256),
	Reinsurance_Reportable varchar(3),
	Reinsurance_Edit_Reason varchar(1333),
	Reinsurance_Flagged_Status varchar(256),
	Date_Shipped_to_Storage datetime,
	Storage_Location_State varchar(256),
	Storage_Category varchar(256),
	Storage_Type varchar(256),
	Box_No varchar(10),
	Bar_Code_No varchar(10),
	Storage_Volumes varchar(10),
	Storage_Notes varchar(1333),
	Litigation_Identified datetime,
	Days_after_FNOL varchar(62),
	Next_Trial_Date datetime,
	First_Notice_Suit varchar(3),
	Nature_of_Litigation varchar(256),
	Risk_Designation varchar(256),
	Risk_Designation_Comments varchar(250),
	Status varchar(256),
	Large_Loss2 varchar(36),
	Net_Total_Incurred decimal(21,9),
	SIU_Status2 varchar(256),
	Flagged varchar(256),
	Date_Flagged datetime,
	Reason_for_Flag varchar(1333),
	Subrogation_Manager_Comments varchar(250),
	Claim_Sanction_Status varchar(256),
	Transactions_Blocked varchar(3),
	Compliance_Response varchar(256),
	Compliance_Response_Rationale varchar(256),
	Top_Percentile2 varchar(3),
	Top_Percentile_TBA1 varchar(3),
	Actuaries_Advised varchar(3),
	Declinature2 varchar(3),
	TBA_Manager_Comments varchar(250),
	TBA_Currency varchar(256),
	Potential_Exposure_TMK_Share decimal(21,9),
	Full_Partial_Declinature varchar(256),
	Declinature_Currency varchar(256),
	Declinature_Amount_100_PCT decimal(21,9),
	Declinature_Amount_TMK_Share decimal(21,9),
	Date_Denied datetime,
	Declinature_Reason varchar(256),
	Declinature_Audit_date datetime,
	Declinature_Manager_Comments varchar(250),
	Dispute1 varchar(3),
	Nature_of_Dispute varchar(256),
	Dispute_Risk_Designation varchar(256),
	Dispute_Risk_Designation_Comments varchar(250),
	Dispute_Status varchar(256),
	Extra_Contractual_Obligations2 varchar(3),
	Nature_of_Allegation varchar(256),
	Eco_Risk_Designation varchar(256),
	ECO_Risk_Designation_Comments varchar(250),
	Eco_Status varchar(256),
	Salvage1 varchar(3),
	Salvage_Manager_Comments varchar(250),
	Volatile2 varchar(3),
	Potential_Exposure_Currency varchar(256),
	Potential_Exposure_Value decimal(21,9),
	Potential_Exposure_Manager_Comments varchar(250),
	Complaint2 varchar(3),
	Closely_Monitored_Claim2 varchar(3),
	SCAP2 varchar(3),
	Claim_Customer_Type2 varchar(256),
	Ex_Gratia2 varchar(3),
	Reason_for_Ex_Gratia_Request varchar(256),
	Ex_Gratia_Currency varchar(256),
	Ex_Gratia_Amount_Requested_100_PCT decimal(21,9),
	Ex_Gratia_Amount_Requested_TMK_Share decimal(21,9),
	Ex_Gratia_Amount_Authorised_100_PCT decimal(21,9),
	Ex_Gratia_Amount_Authorised_TMK_Share decimal(21,9),
	Outcome_of_Ex_Gratia_Request varchar(256),
	Underwriter_Interest2 varchar(3),
	Underwriter_comment varchar(350),
	Description varchar(1333),
	Cause_of_Loss varchar(256),
	Fault_Rating varchar(256),
	Insured_Liability_PCT decimal(21,9),
	Market_Cat_Code int,
	Cover_Type1 varchar(256),
	Claim_Classification2 varchar(256),
	Currency_Orig varchar(256),
	Outstandin decimal(21,9),
	Previously_Paid decimal(21,9),
	Paid_This_Time decimal(21,9),
	Incurred decimal(21,9),
	VAT_Amount decimal(21,9),
	Vessel_or_Aircraft_Name varchar(200),
	Loss_Name varchar(100),
	Loss_Date_from2 datetime,
	Loss_Date_to2 datetime,
	Bureau2 varchar(36),
	PCS_Cat_Code int,
	LCO_Cat_Code varchar(137),
	Role varchar(119),
	Risk_Code1 varchar(100),
	Broker_Claim_Ref_1 varchar(100),
	Location varchar(304),
	Country varchar(256),
	AddressLine1 varchar(60),
	AddressLine2 varchar(60),
	AddressLine3 varchar(60),
	City varchar(60),
	PostCode varchar(60),
	Location_Description varchar(255),
	lossLocationCode varchar(5),
	Jurisdiction varchar(256),
	Expected_Claim_Currency varchar(256),
	Expenses_Paid decimal(21,9),
	Expenses_Outstanding decimal(21,9),
	ExpensesIncurredAmount_TMK decimal(21,9),
	DefencePaidAmount_TMK decimal(21,9),
	DefenceOSAmount_TMK decimal(21,9),
	DefenceIncurredAmount_TMK decimal(21,9),
	IndemnityPaidAmount_TMK decimal(21,9),
	IndemnityOSAmount_TMK decimal(21,9),
	IndemnityIncurredAmount_TMK decimal(21,9),
	Special_Investigation_Status varchar(256),
	Special_Investigation_Type varchar(256),
	Investigation_Carried_Out_to_date varchar(256),
	Special_Investigation_Recommendations varchar(256),
	Total_Claim_Incurred_GBP decimal(21,9),
	Special_Investigation_Reserves_GBP decimal(21,9),
	Suggested_Tactics varchar(256),
	Cost_Of_Special_Investigation_GBP decimal(21,9),
	Special_Investigation_Concerns varchar(256),
	Cost_saving_Of_Special_Investigation_GBP decimal(21,9),
	ClaimTier varchar(256),
	Latest_ECFMessageID bigint,
	Plaintiff varchar(300),
	Obligor varchar(300),
	Coverholder varchar(300),
	Policy_Placing_Broker varchar(300),
	Policy_Producing_Broker varchar(300),
	Slip_Leader varchar(300),
	Check_Payee varchar(300),
	Lloyds_Leader varchar(300),
	Other varchar(300),
	Claimant varchar(300),
	Third_Party_Administrators varchar(300),
	Company_Leader varchar(300),
	Reinsured varchar(300),
	Attorney varchar(300),
	Claim_Authority_Holder varchar(300),
	Policy_Leader varchar(300),
	Reporter varchar(300),
	Defence_Counsel varchar(300),
	Secondary_Insured varchar(300),
	Defendant varchar(300),
	Reinsurer varchar(300),
	Bureau_Lead_Insurer_Or_Reinsurer varchar(300),
	Primary_Defense_Attorney varchar(300),
	Broker varchar(300),
	Intermediary varchar(300),
	Contract_Market_Insurer varchar(300),
	Witness varchar(300),
	Passenger varchar(300),
	Primary_Defense_Law_Firm varchar(300),
	SignedLine_Pct decimal(21,9)

)  DISTKEY(ClaimID) SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : Dim_Claim_rtl */

drop table if exists {0}.Dim_Claim_rtl;

create table {0}.Dim_Claim_rtl
(
	/* Dimension Audit Columns */
	Load_id						   int,
	Dim_Period_key				   int,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	Effective_Start_dt			   timestamp without time zone,
	Effective_End_dt			   timestamp without time zone,
	Current_Ind					   Char(1),
	Delete_Ind					   Char(1),
	Dim_CLaim_Key bigint, -- Generated Key
	ClaimID bigint,
	Claim_ReposId bigint, -- Business Key
	ClaimNumber varchar(40),
	Insured varchar(60),
	Days_Open2 int,
	Migrated_Claim varchar(3),
	Cover_Type2 varchar(256),
	Claim_Classification1 varchar(256),
	Lead_Coverage_Type varchar(256),
	Total_Incurred decimal(21,9),
	Total_Payment decimal(21,9),
	Total_Reserve decimal(21,9),
	COI varchar(3),
	Litigation_Status varchar(256),
	Large_Loss1 varchar(21),
	Currently_Flagged varchar(3),
	Subrogation varchar(256),
	SIU_Status varchar(256),
	FAC_RI varchar(3),
	Top_Percentile1 varchar(3),
	Top_Percentile_TBA2 varchar(3),
	Declinature1 varchar(3),
	Dispute2 varchar(3),
	Extra_Contractual_Obligations1 varchar(3),
	Salvage2 varchar(3),
	Volatile1 varchar(3),
	Complaint1 varchar(3),
	Closely_Monitored_Claim1 varchar(3),
	SCAP1 varchar(3),
	Claim_Customer_Type1 varchar(260),
	Ex_Gratia1 varchar(3),
	Underwriter_Interest1 varchar(3),
	UCR varchar(64),
	UMR varchar(64),
	Loss_Date_from1 datetime,
	Loss_Date_to1 datetime,
	Risk_Code2 varchar(100),
	Bureau1 varchar(97),
	Fil_Code varchar(100),
	Eclipse_Claim_Number varchar(100),
	Loss_Date datetime,
	Notice_Date datetime,
	Loss_Location varchar(255),
	Loss_Details_Description varchar(1333),
	ECFLastUpdateTime datetime,
	Loss_Type varchar(256),
	Line_of_Business varchar(256),
	Claim_Segment varchar(256),
	Claim_Strategy varchar(256),
	Incident_Only varchar(3),
	Claim_Status varchar(256),
	Date_Reported datetime,
	Create_Date datetime,
	Days_Open1 int,
	AssignedUserID bigint,
	Primary_Adjuster varchar(60),
	Primary_Group varchar(256),
	Special_Claim_Permission varchar(256),
	Claim_Validation_Level varchar(256),
	ISO_Enabled varchar(3),
	Salvage_Status varchar(256),
	Other_Recoverable_Status varchar(256),
	Reinsurance_Reportable varchar(3),
	Reinsurance_Edit_Reason varchar(1333),
	Reinsurance_Flagged_Status varchar(256),
	Date_Shipped_to_Storage datetime,
	Storage_Location_State varchar(256),
	Storage_Category varchar(256),
	Storage_Type varchar(256),
	Box_No varchar(10),
	Bar_Code_No varchar(10),
	Storage_Volumes varchar(10),
	Storage_Notes varchar(1333),
	Litigation_Identified datetime,
	Days_after_FNOL varchar(62),
	Next_Trial_Date datetime,
	First_Notice_Suit varchar(3),
	Nature_of_Litigation varchar(256),
	Risk_Designation varchar(256),
	Risk_Designation_Comments varchar(250),
	Status varchar(256),
	Large_Loss2 varchar(36),
	Net_Total_Incurred decimal(21,9),
	SIU_Status2 varchar(256),
	Flagged varchar(256),
	Date_Flagged datetime,
	Reason_for_Flag varchar(1333),
	Subrogation_Manager_Comments varchar(250),
	Claim_Sanction_Status varchar(256),
	Transactions_Blocked varchar(3),
	Compliance_Response varchar(256),
	Compliance_Response_Rationale varchar(256),
	Top_Percentile2 varchar(3),
	Top_Percentile_TBA1 varchar(3),
	Actuaries_Advised varchar(3),
	Declinature2 varchar(3),
	TBA_Manager_Comments varchar(250),
	TBA_Currency varchar(256),
	Potential_Exposure_TMK_Share decimal(21,9),
	Full_Partial_Declinature varchar(256),
	Declinature_Currency varchar(256),
	Declinature_Amount_100_PCT decimal(21,9),
	Declinature_Amount_TMK_Share decimal(21,9),
	Date_Denied datetime,
	Declinature_Reason varchar(256),
	Declinature_Audit_date datetime,
	Declinature_Manager_Comments varchar(250),
	Dispute1 varchar(3),
	Nature_of_Dispute varchar(256),
	Dispute_Risk_Designation varchar(256),
	Dispute_Risk_Designation_Comments varchar(250),
	Dispute_Status varchar(256),
	Extra_Contractual_Obligations2 varchar(3),
	Nature_of_Allegation varchar(256),
	Eco_Risk_Designation varchar(256),
	ECO_Risk_Designation_Comments varchar(250),
	Eco_Status varchar(256),
	Salvage1 varchar(3),
	Salvage_Manager_Comments varchar(250),
	Volatile2 varchar(3),
	Potential_Exposure_Currency varchar(256),
	Potential_Exposure_Value decimal(21,9),
	Potential_Exposure_Manager_Comments varchar(250),
	Complaint2 varchar(3),
	Closely_Monitored_Claim2 varchar(3),
	SCAP2 varchar(3),
	Claim_Customer_Type2 varchar(256),
	Ex_Gratia2 varchar(3),
	Reason_for_Ex_Gratia_Request varchar(256),
	Ex_Gratia_Currency varchar(256),
	Ex_Gratia_Amount_Requested_100_PCT decimal(21,9),
	Ex_Gratia_Amount_Requested_TMK_Share decimal(21,9),
	Ex_Gratia_Amount_Authorised_100_PCT decimal(21,9),
	Ex_Gratia_Amount_Authorised_TMK_Share decimal(21,9),
	Outcome_of_Ex_Gratia_Request varchar(256),
	Underwriter_Interest2 varchar(3),
	Underwriter_comment varchar(350),
	Description varchar(1333),
	Cause_of_Loss varchar(256),
	Fault_Rating varchar(256),
	Insured_Liability_PCT decimal(21,9),
	Market_Cat_Code int,
	Cover_Type1 varchar(256),
	Claim_Classification2 varchar(256),
	Currency_Orig varchar(256),
	Outstandin decimal(21,9),
	Previously_Paid decimal(21,9),
	Paid_This_Time decimal(21,9),
	Incurred decimal(21,9),
	VAT_Amount decimal(21,9),
	Vessel_or_Aircraft_Name varchar(200),
	Loss_Name varchar(100),
	Loss_Date_from2 datetime,
	Loss_Date_to2 datetime,
	Bureau2 varchar(36),
	PCS_Cat_Code int,
	LCO_Cat_Code varchar(137),
	Role varchar(119),
	Risk_Code1 varchar(100),
	Broker_Claim_Ref_1 varchar(100),
	Location varchar(304),
	Country varchar(256),
	AddressLine1 varchar(60),
	AddressLine2 varchar(60),
	AddressLine3 varchar(60),
	City varchar(60),
	PostCode varchar(60),
	Location_Description varchar(255),
	lossLocationCode varchar(5),
	Jurisdiction varchar(256),
	Expected_Claim_Currency varchar(256),
	Expenses_Paid decimal(21,9),
	Expenses_Outstanding decimal(21,9),
	ExpensesIncurredAmount_TMK decimal(21,9),
	DefencePaidAmount_TMK decimal(21,9),
	DefenceOSAmount_TMK decimal(21,9),
	DefenceIncurredAmount_TMK decimal(21,9),
	IndemnityPaidAmount_TMK decimal(21,9),
	IndemnityOSAmount_TMK decimal(21,9),
	IndemnityIncurredAmount_TMK decimal(21,9),
	Special_Investigation_Status varchar(256),
	Special_Investigation_Type varchar(256),
	Investigation_Carried_Out_to_date varchar(256),
	Special_Investigation_Recommendations varchar(256),
	Total_Claim_Incurred_GBP decimal(21,9),
	Special_Investigation_Reserves_GBP decimal(21,9),
	Suggested_Tactics varchar(256),
	Cost_Of_Special_Investigation_GBP decimal(21,9),
	Special_Investigation_Concerns varchar(256),
	Cost_saving_Of_Special_Investigation_GBP decimal(21,9),
	ClaimTier varchar(256),
	Latest_ECFMessageID bigint,
	Plaintiff varchar(300),
	Obligor varchar(300),
	Coverholder varchar(300),
	Policy_Placing_Broker varchar(300),
	Policy_Producing_Broker varchar(300),
	Slip_Leader varchar(300),
	Check_Payee varchar(300),
	Lloyds_Leader varchar(300),
	Other varchar(300),
	Claimant varchar(300),
	Third_Party_Administrators varchar(300),
	Company_Leader varchar(300),
	Reinsured varchar(300),
	Attorney varchar(300),
	Claim_Authority_Holder varchar(300),
	Policy_Leader varchar(300),
	Reporter varchar(300),
	Defence_Counsel varchar(300),
	Secondary_Insured varchar(300),
	Defendant varchar(300),
	Reinsurer varchar(300),
	Bureau_Lead_Insurer_Or_Reinsurer varchar(300),
	Primary_Defense_Attorney varchar(300),
	Broker varchar(300),
	Intermediary varchar(300),
	Contract_Market_Insurer varchar(300),
	Witness varchar(300),
	Passenger varchar(300),
	Primary_Defense_Law_Firm varchar(300),
	SignedLine_Pct decimal(21,9)

)  DISTKEY(ClaimID) SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : Fact_Activity_rtl */

drop table if exists {0}.Fact_Activity_rtl;

create table {0}.Fact_Activity_rtl
(
	/* Dimension Audit Columns */
	Load_id						   bigint,
	Dim_Period_key				   bigint,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	ClaimID bigint,
	ActivityID bigint,
	Related_to_ExposureID bigint,
	Related_to_MatterID bigint,
	Related_to_ContactID bigint,
    /*Claim_ReposID*/ Dim_Claim_Key_FK bigint,
    /*Activity_ReposID*/ Dim_Acitivity_Key_FK bigint,
	/*Related_to_Exposure_ReposID*/ Dim_Exposure_Key_FK bigint,
	/*Related_to_Matter_ReposID*/ Dim_Matter_Key_FK bigint,
	/*Related_to_Contact_ReposID*/ Dim_Contact_Key_FK bigint,
	LMMessage_Ext bigint
)  DISTKEY(ClaimID) SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : Fact_Activity */

drop table if exists {0}.Fact_Activity;

create table {0}.Fact_Activity
(
	/* Dimension Audit Columns */
	Load_id						   bigint,
	Dim_Period_key				   bigint,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	ClaimID bigint,
	ActivityID bigint,
	Related_to_ExposureID bigint,
	Related_to_MatterID bigint,
	Related_to_ContactID bigint,
    /*Claim_ReposID*/ Dim_Claim_Key_FK bigint,
    /*Activity_ReposID*/ Dim_Acitivity_Key_FK bigint,
	/*Related_to_Exposure_ReposID*/ Dim_Exposure_Key_FK bigint,
	/*Related_to_Matter_ReposID*/ Dim_Matter_Key_FK bigint,
	/*Related_to_Contact_ReposID*/ Dim_Contact_Key_FK bigint,
	LMMessage_Ext bigint
)  DISTKEY(ClaimID) SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : Fact_Claim_Contact_Address_rtl */

drop table if exists {0}.Fact_Claim_Contact_Address_rtl;

create table {0}.Fact_Claim_Contact_Address_rtl
( 	Load_id						   int,
	Dim_Period_key				   int,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	ClaimID bigint,
	ContactID bigint,
	AddressID bigint,
	/*Claim_ReposId*/ Dim_Claim_Key_FK bigint,
	/*Contact_ReposId*/ Dim_Contact_Key_FK bigint,
	/*Address_ReposId*/ Dim_Address_Key_FK bigint) ;

-----------------------------------------------------------------------------------

/* Table Creation : Fact_Claim_Contact_Address */

drop table if exists {0}.Fact_Claim_Contact_Address;

create table {0}.Fact_Claim_Contact_Address
( 	Load_id						   int,
	Dim_Period_key				   int,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	ClaimID bigint,
	ContactID bigint,
	AddressID bigint,
	/*Claim_ReposId*/ Dim_Claim_Key_FK bigint,
	/*Contact_ReposId*/ Dim_Contact_Key_FK bigint,
	/*Address_ReposId*/ Dim_Address_Key_FK bigint) ;

-----------------------------------------------------------------------------------

/* Table Creation : FACT_SCM_Financials_rtl */

drop table if exists {0}.FACT_SCM_Financials_rtl;

create table {0}.FACT_SCM_Financials_rtl
(  	Load_id						   int,
	Dim_Period_key				   int,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	ClaimID bigint,
	MessageID bigint,
	BPCR varchar(255),
	MovementReferenceSequence varchar(255),
	Syndicate varchar(60),
	pct100totalincurred_GBP decimal(21,9),
	LatestMovement bigint,
	previous_pct100totalincurred_GBP decimal(21,9),
	GBP_to_Original_FXRate decimal(21,9),
	GBP_to_CAD_FXRate decimal(21,9),
	GBP_to_USD_FXRate decimal(21,9),
	/*Claim_ReposID*/ Dim_Claim_Key_FK bigint
)  DISTKEY(ClaimID) SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : FACT_SCM_Financials */

drop table if exists {0}.FACT_SCM_Financials;

create table {0}.FACT_SCM_Financials
(  	Load_id						   int,
	Dim_Period_key				   int,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	ClaimID bigint,
	MessageID bigint,
	BPCR varchar(255),
	MovementReferenceSequence varchar(255),
	Syndicate varchar(60),
	pct100totalincurred_GBP decimal(21,9),
	LatestMovement bigint,
	previous_pct100totalincurred_GBP decimal(21,9),
	GBP_to_Original_FXRate decimal(21,9),
	GBP_to_CAD_FXRate decimal(21,9),
	GBP_to_USD_FXRate decimal(21,9),
	/*Claim_ReposID*/ Dim_Claim_Key_FK bigint
)  DISTKEY(ClaimID) SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : FACT_ECF_Financials */

drop table if exists {0}.FACT_ECF_Financials;

create table {0}.FACT_ECF_Financials
(  /* Fact Audit Columns */
	Load_id						   int,
	Dim_Period_key				   int,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	ClaimID bigint,
	MessageID bigint,
	Previous_MessageID bigint,
	total_incurred_amount_gbp decimal(21,9),
	Previous_Total_Incurred_Amount_GBP decimal(21,9),
	GBP_to_EUR_FXRate decimal(21,9),
	GBP_to_CAD_FXRate decimal(21,9),
	Latest_Message bigint,
	/*Claim_ReposID*/ Dim_Claim_Key_FK bigint

)  DISTKEY(ClaimID) SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : FACT_ECF_Financials_rtl */

drop table if exists {0}.FACT_ECF_Financials_rtl;

create table {0}.FACT_ECF_Financials_rtl
(  /* Fact Audit Columns */
	Load_id						   int,
	Dim_Period_key				   int,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	ClaimID bigint,
	MessageID bigint,
	Previous_MessageID bigint,
	total_incurred_amount_gbp decimal(21,9),
	Previous_Total_Incurred_Amount_GBP decimal(21,9),
	GBP_to_EUR_FXRate decimal(21,9),
	GBP_to_CAD_FXRate decimal(21,9),
	Latest_Message bigint,
	/*Claim_ReposID*/ Dim_Claim_Key_FK bigint

)  DISTKEY(ClaimID) SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : Fact_User_Group_rtl */

drop table if exists {0}.Fact_User_Group_rtl;

create table {0}.Fact_User_Group_rtl
( /* Fact Audit Columns */
	Load_id						   int,
	Dim_Period_key				   int,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	User_id bigint,
	Group_ID bigint,
	FirstName varchar(30),
	LastName varchar(30),
	Group_Name varchar(100),
	/*User_ReposId*/ Dim_User_Key_FK bigint
)  DISTSTYLE All SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------

/* Table Creation : Fact_User_Group */

drop table if exists {0}.Fact_User_Group;

create table {0}.Fact_User_Group
( /* Fact Audit Columns */
	Load_id						   int,
	Dim_Period_key				   int,
	Inserted_dt					   timestamp without time zone,
	Updated_dt				       timestamp without time zone,
	User_id bigint,
	Group_ID bigint,
	FirstName varchar(30),
	LastName varchar(30),
	Group_Name varchar(100),
	/*User_ReposId*/ Dim_User_Key_FK bigint
)  DISTSTYLE All SORTKEY(Dim_Period_key);

-----------------------------------------------------------------------------------