-- drop table #Dim_CLaim_PolicyLine
 --This is also an incremental load this table should be loaded for cc_coverage.id > Dim_CLaim_PolicyLine.PolicyLine_ReposId
 --There is no need to generate dimension keys , PolicyLine_ReposId will itself be dimension key 
 -- Load Dim_CLaim_PolicyLine 
 select 
 cc_coverage.id Dim_Claim_PolicyLine_Key,
 cc_claim.id ClaimID,
 cc_coverage.PolicyID,
 cc_coverage.id PolicyLineID,
 /* Business Key */
 cc_coverage.id PolicyLine_ReposId,
 /* Business Key */
 cc_coverage.ClassType_TMK Class_Type,
 cc_coverage.MajorClass_TMK Major_Class,
 cc_coverage.MinorClass_TMK Minor_Class,
 cc_coverage.Class_TMK Class,
 cc_coverage.PolicyLineRef_TMK Policy_Line_Reference,
 cctl_policylinestatus_tmk.L_en_GB Policy_LineStatus,
 cctl_syndicate_tmk.L_en_GB Carrier_Code,
 cctl_producingteam_tmk.L_en_GB Producing_Team,
 cc_coverage.SignedOrder_TMK Signed_Order,
 cc_coverage.SignedLine_TMK Signed_Line,
 cc_coverage.SigningNumber_TMK+'Need mapping'+ cc_policy.YearOfAccount_TMK OSND,
 cc_coverage.ExposureLimit,
 cc_coverage.RI_TMK R_I,
 cc_coverage.RI2_TMK R_I2,
 cc_coverage.RI3_TMK R_I3,
 cctl_currency.L_en_GB Policy_Currency,
 cc_coverage.PolicyInternalReference_TMK UM_Ref,
 cc_coverage.UnderwriterInitial_TMK Underwriter,
 cc_coverage.Premium_TMK Premium,
 case when PackageInd_TMK = 1 then 'Yes' else 'No' end Package,
 cc_coverage.DeclarationReference_TMK Declaration_Reference
 -- into #Dim_CLaim_PolicyLine
 from cc_claim left outer join cc_policy on  cc_claim.PolicyID = cc_policy.ID
 left outer join cc_coverage on cc_policy.id = cc_coverage.policyid
 left outer join cctl_currency on cc_policy.Currency = cctl_currency.ID
 left outer join cctl_policylinestatus_tmk on cc_coverage.PolicyLineStatus_TMK = cctl_policylinestatus_tmk.ID
 left outer join cctl_producingteam_tmk on cc_coverage.ProducingTeam_TMK = cctl_producingteam_tmk.ID
 left outer join cctl_syndicate_tmk on cc_coverage.Syndicate_TMK = cctl_syndicate_tmk.ID
 --where ClaimNumber = 'TMK000000001871'
 --added this as format input for  delta load
 where cc_coverage.id > {0}