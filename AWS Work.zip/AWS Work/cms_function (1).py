###########################################################
#   Job Name    : cms_function.py
#   Description : This is a global function list and will be called in every job. This script holds all the required functions for the job.

#   Version no  |   Date Modified  | Comment     
#       0.1     |     08/03/19     | Initial Version
#
###########################################################

import sys
import datetime
import config

from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql.types import *
from pyspark.sql import SQLContext
from awsglue.dynamicframe import DynamicFrame

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session


#Assign the values from the Config file
s3_bucket_name =config.s3_bucket_name
landing_path =config.landing_path
Stage_table_list_file_path= config.Stage_table_list_file_path
s3_file_format = config.s3_file_format
s3_file_compression = config.s3_file_compression

glue_redshift_db_user_name = config.glue_redshift_db_user_name
glue_redshift_db_password = config.glue_redshift_db_password
glue_redshift_jdbc_userpass = config.glue_redshift_jdbc_userpass
temp_dir_path = config.temp_dir_path
glue_redshift_temp_dir =  config.glue_redshift_temp_dir
glue_aws_iam_role =config.glue_aws_iam_role
glue_redshift_db_jdbc_connection = config.glue_redshift_db_jdbc_connection
glue_redshift_database = config.glue_redshift_database
glue_redshift_db_connection =config.glue_redshift_db_connection
glue_calalog_redshift_database = config.glue_calalog_redshift_database
ctrl_table_name = config.ctrl_table_name

ctrl_load_log_table = config.ctrl_load_log_table

#Initialize a class for the 'filecount' custom exception
class exception_others(Exception):
    pass

#Initialize a class for the 'job_status' custom exception
class exception_job_status(Exception):
    pass

#Initialize a class for the 'audit_function' custom exception
class exception_audit_table(Exception):
    pass

############################################################################################

# (1) Function to create the LOAD_ID,PERIOD_KEY and update the ctrl_log_management table

def UPDATE_AUDIT_TABLE( job_name, step_name,  status, error_code, error_message):
    #Create the dyanmicFrame to read the data from the ctrl_load_management table from Redshift
    try:    
        def_job_name = job_name
        def_step_name = step_name
        def_status = status
        def_error_code = error_code
        def_error_message = error_message    
            	
        if def_job_name == 'cms_stage_1_job_land_cc_table':
                        
            #To populate the LOAD_ID into S3. Create a DYF for the ctrl_load_management table
            ctrl_dyf = glueContext.create_dynamic_frame.from_catalog(database = glue_calalog_redshift_database, table_name = glue_redshift_database+"_public_"+ctrl_table_name, redshift_tmp_dir = glue_redshift_temp_dir)
            ctrl_df = ctrl_dyf.toDF().repartition(1)
            					
            #Creation of temp view for the ctrl_load_management table
            ctrl_df.createOrReplaceTempView(ctrl_table_name)
                	
            #Checking for the new LOAD_ID from the ctrl_load_management
            SQL_Execute = ("select max(load_ID) load_id from (select case when cnt =0 then 1 else 0 end  load_id from (select count(*) cnt from {0}) union select case when  (job_name = '{1}' and   status ='FAILURE') or job_name  <> '{1}' then load_id +1 else load_id end load_id from ( select row_number() over(order by inserted_dt desc,status asc) latest_inserted_dt,  b.load_id,b.status,b.job_name from  {0} b where load_id in (select max(load_id) from {0})  ) a where latest_inserted_dt =1  )").format(ctrl_table_name,def_job_name) 
            load_id_df = spark.sql(SQL_Execute)
            
            load_id_value = load_id_df.select('load_id').rdd.map(lambda r: str(r.load_id)).collect()
            load_id = load_id_value[0] 
            print "New Load_ID created is :", load_id
                #Get the current PERIOD_KEY   
            period_key = datetime.date.today().strftime('%Y%m%d')
            print "New Period_key created is :", period_key
            
            rec =[(load_id,period_key)]
            print "Record to be inserted into ctrl_load_management table  : ", rec
            						
            #Write the Load_ID,PERIOD_KEY into S3
            audit_df = spark.createDataFrame(rec, ["Load_id","Period_key"] ).repartition(1)
            
            audit_df.write.format("csv").mode("overwrite").option("header","true").save("s3://"+s3_bucket_name+"/"+landing_path+"/parameter/")
            print " New Load_ID,PERIOD_KEY is written into S3"	
                         
        #Read the Period_Key from S3
        df = spark.read.format("csv").option("header", "true").load("s3://"+s3_bucket_name+"/"+landing_path+"/parameter/part*.csv")
        #Assign it to a variable
        period_key = df.select('Period_key').rdd.map(lambda r: int(r.Period_key)).collect()
        str_period_key = " ".join(str(x) for x in period_key)
        def_period_key = int(str_period_key)
        print "period_key : ", def_period_key
        
        #Read the JOB_ID from S3
        df = spark.read.format("csv").option("header", "true").load("s3://"+s3_bucket_name+"/"+landing_path+"/parameter/part*.csv")
        #Assign it to a variable
        job_id = df.select('Load_id').rdd.map(lambda r: int(r.Load_id)).collect()
        str_job_id = " ".join(str(x) for x in job_id)
        def_job_id = int(str_job_id)
        print "job_id : ", def_job_id
        
        #Insert the audit details into the ctrl_load_management table.
        
        current_dte = spark.sql("select date_format(current_timestamp(), 'yyyy-MM-dd HH:mm:ss') tme")
        current_dte_ex = current_dte.select('tme').rdd.map(lambda r: str(r.tme)).collect()
        def_insert_date = current_dte_ex[0]         
        print "current_date : " , def_insert_date
        rec =[(def_job_id,def_job_name,def_insert_date,def_step_name,def_status,def_error_code, def_error_message,def_insert_date,def_period_key )]
        print "Record to be inserted into ctrl_load_management table  : ", rec
            
        audit_df = spark.createDataFrame(rec, ["Load_id","Job_name","Inserted_DT","Step_name","Status","Error_code","Message","Loadparmeter_start_date","Loadparmeter_Period_Key"] )
        audit_dyf = DynamicFrame.fromDF(audit_df, glueContext, "audit_df")    
        
        glueContext.write_dynamic_frame.from_jdbc_conf(frame = audit_dyf, catalog_connection = glue_redshift_db_connection, connection_options = {"dbtable": ctrl_table_name,"database": glue_redshift_database}, redshift_tmp_dir = glue_redshift_temp_dir)
            
        print "Insert completed into Redshift"
        return '1'
    except:
        print ("Unexpected error in calling the UPDATE_AUDIT_TABLE function")
        print str(sys.exc_info()[0] )
        return str(sys.exc_info()[0] )

############################################################################################        

# (2) Function to fetch the period_key

def Get_Dim_Period_Key():
	print("Read the Period_Key from S3")
	df = spark.read.format("csv").option("header", "true").load("s3://"+s3_bucket_name+"/"+landing_path+"/parameter/part*.csv")
    #Assign it to a variable
	period_key_list = df.select('Period_key').rdd.map(lambda r: int(r.Period_key)).collect()
	period_key  = period_key_list[0]
	print "period_key : ", period_key
	return period_key

############################################################################################        

# (3) Function to fetch the Load_Id

def get_loadid():
	print("Read the load_id file from S3")
	df = spark.read.format("csv").option("header", "true").load("s3://"+s3_bucket_name+"/"+landing_path+"/parameter/part*.csv")
    #Assign it to a variable
	load_id_list = df.select('Load_id').rdd.map(lambda r: int(r.Load_id)).collect()
	current_load_id  = load_id_list[0]
	print "current_load_id : ", current_load_id
	return int(current_load_id)

############################################################################################ 

# (4) Function to log the message

def log_message(job_name,log_level,log_message, step_name ='', logic ='', src_name ='', dest_name =''):
    def_job_id = 3
    current_dte = spark.sql("select date_format(current_timestamp(), 'yyyy-MM-dd HH:mm:ss') tme")
    current_dte_ex = current_dte.select('tme').rdd.map(lambda r: str(r.tme)).collect()
    def_insert_date = current_dte_ex[0]
    rec =[(def_job_id,job_name,def_insert_date,log_level,log_message, step_name, logic, src_name, dest_name )]
    print "Record to be inserted into ctrl_load_log_message  : ", rec
    log_df = spark.createDataFrame(rec, ["Load_id","job_name","start_time","log_level","log_message", "step_name", "logic", "src_name", "dest_name"] )    
    log_dyf = DynamicFrame.fromDF(log_df, glueContext, "log_df") 
    target_val = glueContext.write_dynamic_frame.from_jdbc_conf(frame = log_dyf, catalog_connection = glue_redshift_db_connection, connection_options = {"dbtable": ctrl_load_log_table,"database": glue_redshift_database}, redshift_tmp_dir = glue_redshift_temp_dir)

############################################################################################ 

# (5) Function to get the sttaus of the job

def job_status(job_name):
    ctrl_dyf = glueContext.create_dynamic_frame.from_catalog(database = glue_calalog_redshift_database, table_name = glue_redshift_database+"_public_"+ctrl_table_name, redshift_tmp_dir = glue_redshift_temp_dir)
    ctrl_df = ctrl_dyf.toDF().repartition(1)
                        
    print ("Reading data from the ctrl_load_management")
    ctrl_df.createOrReplaceTempView(ctrl_table_name)
            
    print "Checking the status of the job :" +job_name
    SQL_Execute = ("select 1 from (select row_number() over(order by inserted_dt desc,status asc) latest_inserted_dt,  b.* from  {0} b where load_id in (select max(load_id) from {0}) ) a where latest_inserted_dt =1 and job_name ='{1}' and status ='STARTED'").format(ctrl_table_name,job_name)
    table_val = spark.sql(SQL_Execute)
    print "completed"
    print table_val.count() 
    if table_val.count() == 1:
       	return 1
    else:
       	return 0

############################################################################################        

# (6) Function to create the views for all the staging tables

def call_create_views():	
	s3path_current_date = "s3://"+s3_bucket_name+"/"+landing_path+"/"
		
	print ("Reading data from the Stage_table_list_file_path")
	table_list_df = spark.read.format("csv").option("header", "true").load(Stage_table_list_file_path)
	#print("INFO", "Total base table count is : " + str(table_list_df.count()))
	table_list = table_list_df.rdd.map(lambda r: str(r.Base_table)).collect()
	print table_list
	def create_views(table_name, s3_source_path):
		DF = table_name
		catalog_tab_name = table_name+"/"
		view_name = table_name
		DF = glueContext.create_dynamic_frame_from_options(connection_type = "s3", connection_options = {"paths": [s3_source_path + catalog_tab_name]}, format = s3_file_format).toDF()
		DF.createOrReplaceTempView(view_name)
		print "View :" + view_name + "created"
	for table in table_list:
		print '\n-- tableName: '+table
		create_views(table, s3path_current_date)
	return 1
	
############################################################################################        

# (7) Function to get the maximum value of the primary key

def get_max_dim_key(dim_tab_name_RTL,dim_column_name_RTL):
    ctrl_dyf = glueContext.create_dynamic_frame.from_catalog(database = glue_calalog_redshift_database, table_name = glue_redshift_database+"_public_"+dim_tab_name_RTL, redshift_tmp_dir = glue_redshift_temp_dir)
    df = ctrl_dyf.toDF()
    print ("Creating a view for the "+dim_tab_name_RTL)     
    df.createOrReplaceTempView(dim_tab_name_RTL)
    sql_text="select case when cnt = 0 then 1 else max_key end key from ( select max("+ dim_column_name_RTL +") max_key, count(*) cnt from "+dim_tab_name_RTL +")"
    Max_Dim_Key_DF = spark.sql(sql_text)
    Max_Dim_Key_List = Max_Dim_Key_DF.select('key').rdd.map(lambda r: int(r.key)).collect()
    v_Max_Dim_Key  = Max_Dim_Key_List[0]
    print("Max value returned is ", v_Max_Dim_Key)
    return int(v_Max_Dim_Key)

############################################################################################        

# (8) Function to convert the .sql file to a string

def transform_sql_file_2_string(s3_sql_query_folder_path, sql_query_file_name):
    file= sc.wholeTextFiles(s3_sql_query_folder_path+sql_query_file_name).collect()
    query_text= str(file[0][1])
    print sql_query_file_name +" file is read and is converted into string"
    print query_text
    return query_text

############################################################################################        

# (9) Function to populate the audit columns and the primary key

def populate_audit_columns(view_name,key_name = None, max_key_value = None, load_type = 'complete',offset_required = None ):
    v_Load_id = get_loadid()
    v_Dim_Period_Key =  Get_Dim_Period_Key()  
    key_value = max_key_value
    key_alias = key_name
    print ("Create a wrapper SQL to populate the audit columns")

    if load_type == 'incremental' and offset_required == None :		
        query = """select  {1} Load_id, 
        {2} Dim_Period_Key, 
        date_format(current_timestamp(), 'yyyy-MM-dd HH:mm:ss') Inserted_dt,
        date_format(current_timestamp(), 'yyyy-MM-dd HH:mm:ss') Updated_dt,a.*    
        from {0} a where a.{3} > {4} """.format( view_name, v_Load_id, v_Dim_Period_Key,key_name,max_key_value)
    elif offset_required == 'No':
		query = """select   {1} Load_id, 
        {2} Dim_Period_Key, 
        date_format(current_timestamp(), 'yyyy-MM-dd HH:mm:ss') Inserted_dt,
        date_format(current_timestamp(), 'yyyy-MM-dd HH:mm:ss') Updated_dt,
        date_format(current_date(), 'yyyy-MM-dd HH:mm:ss')  Effective_Start_dt,
        date_format( concat(date_add(current_timestamp(), 1),' 23:59:59'), 'yyyy-MM-dd HH:mm:ss')   Effective_End_dt,
        'Y' Current_Ind,
        'N' Delete_Ind ,a.* 
        from {0} a""".format( view_name, v_Load_id, v_Dim_Period_Key)
	else:
        query = """select   {1} Load_id, 
        {2} Dim_Period_Key, 
        date_format(current_timestamp(), 'yyyy-MM-dd HH:mm:ss') Inserted_dt,
        date_format(current_timestamp(), 'yyyy-MM-dd HH:mm:ss') Updated_dt,
        date_format(current_date(), 'yyyy-MM-dd HH:mm:ss')  Effective_Start_dt,
        date_format( concat(date_add(current_timestamp(), 1),' 23:59:59'), 'yyyy-MM-dd HH:mm:ss')   Effective_End_dt,
        'Y' Current_Ind,
        'N' Delete_Ind,row_number() over(order by 1) + {3} {4} ,a.* 
        from {0} a""".format( view_name, v_Load_id, v_Dim_Period_Key, key_value,key_alias)       
    print query
    return query
    
############################################################################################        

# (10) Function to populate the surrogate key and no of records into a file    

def recon_check(jobnam,table_name,no_of_records,column_name=None,max_key=None,load_type ='complete',delta_column_name =None, max_delta_key =None):
    load_id = get_loadid()
    period_key = Get_Dim_Period_Key()   
    current_dte = spark.sql("select date_format(current_timestamp(), 'yyyy-MM-dd HH:mm:ss') tme")
    current_dte_ex = current_dte.select('tme').rdd.map(lambda r: str(r.tme)).collect()
    def_insert_date = current_dte_ex[0]         
    print "current_date : " , def_insert_date
    rec =[(load_id,period_key,jobnam,def_insert_date,table_name,column_name,max_key,no_of_records,load_type,delta_column_name,max_delta_key )]
    print "Record to be appended  : ", rec
    log_df = spark.createDataFrame(rec, ["Load_id","Period_key","job_name","Insert_time","Table_Name","Primary/Surrogate_Column_Name","Max_Primary/Surrogate_Key_Retrieved","No_of_records_processed","Load_type","Delta_column_name","Max_Delta_key_Retrieved"] ).repartition(1)
    log_df.write.format("csv").mode("append").option("header","true").save("s3://"+s3_bucket_name+"/"+landing_path+"/"+str(period_key)+"/reconciliation_check/")
    
