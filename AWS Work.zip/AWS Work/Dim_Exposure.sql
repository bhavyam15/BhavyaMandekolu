select 
cc_claim.ID ClaimID,
cc_exposure.ID ExposureID,
/* Business Key */
cc_exposure.ID Exposure_ReposId,
/* Business Key */
/* Dimension Attributes*/ 
cc_claim.ClaimNumber,
--cc_exposure.OCR_Ext +'-' +cc_exposure.PolicyLineReference_TMK Exposure_Name,
concat(cc_exposure.OCR_Ext ,'-' ,cc_exposure.PolicyLineReference_TMK) Exposure_Name,
--cctl_syndicate_tmk.L_en_GB Carrier_Code,
cctl_syndicate_tmk.L_en_GB Syndicate,
cc_exposure.OCR_Ext BPCR,
cctl_losspartytype.L_en_GB Loss_Party,
cctl_coveragetype.l_en_GB Primary_Coverage , 
cctl_coveragesubtype.L_en_GB Coverage_Subtype,
'CMS System down hence need to revist for mapping' Coverage,
c.FirstName +' '+ c.LastName Claim_Adjuster,
cc_group_name_l10n.Value Assigned_Group,
cctl_exposurestate.L_en_GB Status,
cc_exposure.CreateTime,
cctl_validationlevel.L_en_GB ValidationLevel,
--cc_contact.FirstNameDenorm +' '+ cc_contact.LastNameDenorm Claimant,
concat(cc_contact.FirstNameDenorm ,' ', cc_contact.LastNameDenorm) Claimant,
cctl_claimanttype.L_en_GB Claimant_Type,
case when cc_exposure.ContactPermitted = 1 then 'No' else 'Yes' end ContactProhibited,
--cctl_exposuretype.L_en_GB Type, 
--cctl_coveragetype.l_en_GB Coverage , 
cc_contact.PrimaryPhone PrimaryPhone,
cc_address.AddressLine1 Address,
(
select cc_incident.TypeofLoss
from 
cc_incident ,cc_claim where cc_claim.id = cc_incident.claimid
and cc_incident.Retired = 0
limit 1)
 TypeofLoss,
cctl_jurisdiction.L_en_GB Jurisdiction_State ,
cctl_claimsegment.L_en_GB Segment,
cctl_claimstrategy.L_en_GB Strategy,
'CMS System down hence need to revist for mapping' Currency,
cc_exposurerpt.RemainingReserves Outsatnding_Reserve,
cc_exposurerpt.FuturePayments,
cc_exposurerpt.TotalPayments Paid,
cc_exposurerpt.TotalRecoveries Recoveries,
cc_exposurerpt.RemainingReserves + cc_exposurerpt.TotalPayments - cc_exposurerpt.TotalRecoveries Total_Incurred,
ci.NameDenorm Insured,
LossDate,
case when cc_exposure.OtherCoverageInfo =1 then 'Yes' else 'No' end OtherCoverageInfo
/* Dimension Attributes*/ 
--into#Dim_Exposure
 from 
 cc_claim 
 left outer join cc_exposure on  cc_claim.ID = cc_exposure.claimID
 left outer join cctl_coveragetype on cc_exposure.PrimaryCoverage = cctl_coveragetype.ID
 left outer join cc_contact on cc_contact.id = cc_exposure.ClaimantDenormID
 left outer join cctl_exposuretype on cctl_exposuretype.ID = cc_exposure.ExposureType
 left outer join cc_exposurerpt on cc_exposurerpt.ExposureID = cc_exposure.ID
 left outer join cc_user on cc_exposure.AssignedUserID = cc_user.ID
 left outer join cc_contact c on c.ID = cc_user.ContactID
 left outer join cc_policy on cc_claim.PolicyID = cc_policy.ID
 left outer join cc_coverage on cc_exposure.CoverageID = cc_coverage.id
 left outer join cctl_syndicate_tmk on cc_coverage.Syndicate_TMK = cctl_syndicate_tmk.ID
 left outer join cc_user adj on cc_claim.AssignedUserID = adj.ID
 left outer join cc_contact ci on cc_claim.InsuredDenormID = ci.ID
 left outer join cctl_losspartytype on cc_exposure.LossParty = cctl_losspartytype.ID
 left outer join cctl_coveragesubtype on cc_exposure.CoverageSubType = cctl_coveragesubtype.ID
 left outer join cc_group_name_l10n on cc_group_name_l10n.id = cc_claim.AssignedGroupID
 left outer join cctl_exposurestate on cc_exposure.State = cctl_exposurestate.ID
 left outer join cctl_validationlevel on cc_exposure.ValidationLevel = cctl_validationlevel.id
 left outer join cctl_claimanttype on cc_exposure.ClaimantType = cctl_claimanttype.id  
 left outer join cc_address on cc_contact.PrimaryAddressID = cc_address.ID
 left outer join cctl_jurisdiction on cc_exposure.JurisdictionState = cctl_jurisdiction.ID
 left outer join cctl_claimsegment on cc_exposure.Segment = cctl_claimsegment.ID
 left outer join cctl_claimstrategy on cc_exposure.Strategy = cctl_claimstrategy.ID
  where cc_exposure.id is not null 
   --ClaimNumber = 'TMK000000001871' 