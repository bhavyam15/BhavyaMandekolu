USE master;
GO

ALTER DATABASE CMS_A_KDR
SET SINGLE USER



RESTORE DATABASE CMS_Binders
FROM DISK = '\\uk2_grpvse01\cms\LONSSQL01\Binders.DAT'
WITH REPLACE
	,RECOVERY
	,MOVE 'Binders' TO 'F:\SQLData\CMS_Binders_Data.mdf'
	,MOVE 'Binders_Log' TO 'H:\SQLLog\CMS_Binders_Log.ldf'
	,STATS = 1
GO

RESTORE DATABASE CMS_CALC
FROM DISK = '\\uk2_grpvse01\cms\LONSSQL01\CALC.DAT'
WITH REPLACE
	,RECOVERY
	,MOVE 'CALC' TO 'F:\SQLData\CMS_CALC_Data.mdf'
	,MOVE 'CALC_log' TO 'H:\SQLLog\CMS_CALC_Log.ldf'
	,STATS = 1
GO

RESTORE DATABASE CMS_CBS_MART
FROM DISK = '\\uk2_grpvse01\cms\LONSSQL01\CBS_MART.DAT'
WITH REPLACE
	,RECOVERY
	,MOVE 'CBS_MART' TO 'F:\SQLData\CMS_CBS_MART.mdf'
	,MOVE 'CBS_MART_log' TO 'H:\SQLLog\CMS_CBS_MART_Log.ldf'
	,STATS = 1
GO

RESTORE DATABASE CMS_Claims_Administration
FROM DISK = '\\uk2_grpvse01\cms\LONSSQL01\CLAIMS_ADMINISTRATION.DAT'
WITH REPLACE
	,RECOVERY
	,MOVE 'Claims_Administration' TO 'F:\SQLData\CMS_Claims_Administration.mdf'
	,MOVE 'Claims_Administration_log' TO 'H:\Sqllog\CMS_Claims_Administration.ldf'
	,STATS = 1
GO

RESTORE DATABASE CMS_Claims_Mart
FROM DISK = '\\uk2_grpvse01\cms\LONSSQL01\Claims_Mart.DAT'
WITH REPLACE
	,RECOVERY
	,MOVE 'Claims_Mart' TO 'F:\SQLData\CMS_Claims_Mart.mdf'
	,MOVE 'Claims_Mart_log' TO 'H:\SQLLog\CMS_Claims_Mart.ldf'
	,STATS = 1
GO


RESTORE DATABASE CMS_FC
FROM DISK = '\\uk2_grpvse01\cms\LONSSQL01\FC.DAT'
WITH REPLACE
	,RECOVERY
	,MOVE 'FC' TO 'F:\SQLData\CMS_FC.mdf'
	,MOVE 'FC_log' TO 'H:\SQLLog\CMS_FC.ldf'
	,STATS = 1
GO

RESTORE DATABASE CMS_Fred_Mart
FROM DISK = '\\uk2_grpvse01\cms\LONSSQL01\Fred_Mart.DAT'
WITH REPLACE
	,RECOVERY
	,MOVE 'Fred_Mart' TO 'F:\SQLData\CMS_Fred_Mart.mdf'
	,MOVE 'Fred_Mart_log' TO 'H:\SQLLog\CMS_Fred_Mart.ldf'
	,STATS = 1
GO

RESTORE DATABASE CMS_JBOSS_PORTAL
FROM DISK = '\\uk2_grpvse01\cms\LONSSQL01\jboss_portal.DAT'
WITH REPLACE
	,RECOVERY
	,MOVE 'jboss_portal' TO 'F:\SQLData\CMS_JBOSS_PORTAL.mdf'
        ,MOVE 'jboss_portal_log' TO 'H:\SQLLog\CMS_JBOSS_PORTAL.ldf'
	,STATS = 1
GO

RESTORE DATABASE CMS_KDR
FROM DISK = '\\uk2_grpvse01\cms\LONSSQL01\KDR.DAT'
WITH REPLACE
	,RECOVERY
	,MOVE 'KDR' TO 'F:\SQLData\CMS_KDR_Data.mdf'
	,MOVE 'KDR_log' TO 'H:\SQLLog\CMS_KDR_Log.ldf'
	,STATS = 1
GO

RESTORE DATABASE CMS_KDR_Portal
FROM DISK = '\\uk2_grpvse01\cms\LONSSQL01\KDR_Portal.DAT'
WITH REPLACE
	,RECOVERY
	,MOVE 'KDR_PORTAL' TO 'F:\SQLData\CMS_KDR_Portal.mdf'
	,MOVE 'KDR_PORTAL_Log' TO 'H:\SQLLog\CMS_KDR_Portal.ldf'
	,STATS = 1
GO

RESTORE DATABASE CMS_KDR_Staging
FROM DISK = '\\uk2_grpvse01\cms\LONSSQL01\KDRStaging.DAT'
WITH REPLACE
	,RECOVERY
	,MOVE 'KDRStaging' TO 'F:\SQLData\CMS_KDR_Staging_Data.mdf'
	,MOVE 'KDRStaging_log' TO 'H:\SQLLog\CMS_KDR_Staging_Log.ldf'
	,STATS = 1
GO


RESTORE DATABASE CMS_MADMAN
FROM DISK = '\\uk2_grpvse01\cms\LONSSQL01\MADMAN.DAT'
WITH REPLACE
	,RECOVERY
	,MOVE 'MADMAN' TO 'F:\SQLData\CMS_MADMAN.mdf'
	,MOVE 'MADMAN_Log' TO 'H:\SQLLog\CMS_MADMAN.ldf'
	,STATS = 1
GO


RESTORE DATABASE CMS_MasterReferenceData
FROM DISK = '\\uk2_grpvse01\cms\LONSSQL01\MasterReferenceData.DAT'
WITH REPLACE
	,RECOVERY
	,MOVE 'MasterReferenceData' TO 'F:\SQLData\CMS_MasterReferenceData_Data.mdf'
	,MOVE 'MasterReferenceData_log' TO 'H:\SQLLog\CMS_MasterReferenceData_Log.ldf'
	,STATS = 1
GO

RESTORE DATABASE CMS_Operational
FROM DISK = '\\uk2_grpvse01\cms\LONSSQL01\Operational.DAT'
WITH REPLACE
	,RECOVERY
	,MOVE 'Operational' TO 'F:\SQLData\CMS_Operational.mdf'
	,MOVE 'Operational_log' TO 'H:\SQLLog\CMS_Operational.ldf'
	,STATS = 1
GO

RESTORE DATABASE CMS_Policy_Administration
FROM DISK = '\\uk2_grpvse01\cms\LONSSQL01\POLICY_ADMINISTRATION.DAT'
WITH REPLACE
	,RECOVERY
	,MOVE 'Policy_Administration' TO 'F:\SQLData\CMS_Policy_Administration.mdf'
	,MOVE 'Policy_Administration_log' TO 'H:\Sqllog\CMS_Policy_Administration.ldf'
	,STATS = 1
GO

RESTORE DATABASE CMS_Reporting
FROM DISK = '\\uk2_grpvse01\cms\LONSSQL01\Reporting.DAT'
WITH REPLACE
	,RECOVERY
	,MOVE 'Reporting' TO 'F:\SQLData\CMS_CMS_Reporting.mdf'
	,MOVE 'Reporting_log' TO 'H:\SQLLog\CMS_Reporting.ldf'
	,STATS = 1
GO

RESTORE DATABASE CMS_Credit_Control
FROM DISK = '\\uk2_grpvse01\cms\LONSSQL01\Credit_Control_20180718185152.BAK'
WITH REPLACE
	,RECOVERY
	,MOVE 'Credit_Control' TO 'F:\SQLData\CMS_Credit_Control.mdf'
	,MOVE 'Credit_Control_Log' TO 'H:\SQLLog\CMS_Credit_Control.ldf'
	,STATS = 1
GO


/*
RESTORE DATABASE CMSAppMaster
FROM DISK = '\\lonstcs01\Backup\SQL_Backup\LONSSQL01\CMSAppMaster.DAT'
WITH REPLACE
	,RECOVERY
	,MOVE 'KILNMCAPP' TO 'F:\SQLData\KILNMCAPP.mdf'
	,MOVE 'KILNMCAPP_log' TO 'H:\Sqllog\KILNMCAPP.ldf'
	,STATS = 1
GO

RESTORE DATABASE CMSSecMaster
FROM DISK = '\\lonstcs01\Backup\SQL_Backup\LONSSQL01\CMSSecMaster.DAT'
WITH REPLACE
	,RECOVERY
	,MOVE 'KILNMCSEC' TO 'F:\SQLData\KILNMCSEC.mdf'
	,MOVE 'KILNMCSEC_log' TO 'H:\Sqllog\KILNMCSEC.ldf'
	,STATS = 1
GO

*/





use
BAU_A_BAG_MART
go 
DROP USER DS_ADMIN; 
CREATE USER DS_ADMIN FOR LOGIN DS_ADMIN;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN';

use
CMS_Binders
go 
DROP USER DS_ADMIN; 
CREATE USER DS_ADMIN FOR LOGIN DS_ADMIN;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN';

use
CMS_CALC
go 
DROP USER DS_ADMIN;
CREATE USER DS_ADMIN FOR LOGIN DS_ADMIN;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN';

use
CMS_CBS_MART
go 
DROP USER DS_ADMIN;
CREATE USER DS_ADMIN FOR LOGIN DS_ADMIN;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN';

use
CMS_Claims_Administration
go 
DROP USER DS_ADMIN;
CREATE USER DS_ADMIN FOR LOGIN DS_ADMIN;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN';


use
CMS_Claims_Mart
go 
DROP USER DS_ADMIN;
CREATE USER DS_ADMIN FOR LOGIN DS_ADMIN;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN';


use
CMS_FC
go 
DROP USER DS_ADMIN;
CREATE USER DS_ADMIN FOR LOGIN DS_ADMIN;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN';

use
CMS_Fred_Mart
go 
DROP USER DS_ADMIN;
CREATE USER DS_ADMIN FOR LOGIN DS_ADMIN;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN';

use
CMS_Jboss_portal
go 
DROP USER DS_ADMIN;
CREATE USER DS_ADMIN FOR LOGIN DS_ADMIN;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN';

use
CMS_KDR
go 
DROP USER DS_ADMIN;
CREATE USER DS_ADMIN FOR LOGIN DS_ADMIN;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN';

use
CMS_KDR_Portal
go 
DROP USER DS_ADMIN;
CREATE USER DS_ADMIN FOR LOGIN DS_ADMIN;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN';

use
CMS_KDR_Staging
go 
DROP USER DS_ADMIN;
CREATE USER DS_ADMIN FOR LOGIN DS_ADMIN;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN';

use
CMS_MADMAN
go 
DROP USER DS_ADMIN;
CREATE USER DS_ADMIN FOR LOGIN DS_ADMIN;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN';

use
CMS_MasterReferenceData
go 
DROP USER DS_ADMIN;
CREATE USER DS_ADMIN FOR LOGIN DS_ADMIN;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN';

use
CMS_Operational
go 
DROP USER DS_ADMIN;
CREATE USER DS_ADMIN FOR LOGIN DS_ADMIN;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN';

use
CMS_Policy_Administration
go 
DROP USER DS_ADMIN;
CREATE USER DS_ADMIN FOR LOGIN DS_ADMIN;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN';

use
CMS_Reporting
go 
DROP USER DS_ADMIN;
CREATE USER DS_ADMIN FOR LOGIN DS_ADMIN;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN';

use
CMS_Credit_Control
go 
DROP USER DS_ADMIN; 
CREATE USER DS_ADMIN FOR LOGIN DS_ADMIN;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN';
