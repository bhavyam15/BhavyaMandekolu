use [master]
ALTER DATABASE CMS_PRESIT_KDR
SET MULTI_USER
--This rolls back all uncommitted transactions in the db.
WITH ROLLBACK IMMEDIATE
GO


RESTORE DATABASE CMS_PRESIT_KDR
FROM DISK = '\\appvse01\NOT_BACKED_UP\CMS\Prod_Bak_File_DB_29_11_18\KDR.DAT'
WITH REPLACE
	,RECOVERY
	,MOVE 'KDR' TO 'D:\SQLData\CMS_PRESIT_KDR.mdf'
	,MOVE 'KDR_log' TO 'L:\SQLLogs\CMS_PRESIT_KDR_log.ldf'
	,STATS = 1
GO

ALTER DATABASE CMS_PRESIT_KDR
SET MULTI_USER
--This rolls back all uncommitted transactions in the db.
WITH ROLLBACK IMMEDIATE
GO
use CMS_PRESIT_KDR
go 
DROP USER DS_ADMIN_ST;
CREATE USER DS_ADMIN_ST FOR LOGIN DS_ADMIN_ST;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN_ST';

RESTORE DATABASE CMS_PRESIT_MasterReferenceData
FROM DISK = '\\appvse01\NOT_BACKED_UP\CMS\Prod_Bak_File_DB_29_11_18\MasterReferenceData.DAT'
WITH REPLACE
	,RECOVERY
	,MOVE 'MasterReferenceData' TO 'D:\SQLData\CMS_A_MasterReferenceData.mdf'
	,MOVE 'MasterReferenceData_log' TO 'L:\SQLLogs\CMS_A_MasterReferenceData_log.ldf'
	,STATS = 1
GO
use
CMS_PRESIT_MasterReferenceData
go 
DROP USER DS_ADMIN_ST;
CREATE USER DS_ADMIN_ST FOR LOGIN DS_ADMIN_ST;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN_ST';


--To check if DB's are refreshed or not 
use msdb
select * from dbo.restorehistory order by restore_date desc

use [master]
ALTER DATABASE CMS_PRESIT_KDRStaging
SET SINGLE_USER
--This rolls back all uncommitted transactions in the db.
WITH ROLLBACK IMMEDIATE
GO

RESTORE DATABASE CMS_PRESIT_KDRStaging
FROM DISK = '\\lonstcs01\Backup\SQL_Backup\LONSSQL01\KDRStaging.DAT'
WITH REPLACE
	,RECOVERY
	,MOVE 'KDRStaging' TO 'D:\SQLData\CMS_A_KDR_Staging.mdf'
	,MOVE 'KDRStaging_log' TO 'L:\SQLLogs\CMS_A_KDR_Staging_log.ldf'
	,STATS = 1
GO

ALTER DATABASE CMS_PRESIT_KDRStaging
SET MULTI_USER
--This rolls back all uncommitted transactions in the db.
WITH ROLLBACK IMMEDIATE
GO

use CMS_PRESIT_KDRStaging
go 
DROP USER DS_ADMIN_ST;
CREATE USER DS_ADMIN_ST FOR LOGIN DS_ADMIN_ST;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN_ST'; 

use [master]
ALTER DATABASE DS_LOCAL_REPOS_CMSSYS
SET SINGLE_USER
--This rolls back all uncommitted transactions in the db.
WITH ROLLBACK IMMEDIATE
GO

RESTORE DATABASE DS_LOCAL_REPOS_CMSSYS
FROM DISK = '\\appvse01\NOT_BACKED_UP\CMS\Prod_Bak_File_DB_29_11_18\DS_LOCAL_REPOS_PROD.DAT'
WITH REPLACE
          ,RECOVERY
          ,MOVE 'DS_LOCAL_REPOS_PROD' TO 'D:\SQLData\DS_LOCAL_REPOS_CMSSYS.mdf'
          ,MOVE 'DS_LOCAL_REPOS_PROD_log' TO 'L:\SQLLogs\DS_LOCAL_REPOS_CMSSYS.ldf'
          ,STATS = 1
GO

ALTER DATABASE DS_LOCAL_REPOS_CMSSYS
SET MULTI_USER
--This rolls back all uncommitted transactions in the db.
WITH ROLLBACK IMMEDIATE
GO

use DS_LOCAL_REPOS_CMSSYS
go 
DROP USER DS_ADMIN_ST; 
CREATE USER DS_ADMIN_ST FOR LOGIN DS_ADMIN_ST;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN_ST';     

SELECT * from AL_MACHINE_INFO

update AL_MACHINE_INFO set RESERVED2='UK1-SQL-KDR-T01' where SEQNUM=4

delete from AL_MACHINE_INFO where SEQNUM in (8,9,10)


select top 1 * from Policy_Summary