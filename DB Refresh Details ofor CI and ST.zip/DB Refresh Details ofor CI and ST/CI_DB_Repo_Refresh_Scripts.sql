Backup files present in : \\lonstcs01\Backup\SQL_Backup\SQL-CLU-KDR-P01

ALTER DATABASE DS_LOCAL_REPOS_CA_CI

SET single_user
WITH

ROLLBACK immediate
GO

ALTER DATABASE DS_LOCAL_REPOS_CA_CI
SET RECOVERY SIMPLE WITH NO_WAIT
GO

RESTORE DATABASE DS_LOCAL_REPOS_CA_CI
FROM DISK = '\\lonantcfs1\Kiln Software\Sakaar\Backup\DB_Backup\Prod_post_rel3\DS_LOCAL_REPOS_PROD.DAT'
WITH REPLACE
          ,RECOVERY
          ,MOVE 'DS_LOCAL_REPOS_PROD' TO 'D:\SQLData\DS_LOCAL_REPOS_CA_CI.mdf'
          ,MOVE 'DS_LOCAL_REPOS_PROD_log' TO 'E:\Sqllogs\DS_LOCAL_REPOS_CA_CI.ldf'
          ,STATS = 1
--Step#2
use
DS_LOCAL_REPOS_CA_CI
go 
DROP USER DS_ADMIN; 
CREATE USER DS_ADMIN FOR LOGIN DS_ADMIN;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN';     

--Step#3
use DS_LOCAL_REPOS_CA_CI
SELECT * from AL_MACHINE_INFO

use DS_LOCAL_REPOS_BhavyaMandekolu
SELECT * from AL_MACHINE_INFO

update AL_MACHINE_INFO set RESERVED2='UK2-SQL-KDR-D01' where SEQNUM=4
delete from AL_MACHINE_INFO where SEQNUM in (5,6,7)
----------------------------------------------------------------------------------------------------

use msdb
select * from restorehistory order by 1 desc
select top 10 * from CA_CI_Reporting..WRK_REP_MART_PRE_CUML_INW_CONTRACT_ORIGINAL
-------------------------------------------------------------------------------------------------------------
ALTER DATABASE CA_CI_Calc

SET single_user
WITH

ROLLBACK immediate
GO

ALTER DATABASE CA_CI_Calc
SET RECOVERY SIMPLE WITH NO_WAIT
GO

RESTORE DATABASE CA_CI_Calc
FROM DISK = '\\lonantcfs1\Kiln Software\Sakaar\Backup\DB_Backup\Prod_post_rel3\CALC.DAT'
WITH REPLACE
          ,RECOVERY
          ,MOVE 'CALC' TO 'D:\SQLData\CA_CI_Calc.mdf'
          ,MOVE 'CALC_log' TO 'E:\Sqllogs\CA_CI_Calc.ldf'
          ,STATS = 1
--Step#2
use CA_CI_Calc
go 
DROP USER DS_ADMIN; 
CREATE USER DS_ADMIN FOR LOGIN DS_ADMIN;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN';  
-------------------------------------------------------------------------------------------------------  
ALTER DATABASE CA_CI_Credit_Control
SET single_user
WITH ROLLBACK immediate
GO

ALTER DATABASE CA_CI_Credit_Control
SET RECOVERY SIMPLE WITH NO_WAIT
GO

RESTORE DATABASE CA_CI_Credit_Control
FROM DISK = '\\lonantcfs1\Kiln Software\Sakaar\Backup\DB_Backup\Prod_post_rel3\Credit_Control.DAT'
WITH REPLACE
          ,RECOVERY
          ,MOVE 'Credit_Control' TO 'D:\SQLData\CA_CI_Credit_Control.mdf'
          ,MOVE 'Credit_Control_log' TO 'L:\Sqllogs\CA_CI_Credit_Control.ldf'
          ,STATS = 1
--Step#2
use CA_CI_Credit_Control
go 
DROP USER DS_ADMIN; 
CREATE USER DS_ADMIN FOR LOGIN DS_ADMIN;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN';  
------------------------------------------------------------------------------------------------------
ALTER DATABASE CA_CI_FC
SET single_user
WITH ROLLBACK immediate
GO

ALTER DATABASE CA_CI_FC
SET RECOVERY SIMPLE WITH NO_WAIT
GO

RESTORE DATABASE CA_CI_FC
FROM DISK = '\\lonantcfs1\Kiln Software\Sakaar\Backup\DB_Backup\Prod_post_rel3\FC.DAT'
WITH REPLACE
          ,RECOVERY
          ,MOVE 'FC' TO 'D:\SQLData\CA_CI_FC.mdf'
          ,MOVE 'FC_log' TO 'L:\Sqllogs\CA_CI_FC.ldf'
          ,STATS = 1
--Step#2
use CA_CI_FC
go 
DROP USER DS_ADMIN; 
CREATE USER DS_ADMIN FOR LOGIN DS_ADMIN;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN'; 
---------------------------------------------------------------------------------------------------------
ALTER DATABASE CA_CI_Fred_Mart
SET single_user
WITH ROLLBACK immediate
GO

ALTER DATABASE CA_CI_Fred_Mart
SET RECOVERY SIMPLE WITH NO_WAIT
GO

RESTORE DATABASE CA_CI_Fred_Mart
FROM DISK = '\\lonantcfs1\Kiln Software\Sakaar\Backup\DB_Backup\Prod_post_rel3\Fred_Mart.DAT'
WITH REPLACE
          ,RECOVERY
          ,MOVE 'Fred_Mart' TO 'D:\SQLData\CA_CI_Fred_Mart.mdf'
          ,MOVE 'Fred_Mart_log' TO 'L:\Sqllogs\CA_CI_Fred_Mart.ldf'
          ,STATS = 1
--Step#2
use CA_CI_Fred_Mart
go 
DROP USER DS_ADMIN; 
CREATE USER DS_ADMIN FOR LOGIN DS_ADMIN;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN'; 
--------------------------------------------------------------------------------------------------- 
ALTER DATABASE CA_CI_KDR_Portal
SET single_user
WITH ROLLBACK immediate
GO

ALTER DATABASE CA_CI_KDR_Portal
SET RECOVERY SIMPLE WITH NO_WAIT
GO

RESTORE DATABASE CA_CI_KDR_Portal
FROM DISK = '\\lonantcfs1\Kiln Software\Sakaar\Backup\DB_Backup\Prod_post_rel3\KDR_Portal.DAT'
WITH REPLACE
          ,RECOVERY
          ,MOVE 'KDR_Portal' TO 'D:\SQLData\CA_CI_KDR_Portal.mdf'
          ,MOVE 'KDR_Portal_log' TO 'L:\Sqllogs\CA_CI_KDR_Portal.ldf'
          ,STATS = 1
--Step#2
use CA_CI_KDR_Portal
go 
DROP USER DS_ADMIN; 
CREATE USER DS_ADMIN FOR LOGIN DS_ADMIN;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN';
-----------------------------------------------------------------------------------------------------
ALTER DATABASE CA_CI_KDRStaging
SET single_user
WITH ROLLBACK immediate
GO

ALTER DATABASE CA_CI_KDRStaging
SET RECOVERY SIMPLE WITH NO_WAIT
GO

RESTORE DATABASE CA_CI_KDRStaging
FROM DISK = '\\lonantcfs1\Kiln Software\Sakaar\Backup\DB_Backup\Prod_post_rel3\KDRStaging.DAT'
WITH REPLACE
          ,RECOVERY
          ,MOVE 'KDRStaging' TO 'D:\SQLData\CA_CI_KDRStaging.mdf'
          ,MOVE 'KDRStaging_log' TO 'L:\Sqllogs\CA_CI_KDRStaging.ldf'
          ,STATS = 1
--Step#2
use CA_CI_KDRStaging
go 
DROP USER DS_ADMIN; 
CREATE USER DS_ADMIN FOR LOGIN DS_ADMIN;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN';
---------------------------------------------------------------------------------------------------------------
ALTER DATABASE CA_CI_MasterReferenceData
SET single_user
WITH ROLLBACK immediate
GO

ALTER DATABASE CA_CI_MasterReferenceData
SET RECOVERY SIMPLE WITH NO_WAIT
GO

RESTORE DATABASE CA_CI_MasterReferenceData
FROM DISK = '\\lonantcfs1\Kiln Software\Sakaar\Backup\DB_Backup\Prod_post_rel3\MasterReferenceData.DAT'
WITH REPLACE
          ,RECOVERY
          ,MOVE 'MasterReferenceData' TO 'D:\SQLData\CA_CI_MasterReferenceData.mdf'
          ,MOVE 'MasterReferenceData_log' TO 'L:\Sqllogs\CA_CI_MasterReferenceData.ldf'
          ,STATS = 1
--Step#2
use CA_CI_MasterReferenceData
go 
DROP USER DS_ADMIN; 
CREATE USER DS_ADMIN FOR LOGIN DS_ADMIN;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN';
--------------------------------------------------------------------------------------------------------------
ALTER DATABASE CA_CI_Reporting
SET single_user
WITH ROLLBACK immediate
GO

ALTER DATABASE CA_CI_Reporting
SET RECOVERY SIMPLE WITH NO_WAIT
GO

RESTORE DATABASE CA_CI_Reporting
FROM DISK = '\\lonantcfs1\Kiln Software\Sakaar\Backup\DB_Backup\Prod_post_rel3\Reporting.DAT'
WITH REPLACE
          ,RECOVERY
          ,MOVE 'Reporting' TO 'D:\SQLData\CA_CI_Reporting.mdf'
          ,MOVE 'Reporting_log' TO 'L:\Sqllogs\CA_CI_Reporting.ldf'
          ,STATS = 1
--Step#2
use CA_CI_Reporting
go 
DROP USER DS_ADMIN; 
CREATE USER DS_ADMIN FOR LOGIN DS_ADMIN;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN';
---------------------------------------------------------------------------------------------------
ALTER DATABASE CA_CI_KDR
SET single_user
WITH ROLLBACK immediate
GO

ALTER DATABASE CA_CI_KDR
SET RECOVERY SIMPLE WITH NO_WAIT
GO

RESTORE DATABASE CA_CI_KDR
FROM DISK = '\\lonantcfs1\Kiln Software\Sakaar\Backup\DB_Backup\Prod_post_rel3\KDR.DAT'
WITH REPLACE
          ,RECOVERY
          ,MOVE 'KDR' TO 'D:\SQLData\CA_CI_KDR.mdf'
          ,MOVE 'KDR_log' TO 'L:\Sqllogs\CA_CI_KDR.ldf'
          ,STATS = 1
--Step#2
use CA_CI_KDR
go 
DROP USER DS_ADMIN; 
CREATE USER DS_ADMIN FOR LOGIN DS_ADMIN;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN';