use master 


ALTER DATABASE CA_A_Reporting
SET SINGLE_USER
WITH ROLLBACK IMMEDIATE;
GO

RESTORE DATABASE CA_A_Reporting
FROM DISK = '\\lonantcfs1\Kiln Software\Sakaar\Backup\DB_Backup\Reporting_080420.bak'
WITH REPLACE
    ,RECOVERY
    ,MOVE 'Reporting' TO 'B:\SQLData\ CA_A_Reporting.mdf'
	,MOVE 'Reporting_Partitions' TO 'B:\SQLData\ CA_A_Reporting_Partitions.ndf'
	,MOVE 'Reporting_Partitions_Active' TO 'B:\SQLData\ CA_A_Reporting_Partitions_Active.ndf'
    ,MOVE 'Reporting_log' TO 'E:\SQLLogs\ CA_A_Reporting_0.ldf'
    ,STATS = 1
GO


USE [master]
GO
ALTER DATABASE [CA_A_Reporting] SET RECOVERY SIMPLE WITH NO_WAIT
GO


USE [CA_A_Reporting]
GO
DBCC SHRINKFILE (N'Reporting_log' , 5000)
GO


use
CA_A_Reporting 
go
DROP USER DS_ADMIN;
CREATE USER DS_ADMIN FOR LOGIN DS_ADMIN;
EXEC sp_addrolemember N'db_owner', N'DS_ADMIN';

